#ifndef _CreateFileIniGTM3DDialog_H_
#define _CreateFileIniGTM3DDialog_H_

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

class CreateFileIniGTM3DDialog : public wxDialog {

public:
    CreateFileIniGTM3DDialog( wxWindow* parent, const wxString& title );

    void OnButtonClick(wxCommandEvent &event);

    void set_xmin(wxString _s)   { Xmin->SetLabel(_s); }
    void set_ymin(wxString _s)   { Ymin->SetLabel(_s); }
    void set_zmin(wxString _s)   { Zmin->SetLabel(_s); }
    void set_xmax(wxString _s)   { Xmax->SetLabel(_s); }
    void set_ymax(wxString _s)   { Ymax->SetLabel(_s); }
    void set_zmax(wxString _s)   { Zmax->SetLabel(_s); }
    void set_size(wxString _s)   { Bsiz->SetLabel(_s); }
    void set_illum(wxString _s)  { illum->SetLabel(_s); }
    void set_col1R(wxString _s)  { col1R->SetLabel(_s); }
    void set_col1G(wxString _s)  { col1G->SetLabel(_s); }
    void set_col1B(wxString _s)  { col1B->SetLabel(_s); }
    void set_col2R(wxString _s)  { col2R->SetLabel(_s); }
    void set_col2G(wxString _s)  { col2G->SetLabel(_s); }
    void set_col2B(wxString _s)  { col2B->SetLabel(_s); }
    void set_col3R(wxString _s)  { col3R->SetLabel(_s); }
    void set_col3G(wxString _s)  { col3G->SetLabel(_s); }
    void set_col3B(wxString _s)  { col3B->SetLabel(_s); }
    void set_col4R(wxString _s)  { col4R->SetLabel(_s); }
    void set_col4G(wxString _s)  { col4G->SetLabel(_s); }
    void set_col4B(wxString _s)  { col4B->SetLabel(_s); }
    void set_m2(wxString _s)  { m2->SetLabel(_s); }
    void set_m3(wxString _s)  { m3->SetLabel(_s); }
    void set_d2(wxString _s)  { d2->SetLabel(_s); }
    void set_d3(wxString _s)  { d3->SetLabel(_s); }
    void set_d4(wxString _s)  { d4->SetLabel(_s); }

    float get_xmin()     { return wxAtof(Xmin->GetLabelText()); }
    float get_ymin()     { return wxAtof(Ymin->GetLabelText()); }
    float get_zmin()     { return wxAtof(Zmin->GetLabelText()); }
    float get_xmax()     { return wxAtof(Xmax->GetLabelText()); }
    float get_ymax()     { return wxAtof(Ymax->GetLabelText()); }
    float get_zmax()     { return wxAtof(Zmax->GetLabelText()); }
    float get_size()       { return wxAtof(Bsiz->GetLabelText()); }
    int get_illum()         { return wxAtoi(illum->GetLabelText()); }
    float get_col1R()      { return wxAtof(col1R->GetLabelText()); }
    float get_col1G()      { return wxAtof(col1G->GetLabelText()); }
    float get_col1B()      { return wxAtof(col1B->GetLabelText()); }
    float get_col2R()      { return wxAtof(col2R->GetLabelText()); }
    float get_col2G()      { return wxAtof(col2G->GetLabelText()); }
    float get_col2B()      { return wxAtof(col2B->GetLabelText()); }
    float get_col3R()      { return wxAtof(col3R->GetLabelText()); }
    float get_col3G()      { return wxAtof(col3G->GetLabelText()); }
    float get_col3B()      { return wxAtof(col3B->GetLabelText()); }
    float get_col4R()      { return wxAtof(col4R->GetLabelText()); }
    float get_col4G()      { return wxAtof(col4G->GetLabelText()); }
    float get_col4B()      { return wxAtof(col4B->GetLabelText()); }
    int get_m2()            { return wxAtoi(m2->GetLabelText()); }
    int get_m3()            { return wxAtoi(m3->GetLabelText()); }
    int get_d2()            { return wxAtoi(d2->GetLabelText()); }
    int get_d3()            { return wxAtoi(d3->GetLabelText()); }
    int get_d4()            { return wxAtoi(d4->GetLabelText()); }

protected:
    DECLARE_EVENT_TABLE()

private:
    wxTextCtrl *Xmin;
    wxTextCtrl *Xmax;
    wxTextCtrl *Ymin;
    wxTextCtrl *Ymax;
    wxTextCtrl *Zmin;
    wxTextCtrl *Zmax;
    wxTextCtrl *Bsiz;
    wxTextCtrl *illum;
    wxTextCtrl *m2;
    wxTextCtrl *m3;
    wxTextCtrl *d2;
    wxTextCtrl *d3;
    wxTextCtrl *d4;
    wxTextCtrl *col1R;
    wxTextCtrl *col2R;
    wxTextCtrl *col3R;
    wxTextCtrl *col4R;
    wxTextCtrl *col1G;
    wxTextCtrl *col2G;
    wxTextCtrl *col3G;
    wxTextCtrl *col4G;
    wxTextCtrl *col1B;
    wxTextCtrl *col2B;
    wxTextCtrl *col3B;
    wxTextCtrl *col4B;

    enum {
        ID_BUTTON_CLICK = wxID_HIGHEST+1
    };

};

#endif
