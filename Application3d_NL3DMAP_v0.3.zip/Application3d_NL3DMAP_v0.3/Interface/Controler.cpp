//#include <windows.h>

#include <vector>
#include <fstream>

#include "Controler.h"
#include "SObject3D.h"
#include "ReducMap.h"

//#include <string.h>
//#include "Export\gl2ps.h"

#include "LowRenderer.h"
#include "Parameters.h"

//#include <windows.h>
//#include <mmsystem.h>

class LowRenderer;

Controler::Controler() // contains object Data=data table from file
{
    data = (Data*)NULL;
    type =  MAP_UMAT;
}

void Controler::setData(Data* _data)
{
    data = _data;
    renderer3D->getLowRenderer()->constructColorMap();
//    renderer3D->getLowRenderer()->setConstants(Parameters::get_Xmin(), Parameters::get_Xmax(),
//                                                Parameters::get_Ymin(), Parameters::get_Ymax(),
//                                                Parameters::get_Zmin(), Parameters::get_Zmax());

    updateObjects3D_Data();
    updateObjects3D_Map();
    renderer3D->getLowRenderer()->setNeedUpdateAll();
}

void Controler::setMapType(MAP_TYPE _type)
{
    type =  type;
}

//Controler::Controler(Data* _data) // contains object Data=data table from file
//{
//    data = _data;
//    type =  MAP_DENS;//MAP_CENTER;
//}

void Controler::setRenderer3D(Renderer3D* _r3d)
{
    renderer3D=_r3d;
    updateObjects3D_Data();
    updateObjects3D_Map();
}

void Controler::updateObjects3D_Data()
{
    if (data!=(Data*)NULL)
    {
        int n=data->get_n();
        ReducMap* r = data->get_reducmap(type);
        float** data_proj = r->get_dataproj(0,1,2);
        float* min = r->get_min();
        float* max = r->get_max();
        int* data_cl=data->c_n;
        LowRenderer* _r=renderer3D->getLowRenderer();
        _r->updateObjects3D_Data(n,data_proj,min,max,data_cl,type,SPHERE);
    }
}

void Controler::updateObjects3D_Map()
{
    if (data!=(Data*)NULL)
    {
        ReducMap* r = data->get_reducmap(type);
        int n=data->get_n();
        int k=r->get_k();
        float** map = r->get_map(0,1,2);
        float* min = r->get_min();
        float* max = r->get_max();
        int* map_cl=NULL;
        int dim1=r->get_dim1();
        int dim2=r->get_dim2();
        LowRenderer* _r=renderer3D->getLowRenderer();
        _r->updateObjects3D_Map(n,k,dim1,dim2,map,min,max,map_cl,type,CUBE);
    }
}

//void Controler::save_snapshot() {
//        int state = GL2PS_OVERFLOW, buffsize = 0;
//        FILE *fp = fopen("out.eps", "wb");
//        printf("Writing 'out.eps'... ");
//        while(state == GL2PS_OVERFLOW){
//          buffsize += 1024*1024;
//          gl2psBeginPage("test", "gl2psTestSimple", NULL, GL2PS_EPS, GL2PS_SIMPLE_SORT,
//                         GL2PS_DRAW_BACKGROUND | GL2PS_USE_CURRENT_VIEWPORT,
//                         GL_RGBA, 0, NULL, 0, 0, 0, buffsize, fp, "out.eps");
//          renderer3D->display();
//          state = gl2psEndPage();
//        }
//        fclose(fp);
//        printf("Done!\n");
//
//}

void Controler::keyboard(long key)
{
//    static bool init_time=false;
//    static double time = -1;
//
//    if (!init_time) {
//      time=0.0f;//(double)timeGetTime();
//      init_time=true;
//    } else {
//      double new_time=0.0f;//(double)timeGetTime();
//      if (new_time-time<250)
//        {return;}
//      else
//        {time=new_time;}
//    }
//    key=toupper(key);
//    LowRenderer* r=renderer3D->getLowRenderer();
//    switch (key) /*MessageBox (NULL, "Key", "Key", 0);*/
//	{
//		case 27: {exit(0);break;}
//
//		case 'C': {r->paintColorObject3D = CLASS;
//                   r->setNeedUpdateOs3D(); break;}
//
//		case 'X': {r->paintColorObject3D = CLUSTER;
//                   r->setNeedUpdateOs3D(); break;}
//
//		case 'W': {r->paintColorObject3D = NONE;
//                   r->setNeedUpdateOs3D(); break;}
//
//    	case 'M': {r->paintMap           =! r->paintMap;                     break;}
//
//        case 'F': {r->paintNodeGrid      =! r->paintNodeGrid;                break;}
//
//        case 'P': {if (renderer3D->isSelected) renderer3D->isSelected=false; break;}
//
//        case 'G': {r->paintGrid          =! r->paintGrid;                    break;}
//
//        case 'H': {r->paintTextGrid      =! r->paintTextGrid;                break;}
//
//        case 'D': {r->paintData          =! r->paintData;                    break;}
//
//        case 'N': {r->paintNameObject3D  =! r->paintNameObject3D;            break;}
//
//        case 'R': {r->paintAxisXYZ       =! r->paintAxisXYZ;                 break;}
//
//        case 'K': {r->paintInPlaneXYZ    =! r->paintInPlaneXYZ;              break;}
//
//        case 'B': {r->paintOutBoxXYZ     =! r->paintOutBoxXYZ;               break;}
//
//        case 'Q': {r->paintColorMap      =! r->paintColorMap;                break;}
//
//    	case 'J': {r->paintColorGrid     =! r->paintColorGrid;
//                   r->setNeedUpdateMs3D(); break;}
//
//		case 'T':
//          {
//             /*MessageBox (NULL, "T", "T", 0);*/
//             LowRenderer* r = renderer3D->getLowRenderer();
//             r->updateAngle =! r->updateAngle;
//             if (!r->updateAngle)
//               {r->getTimer()->Pause();}
//             else if (r->getTimer()->hasBeenReset())
//               {r->getTimer()->Unpause();}
//             else
//               {r->getTimer()->Reset();}
//             break;
//          }
//
//		//case 'S': {save_snapshot();break;}
//
//		case 'w': {break;}//{wireframe = !wireframe;break;}
//	}
}

void Controler::special(int key)
{
//    static bool init_time=false;
//    static double time = -1;
//
//    if (!init_time) {
//      time=0.0f;//(double)timeGetTime();
//      init_time=true;
//    } else {
//      double new_time=0.0f;//(double)timeGetTime();
//      if (new_time-time<250)
//        {return;}
//      else
//        {time=new_time;}
//    }

//    LowRenderer* r=renderer3D->getLowRenderer();
//    switch (key)
//	{
//		case 27: {exit(0);break;}
//		case GLUT_KEY_F1:
//          {
//               if (type!=MAP_CENTER) {
//                 type = MAP_CENTER;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//          }
//		case GLUT_KEY_F2:
//          {
//               if (type!=MAP_UMAT) {
//                 type = MAP_UMAT;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//          }
//		case GLUT_KEY_F3:
//          {
//               if (type!=MAP_DENS) {
//                 type = MAP_DENS;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//          }
//		case GLUT_KEY_F4:
//          {
//               if (type!=MAP_ACP) {
//                 type = MAP_ACP;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//           }
//		case GLUT_KEY_F5:
//          {
//               if (r->allowHeighMap || r->allowColorMap) {
//                 r->allowHeighMap = false;
//                 r->allowColorMap = false;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//          }
//		case GLUT_KEY_F6:
//          {
//               if (r->allowHeighMap || !r->allowColorMap) {
//                 r->allowHeighMap = false;
//                 r->allowColorMap = true;
//                 updateObjects3D_Data();
//                 updateObjects3D_Map();
//               }
//               break;
//          }
//		case GLUT_KEY_F7:
//          {
//               r->allowHeighMap = true;
//               r->allowColorMap = true;
//               updateObjects3D_Data();
//               updateObjects3D_Map();
//               break;
//          }
//		case GLUT_KEY_F12: {renderer3D->fullScreenTogle();break;}
//	}
}

void Controler::mouse(int button, int state, int x, int y)
{
//    LowRenderer* r=renderer3D->getLowRenderer();
//    if(state == GLUT_DOWN)
//    {
//        renderer3D->mOldX = x;
//        renderer3D->mOldY = y;
//        switch(button)
//        {
//            case GLUT_LEFT_BUTTON:
//                if (glutGetModifiers() == GLUT_ACTIVE_CTRL)
//                {
//                   renderer3D->mButton = BUTTON_LEFT_TRANSLATE;
//                } else if (glutGetModifiers() == GLUT_ACTIVE_SHIFT)
//                {
//                   renderer3D->mode=SELECT;
//                   renderer3D->mButton=-1;
//                   //MessageBox (NULL, "Picking!", "HelloMsg", 0) ;
//                } else
//                {
//                   renderer3D->mButton = BUTTON_LEFT;
//
//                }
//             break;
//            case GLUT_RIGHT_BUTTON:
//                 if (glutGetModifiers() != GLUT_ACTIVE_SHIFT) {
//                   renderer3D->mButton = BUTTON_RIGHT;
//                 } else {
//                   renderer3D->mButton = -1;
//                 }
//                break;
//        }
//    } else if (state == GLUT_UP) {
//      renderer3D->mButton = -1;
//    }
}

void Controler::motion(int x, int y)
{
//    if (renderer3D->mButton == BUTTON_LEFT)
//    {
//        /* rotates screen */
//        renderer3D->rot[0] -= (renderer3D->mOldY - y);
//        renderer3D->rot[1] -= (renderer3D->mOldX - x);
//        clamp (renderer3D->rot);
//    }
//	else if (renderer3D->mButton == BUTTON_RIGHT)
//    {
//        /*
//           translate the screen, z axis
//           gives the idea of zooming in and out
//        */
//        renderer3D->eye[2] -= (renderer3D->mOldY - y) * 0.05f; // here I multiply by a 0.2 factor to
//                                      // slow down the zoom
//        clamp (renderer3D->rot);
//    }
//    else if (renderer3D->mButton == BUTTON_LEFT_TRANSLATE)
//    {
//        renderer3D->eye[0] += (renderer3D->mOldX - x) * 0.01f;
//        renderer3D->eye[1] -= (renderer3D->mOldY - y) * 0.01f;
//        clamp (renderer3D->rot);
//    }
//
//    renderer3D->mOldX = x;
//    renderer3D->mOldY = y;
}

