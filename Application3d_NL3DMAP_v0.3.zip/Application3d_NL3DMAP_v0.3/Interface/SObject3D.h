#ifndef SOBJECT3D_H
#define SOBJECT3D_H
#include "LowRenderer.h"
#include "LIBS.h"
#include "LIB3D.h"

class LowRenderer;

class SObject3D {
      
  public:
    SObject3D();
    ~SObject3D();
    void setName(char *_name);
    void setClass(int _labelclass);
    void setCluster(int _labelcluster);
    void setCenter(float _x, float _y, float _z);
    void setColor(float _Rc, float _Gc, float _Bc);
    void setType(OBJECT_TYPE _type);
    void setSize(float _size);
    void setLowRenderer(LowRenderer* _lr);
    void setMM(float min_x, float max_x,
               float min_y, float max_y, 
               float min_z, float max_z);

    void paint(OBJECT_COLOR _drawColor, bool _drawName, bool _useZ);
    void paintText(OBJECT_COLOR _drawColor, bool _useZ);                
    
    float get_x();
    float get_y();
    float get_z();
    float get_min_x();
    float get_min_y();
    float get_min_z();
    float get_max_x();
    float get_max_y();
    float get_max_z();
    
    int getNum() {return num;}
    void setNum(int _num) {num=num;}
    
  protected:
    OBJECT_TYPE type;
    int num;
    char* name;
    float size;       //size (/2 -> symmetric around c)
    float x;          //center x
    float y;          //center y
    float z;          //center z
    float Rc, Gc, Bc; // Color component
    int labelclass;
    int labelcluster;
    LowRenderer* lr;
    //bool drawname;
    float min_x, max_x, min_y, max_y, min_z, max_z;
    
};

#endif
