#ifndef _WX_DEBUGDIALOG_H_
#define _WX_DEBUGDIALOG_H_

// ------------- WX_LIB -------------------------------------------------------
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#if !wxUSE_GLCANVAS
#error "OpenGL required: set wxUSE_GLCANVAS to 1 and rebuild the library"
#endif

class DEBUGDIALOG
{
public:

    static void message()
    {
        wxMessageDialog dialog( NULL, _T("Test!"),
                                _T("!!!"), wxNO_DEFAULT|wxYES_NO|wxCANCEL|wxICON_INFORMATION);
        switch ( dialog.ShowModal() )
        {
        case wxID_YES:
            wxLogStatus(wxT("You pressed \"Yes\""));
            break;

        case wxID_NO:
            wxLogStatus(wxT("You pressed \"No\""));
            break;

        case wxID_CANCEL:
            wxLogStatus(wxT("You pressed \"Cancel\""));
            break;

        default:
            wxLogError(wxT("Unexpected wxMessageDialog return code!"));
        }
    }

};

#endif
