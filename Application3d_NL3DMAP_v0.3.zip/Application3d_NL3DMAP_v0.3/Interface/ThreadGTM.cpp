#include "ThreadGTM.h"

ThreadGTM::ThreadGTM(AppliFrame *frame)
        : wxThread()
{
//    m_count = 0;
    m_frame = frame;
}

void ThreadGTM::WriteText(const wxString& text)
{
    wxString msg;

    // before doing any GUI calls we must ensure that this thread is the only
    // one doing it!

    wxMutexGuiEnter();

    msg << text;
    //m_frame->WriteText(msg);

    wxMutexGuiLeave();
}

void ThreadGTM::OnExit()
{
//    wxCriticalSectionLocker locker(wxGetApp().m_critsect);

//    wxArrayThread& threads = wxGetApp().m_threads;
//    threads.Remove(this);
//
//    if ( threads.IsEmpty() )
//    {
//        // signal the main thread that there are no more threads left if it is
//        // waiting for us
//        if ( wxGetApp().m_waitingUntilAllDone )
//        {
//            wxGetApp().m_waitingUntilAllDone = false;
//
//            wxGetApp().m_semAllDone.Post();
//        }
//    }
}

void *ThreadGTM::Entry()
{
    int n_step=0;

    Data d;
    d.readData(nameFileData);
    GTM gtm(workDirectory);

    ofstream ou;
    char* nameFileLog=new char[256];
    strcpy(nameFileLog,workDirectory);
    strcat(nameFileLog,"gtmlog.txt");
    ou.open(nameFileLog);

    int dim1_W=dim1_W_init;
    int dim2_W=dim2_W_init;
    gtm.setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM,basistypeM);
    gtm.apprentissage_init(type_initW, nameFileInitW, false);
    if (evaluate_last>=0) {
        double Lg=gtm.apprentissage(-1);
        ou<<"MAP ["<<dim1_W<<"x"<<dim2_W<<"], L=" << Lg<<" Done!"<<endl;
    } else
        ou<<"MAP ["<<dim1_W<<"x"<<dim2_W<<"], Skip!"<<endl;

    wxCommandEvent event_init( wxEVT_COMMAND_MENU_SELECTED, WORKER_EVENT );
    event_init.SetInt(++n_step); // that's all
    wxPostEvent( m_frame, event_init );

    //m_frame->m_dlgProgress->Update(n_step++);

    int delta1=dim1_W_end-dim1_W_init;
    int delta2=dim2_W_end-dim2_W_init;
    int delta_max=delta1;
    if (delta2>delta1)
    {
        delta_max=delta2;
    }
    if (delta_max!=0)
    {
        for (int g=1; g<=delta_max; g++)
        {
            if (dim1_W+1<=dim1_W_end)
            {
                dim1_W++;
            }
            if (dim2_W+1<=dim2_W_end)
            {
                dim2_W++;
            }
            gtm.updateSizeVariables(dim1_W, dim2_W, sM);
            gtm.apprentissage_init(GTM::INIT_DONE, NULL, false);
            if (evaluate_last>=0) {
                double Lg=gtm.apprentissage(-1);
                ou<<"MAP ["<<dim1_W<<"x"<<dim2_W<<"], L=" << Lg<<" Done!"<<endl;
            } else
                ou<<"MAP ["<<dim1_W<<"x"<<dim2_W<<"], Skip!"<<endl;

            //m_frame->m_dlgProgress->Update(n_step++);

            ///?? m_frame->m_dlgProgress->Update(n_step++);

            wxCommandEvent event( wxEVT_COMMAND_MENU_SELECTED, WORKER_EVENT );
            event.SetInt(++n_step); // that's all
            wxPostEvent( m_frame, event );

        }
    }

    // size larger !!
    if (dim1_W_last!=dim1_W_end  || dim2_W_last!=dim2_W_end)
    {
        gtm.updateSizeVariables(dim1_W_last, dim2_W_last, sM);
        gtm.apprentissage_init(GTM::INIT_DONE, NULL, false);
        if (evaluate_last==1) {
            double Lg = gtm.apprentissage(-1);
                ou<<"MAP ["<<dim1_W_last<<"x"<<dim2_W_last<<"], L=" << Lg<<" Done!"<<endl;
        } else
                ou<<"MAP ["<<dim1_W_last<<"x"<<dim2_W_last<<"], Skip!"<<endl;
    }

    // final ACP map (good size!)
    gtm.calculer_mapping3D_all();
    gtm.sauvegarde();
    //gtm.recenterData();
    gtm.updateSizeVariables(dim1_W_last, dim2_W_last, sM);
    gtm.apprentissage_init(GTM::INIT_PCA, NULL, true); // PCA for last map

    // m_frame->m_dlgProgress->Update(n_step++);
//if (m_frame->m_dlgProgress!=NULL){
//       m_frame->m_dlgProgress->Show(false);
//}

//    wxCommandEvent event_last( wxEVT_COMMAND_MENU_SELECTED, WORKER_EVENT );
//    event_last.SetInt(++n_step); // that's all
//    wxPostEvent( m_frame, event_last );


    wxCommandEvent event_last( wxEVT_COMMAND_MENU_SELECTED, WORKER_EVENT );
    event_last.SetInt(-1); // that's all
    wxPostEvent( m_frame, event_last);

    //////m_frame->m_semAllDone->Post();

    //wxGetApp();
    //wxString text;

    //text.Printf(wxT("Thread 0x%lx started (priority = %u).\n"),
    //            GetId(), GetPriority());
    //WriteText(text);
    // wxLogMessage(text); -- test wxLog thread safeness

//    for ( m_count = 0; m_count < 10; m_count++ )
//    {
//        // check if we were asked to exit
//        if ( TestDestroy() )
//            break;
//
//        text.Printf(wxT("[%u] Thread 0x%lx here.\n"), m_count, GetId());
//        WriteText(text);
//
//        // wxSleep() can't be called from non-GUI thread!
//        wxThread::Sleep(1000);
//    }
//
//    text.Printf(wxT("Thread 0x%lx finished.\n"), GetId());
//    WriteText(text);
    // wxLogMessage(text); -- test wxLog thread safeness

    return NULL;
}

void ThreadGTM::InitValues(char *_workDirectory,
                           char* _nameFileData,
                           int _dim1_W_init, int _dim2_W_init,
                           int _dim1_W_end, int _dim2_W_end,
                           int _dim1_W_last, int _dim2_W_last,
                           int _evaluate_last,
                           int _dim1_M, int _dim2_M, double _sM,
                           GTM::BASIS_TYPE _basistypeM,
                           GTM::INIT_GTM _type_initW,
                           char* _nameFileInitW,
                           int _type_gtm, double _beta)
{
    workDirectory=_workDirectory;
    nameFileData=_nameFileData;
    dim1_W_init = _dim1_W_init;
    dim2_W_init = _dim2_W_init;
    dim1_W_end  = _dim1_W_end;
    dim2_W_end  = _dim2_W_end;
    dim1_W_last = _dim1_W_last;
    dim2_W_last = _dim2_W_last;
    dim1_M      = _dim1_M;
    dim2_M      = _dim2_M;
    sM          = _sM;
    basistypeM=_basistypeM;
    type_gtm    = _type_gtm;
    beta        = _beta;

    type_initW=_type_initW;
    nameFileInitW=_nameFileInitW;

    evaluate_last=_evaluate_last;
}
