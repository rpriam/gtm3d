#include "Renderer3D.h"

#include "..\Interface\text\bitmap_fonts.h"

#define BUFSIZE 1024

unsigned long  Renderer3D::m_secbase = 0;
int            Renderer3D::m_TimeInitialized = 0;
unsigned long  Renderer3D::m_xsynct;
unsigned long  Renderer3D::m_gsynct;

#include "..\AppliFrame.h";

class AppliFrame;

Renderer3D::Renderer3D(wxWindow *parent, wxWindowID id,
                       const wxPoint& pos, const wxSize& size, long style, const wxString& name)
        : wxGLCanvas(parent, (wxGLCanvas*) NULL, id, pos, size, style|wxFULL_REPAINT_ON_RESIZE , name )
{
    m_init = false;
    //m_gllist = 0;

    selectBuf=new GLuint[BUFSIZE];
    mode = RENDER;
    isSelected=false;
    objectSelected=0;

    //mButton = -1;
    eye[0]=0.0f;
    eye[1]=0.0f;
    eye[2]=15.0f;
    rot[0]=0.0f;//34.0f+115.0f;
    rot[1]=0.0f;//-106.0f-90.0f;
    rot[2]=0.0f;
} // constructor 1 (see below for the constructor 2

Renderer3D::Renderer3D(wxWindow *parent, const Renderer3D *other,
                       wxWindowID id, const wxPoint& pos, const wxSize& size, long style,
                       const wxString& name )
        : wxGLCanvas(parent, other->GetContext(), id, pos, size, style|wxFULL_REPAINT_ON_RESIZE , name)
{
    m_init = false;
    //m_gllist = other->m_gllist; // share display list
    //m_rleft = WXK_LEFT;
    //m_rright = WXK_RIGHT;

    selectBuf=new GLuint[BUFSIZE];
    mode = RENDER;
    isSelected=false;
    objectSelected=0;

    //mButton = -1;
    eye[0]=0.0f;
    eye[1]=0.0f;
    eye[2]=15.0f;
    rot[0]=34.0f;
    rot[1]=-106.0f;
    rot[2]=0.0f;
} // constructor 2 (see above for the constructor 1)

Renderer3D::~Renderer3D()
{
}

void Renderer3D::Render()
{
    wxPaintDC dc(this);
#ifndef __WXMOTIF__
    if (!GetContext()) return;
#endif
    SetCurrent();
    // Init OpenGL once, but after SetCurrent
    if (!m_init)
    {
        InitGL();
        m_init = true;
    }


    //int w, h; GetClientSize(&w, &h);//SetCurrent(); glViewport(0, 0, (GLint) w, (GLint) h);
    //setViewport(w, h);

    // clear buffer
    //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    if (mode == SELECT) {
        isSelected=true;
		beginPicking();
	}

    // tramsform camera
    //glTranslatef(0, 0, cameraDistance);
    //glRotatef(cameraAngleX, 1, 0, 0);   // pitch
    //glRotatef(cameraAngleY, 0, 1, 0);   // heading

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    // save the initial ModelView matrix before modifying ModelView matrix
    glPushMatrix();

    glTranslatef (-eye[0], -eye[1], -eye[2]);
    glRotatef(rot[0], 1.0f, 0.0f, 0.0f);
    glRotatef(rot[1], 0.0f, 1.0f, 0.0f);
    glRotatef(rot[2], 0.0f, 0.0f, 1.0f);

    if (lowrenderer!=(LowRenderer*)NULL)
    {
        lowrenderer->DrawScene(isSelected);
    }

    glPopMatrix();
// ---------------------------------------------

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, 1.0, 0.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glPushAttrib(GL_COLOR_BUFFER_BIT);       /* save current colour */
    //glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
    //glPolygonMode( GL_FRONT, GL_FILL );

    glPopAttrib();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

// ----------------------------------------------

    if (lowrenderer!=(LowRenderer*)NULL)
    {
        if (lowrenderer->paintColorMap)
        {
            drawColorMap(NULL);
        }
    }


    beginRenderText( width, height );
    {
        glColor3f( 1.0f, 1.0f, 1.0f );
//		renderText( 15, height-20, BITMAP_FONT_TYPE_HELVETICA_12, "test" );
//		renderText( 40, height-20, BITMAP_FONT_TYPE_HELVETICA_12, "??" );
//	}
//	endRenderText();

        if (lowrenderer->paintInformations)
        {
            if (lowrenderer->allowHeighMap)
            {
                if (controler->getType()==MAP_CENTER)
                {
                    sprintf(text_params,"Map: XYZ+GTM 3d");
                }
                else if (controler->getType()==MAP_UMAT)
                {
                    sprintf(text_params,"Map: Umatrix 3d");
                }
                else if (controler->getType()==MAP_DENS)
                {
                    sprintf(text_params,"Map: Density 3d");
                }
                else if (controler->getType()==MAP_ACP)
                {
                    sprintf(text_params,"Map: XYZ+ACP 3d");
                }
            }
            else
            {
                if (controler->getType()==MAP_CENTER)
                {
                    sprintf(text_params,"Map: XYZ+GTM 2d");
                }
                else if (controler->getType()==MAP_UMAT)
                {
                    sprintf(text_params,"Map: Umatrix 2d");
                }
                else if (controler->getType()==MAP_DENS)
                {
                    sprintf(text_params,"Map: Density 2d");
                }
                else if (controler->getType()==MAP_ACP)
                {
                    sprintf(text_params,"Map: XYZ+ACP 2d");
                }
            }
            renderText( 10, 10, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "nD=%d", controler->get_data_n());
            renderText( width-50, 20, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "pD=%d", controler->get_data_p());
            renderText( width-50, 35, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "kM=%d", controler->get_map_k());
            renderText( width-50, 50, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "pM=%d", controler->get_map_p());
            renderText( width-50, 65, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "xM=%d", controler->get_map_dim1());
            renderText( width-50, 80, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "yM=%d", controler->get_map_dim2());
            renderText( width-50, 95, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "xL=%d", controler->get_map_dim1M());
            renderText( width-50, 110, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "yL=%d", controler->get_map_dim2M());
            renderText( width-50, 125, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            sprintf(text_params, "sL=%4.2f", controler->get_map_sM());
            renderText( width-50, 140, BITMAP_FONT_TYPE_HELVETICA_12, text_params );

            if (isSelected) {
                sprintf(text_params, "pK=%d ", objectSelected);
            } else
            {
                sprintf(text_params, "pK=0", objectSelected);
            }
            renderText( width-50, 170, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
        }
        if (lowrenderer->paintKeyHelp)
        {
            sprintf(text_params, "Key Z  : parameters setting");
            renderText( 10, height-12, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key M  : map draw swap");
            renderText( 10, height-24, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key G  : mesh draw swap");
            renderText( 10, height-36, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key J  : color mesh swap");
            renderText( 10, height-48, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key A  : axis draw swap");
            renderText( 10, height-60, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key K  : planes draw swap");
            renderText( 10, height-72, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key B  : box draw swap");
            renderText( 10, height-84, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key D  : data draw swap");
            renderText( 10, height-96, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key C  : label color data");
            renderText( 10, height-108, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F1 : data+map");
            renderText( 10, height-120, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F2 : umatrix map");
            renderText( 10, height-132, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F3 : density map");
            renderText( 10, height-144, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F4 : pca map");
            renderText( 10, height-156, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F5 : cancel color map");
            renderText( 10, height-168, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F6 : cancel heigth map");
            renderText( 10, height-180, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key F7 : allow heigth map");
            renderText( 10, height-192, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key I   : informations data");
            renderText( 10, height-204, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
            sprintf(text_params, "Key H  : help key");
            renderText( 10, height-216, BITMAP_FONT_TYPE_HELVETICA_12, text_params );
        }

/// Picking to be added
    }
    endRenderText();

    if (mode == SELECT) {
        isSelected=true;
		beginPicking();
	}

    //glFlush();
    SwapBuffers();
}

void Renderer3D::drawColorMap(void *font)
{

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, 1.0, 0.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glPushAttrib(GL_COLOR_BUFFER_BIT);       /* save current colour */
    glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
    glPolygonMode( GL_FRONT, GL_FILL );
    glBegin( GL_QUADS );
    for (int m=0;m<64;m++)
    {
        glColor3f(lowrenderer->getColR(m),
                  lowrenderer->getColG(m),
                  lowrenderer->getColB(m));
        glVertex2f( 0.01, 0.03+((float)(63-m))/70);
        glVertex2f( 0.01, 0.03+((63-m)+1.0f)/70);
        glVertex2f( 0.05, 0.03+((63-m)+1.0f)/70);
        glVertex2f( 0.05, 0.03+((float)(63-m))/70);
    }
    glEnd();

    glPopAttrib();

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
}

void Renderer3D::InitGL()
{
    SetCurrent();

    //glShadeModel(GL_SMOOTH);                        // shading mathod: GL_SMOOTH or GL_FLAT
    //glPixelStorei(GL_UNPACK_ALIGNMENT, 4);          // 4-byte pixel alignment

    // enable /disable features
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_DEPTH_TEST);
    glClearDepth(1.0f);                             // 0 is near, 1 is far
    //glDepthFunc(GL_LESS);
    glDepthFunc(GL_LEQUAL);

    //glEnable(GL_LIGHTING);
    //glEnable(GL_TEXTURE_2D);
    //glEnable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // track material ambient and diffuse from surface color, call it before glEnable(GL_COLOR_MATERIAL)
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);

    glClearColor(0.4, 0.4, 0.4, 0.0);                       // background color
    //glClearStencil(0);                              // clear stencil buffer

    //initLights();
    //glEnable(GL_TEXTURE_2D);
}

void Renderer3D::initCL(Controler* _c, LowRenderer* _l)
{
    controler = _c;
    lowrenderer = _l;
}

LowRenderer* Renderer3D::getLowRenderer()
{
    return lowrenderer;
}

Controler* Renderer3D::getControler()
{
    return controler;
}

void Renderer3D::beginPicking()
{
    GLint viewport[4];
    glSelectBuffer(BUFSIZE,selectBuf);
    glGetIntegerv(GL_VIEWPORT,viewport);
    glRenderMode(GL_SELECT);
    glInitNames();
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluPickMatrix(mOldX,viewport[3]-mOldY,5,5,viewport);
    float ratio = (viewport[2]+0.0) / viewport[3];
    gluPerspective(45,ratio,0.1,1000);
    glMatrixMode(GL_MODELVIEW);

    for (int o=0; o<BUFSIZE;o++)
    {
        selectBuf[o]=0;
    }
    objectSelected=0;
    isSelected=false;
}

void Renderer3D::finishPicking()
{
    int choose = selectBuf[3];
    int depth = selectBuf[1];

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glFlush();
    hits = glRenderMode(GL_RENDER);
    if (hits != 0)
    {
        for (int loop = 1; loop < hits; loop++)
        {
            if (selectBuf[loop+1] < GLuint(depth))
            {
                choose = selectBuf[loop+1];
                depth = selectBuf[loop+1];
            }
        }
        objectSelected=choose;
        isSelected=true;
    }
    mode = RENDER;
}

void Renderer3D::OnEnterWindow( wxMouseEvent& WXUNUSED(event) )
{
    SetFocus();
}

void Renderer3D::OnPaint( wxPaintEvent& WXUNUSED(event) )
{
    Render();
}

void Renderer3D::OnSize(wxSizeEvent& event)
{
    // this is also necessary to update the context on some platforms
    wxGLCanvas::OnSize(event);

    // set GL viewport (not called by wxGLCanvas::OnSize on all platforms...)
    int w, h;
    GetClientSize(&w, &h);
#ifndef __WXMOTIF__
    if (GetContext())
#endif
    {
        SetCurrent();
        setViewport(w, h);//glViewport(0, 0, (GLint) w, (GLint) h);
    }
}

void Renderer3D::OnEraseBackground(wxEraseEvent& WXUNUSED(event))
{
    // Do nothing, to avoid flashing.
}

void Renderer3D::OnKeyDown( wxKeyEvent& event )
{
    long code = event.GetKeyCode();
    if (code == 0) return;
    //GLfloat angle = CalcRotateAngle( lasttime, acceltime );
    //clamp(angle);

    switch (code)
    {
    case WXK_PAGEUP:
    {
        //Rotate( angle );
        rot[2] += 2.0f;
        break;
    }
    case WXK_PAGEDOWN:
    {
        //Rotate( angle );
        rot[2] -= 2.0f;
        break;
    }
    case WXK_LEFT:
    {
        //Rotate( angle );
        rot[1] += 2.0f;
        break;
    }
    case WXK_RIGHT:
    {
        //Rotate( -angle );
        rot[1] -= 2.0f;
        break;
    }
    case WXK_UP:
    {
        //Rotate( -angle );
        rot[0] += 2.0f;
        break;
    }
    case WXK_DOWN:
    {
        //Rotate( -angle );
        rot[0] -= 2.0f;
        break;
    }
    case WXK_ESCAPE:
    {
        exit(0);
        break;
    }

    case 'C':
    {
        lowrenderer->paintColorObject3D = CLASS;
        lowrenderer->setNeedUpdateOs3D();
        break;
    }

    case 'X':
    {
        lowrenderer->paintColorObject3D = CLUSTER;
        lowrenderer->setNeedUpdateOs3D();
        break;
    }

    case 'W':
    {
        lowrenderer->paintColorObject3D = NONE;
        lowrenderer->setNeedUpdateOs3D();
        break;
    }

    case 'M':
    {
        lowrenderer->paintMap =! lowrenderer->paintMap;
        break;
    }

    case 'F':
    {
        lowrenderer->paintNodeGrid =! lowrenderer->paintNodeGrid;
        break;
    }

    case 'P':
    {
       isSelected = !isSelected;
        break;
    }

    case 'G':
    {
        lowrenderer->paintGrid =! lowrenderer->paintGrid;
        break;
    }

    case 'T':
    {
        lowrenderer->paintTextGrid =! lowrenderer->paintTextGrid;
        break;
    }

    case 'D':
    {
        lowrenderer->paintData =! lowrenderer->paintData;
        break;
    }

    case 'N':
    {
        lowrenderer->paintNameObject3D =! lowrenderer->paintNameObject3D;
        break;
    }

    case 'A':
    {
        lowrenderer->paintAxisXYZ =! lowrenderer->paintAxisXYZ;
        break;
    }

    case 'K':
    {
        lowrenderer->paintInPlaneXYZ =! lowrenderer->paintInPlaneXYZ;
        break;
    }

    case 'B':
    {
        lowrenderer->paintOutBoxXYZ =! lowrenderer->paintOutBoxXYZ;
        break;
    }

    case 'Q':
    {
        lowrenderer->paintColorMap =! lowrenderer->paintColorMap;
        break;
    }

    case 'H':
    {
        lowrenderer->paintKeyHelp =! lowrenderer->paintKeyHelp;
        break;
    }

    case 'I':
    {
        lowrenderer->paintInformations =! lowrenderer->paintInformations;
        break;
    }

    case 'J':
    {
        lowrenderer->paintColorGrid =! lowrenderer->paintColorGrid;
        lowrenderer->setNeedUpdateMs3D();
        break;
    }

    case 'Z':
    {
        if (!controler->isDataNull())
        {
            ((AppliFrame*)this->GetParent())->updateParameters();
        }
        break;
    }

    case 'R':
    {
        /*MessageBox (NULL, "T", "T", 0);*/
//            LowRenderer* r = renderer3D->getLowRenderer();
//            r->updateAngle =! r->updateAngle;
//            if (!r->updateAngle)
//            {
//                r->getTimer()->Pause();
//            }
//            else if (r->getTimer()->hasBeenReset())
//            {
//                r->getTimer()->Unpause();
//            }
//            else
//            {
//                r->getTimer()->Reset();
//            }
        break;
    }

    //case 'S': {save_snapshot();break;}

    case 'w':
    {
        break;
    }//{wireframe = !wireframe;break;}

    case WXK_F1:
    {
        if (controler->type!=MAP_CENTER)
        {
            controler->type = MAP_CENTER;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F2:
    {
        if (controler->type!=MAP_UMAT)
        {
            controler->type = MAP_UMAT;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F3:
    {
        if (controler->type!=MAP_DENS)
        {
            controler->type = MAP_DENS;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F4:
    {
        if (controler->type!=MAP_ACP)
        {
            controler->type = MAP_ACP;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F5:
    {
        if (lowrenderer->allowHeighMap || lowrenderer->allowColorMap)
        {
            //lowrenderer->allowHeighMap = false;
            lowrenderer->allowColorMap = false;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F6:
    {
        if (lowrenderer->allowHeighMap || !lowrenderer->allowColorMap)
        {
            lowrenderer->allowHeighMap = false;
            lowrenderer->allowColorMap = true;
            controler->updateObjects3D_Data();
            controler->updateObjects3D_Map();
        }
        break;
    }
    case WXK_F7:
    {
        lowrenderer->allowHeighMap = true;
        lowrenderer->allowColorMap = true;
        controler->updateObjects3D_Data();
        controler->updateObjects3D_Map();
        break;
    }
    //case GLUT_KEY_F12: //{renderer->fullScreenTogle();break;}
    }

    Refresh(false);
    event.Skip();
}

void Renderer3D::OnKeyUp( wxKeyEvent& event )
{
    m_Key = 0;
    m_StartTime = 0;
    m_LastTime = 0;
    m_LastRedraw = 0;

    event.Skip();
}

void Renderer3D::OnMouseEvent(wxMouseEvent& event)
{
    //static int dragging = 0;
    static float last_x, last_y;

    //printf("%f %f %d\n", event.GetX(), event.GetY(), (int)event.LeftIsDown());
    if (event.LeftIsDown())
    {
        if (abs(mOldY - event.GetY())>2)
        {
            rot[0] -= (mOldY - event.GetX())*0.05f;
            rot[1] -= (mOldX - event.GetY())*0.05f;
            clamp (rot);
            Refresh(false);
        }
    }
    else if (event.RightIsDown())
    {
        if (abs(mOldY - event.GetY())>2)
        {
            eye[2] -= (mOldY - event.GetY()) * 0.05f; // here I multiply by a 0.2 factor to
            clamp (rot);
            Refresh(false);
        }
    }

    mOldX=event.GetX();
    mOldY=event.GetY();

    event.Skip();
}

void Renderer3D::clamp(float *v)
{
    int i;

    for (i = 0; i < 3; i ++)
        if (v[i] > 360 || v[i] < -360)
            v[i] = 0;
}


void Renderer3D::initLights()
{
    // set up light colors (ambient, diffuse, specular)
    GLfloat lightKa[] = {.2f, .2f, .2f, 1.0f};      // ambient light
    GLfloat lightKd[] = {.7f, .7f, .7f, 1.0f};      // diffuse light
    GLfloat lightKs[] = {1, 1, 1, 1};               // specular light
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);

    // position the light
    float lightPos[4] = {0, 0, 20, 1}; // positional light
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    glEnable(GL_LIGHT0);                            // MUST enable each light source after configuration
}

void Renderer3D::setViewport(int w, int h)
{
    height=h;
    width=w;
    // set viewport to be the entire window
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);

    // set perspective viewing frustum
    float aspectRatio = (float)w / h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(50.0f, (float)(w)/h, 0.1f, 20.0f); // FOV, AspectRatio, NearClip, FarClip

    // switch to modelview matrix in order to set scene
    glMatrixMode(GL_MODELVIEW);
}

// ________________________________________

BEGIN_EVENT_TABLE(Renderer3D, wxGLCanvas)
    EVT_SIZE(Renderer3D::OnSize)
    EVT_PAINT(Renderer3D::OnPaint)
    EVT_ERASE_BACKGROUND(Renderer3D::OnEraseBackground)
    EVT_KEY_DOWN( Renderer3D::OnKeyDown )
    EVT_KEY_UP( Renderer3D::OnKeyUp )
    EVT_MOUSE_EVENTS(Renderer3D::OnMouseEvent)
    EVT_ENTER_WINDOW( Renderer3D::OnEnterWindow )
END_EVENT_TABLE()


//    LowRenderer* r=renderer3D->getLowRenderer();
//    if(state == GLUT_DOWN)
//    {
//        renderer3D->mOldX = x;
//        renderer3D->mOldY = y;
//        switch(button)
//        {
//            case GLUT_LEFT_BUTTON:
//                if (glutGetModifiers() == GLUT_ACTIVE_CTRL)
//                {
//                   renderer3D->mButton = BUTTON_LEFT_TRANSLATE;
//                } else if (glutGetModifiers() == GLUT_ACTIVE_SHIFT)
//                {
//                   renderer3D->mode=SELECT;
//                   renderer3D->mButton=-1;
//                   //MessageBox (NULL, "Picking!", "HelloMsg", 0) ;
//                } else
//                {
//                   renderer3D->mButton = BUTTON_LEFT;
//
//                }
//             break;
//            case GLUT_RIGHT_BUTTON:
//                 if (glutGetModifiers() != GLUT_ACTIVE_SHIFT) {
//                   renderer3D->mButton = BUTTON_RIGHT;
//                 } else {
//                   renderer3D->mButton = -1;
//                 }
//                break;
//        }
//    } else if (state == GLUT_UP) {
//      renderer3D->mButton = -1;
//    }

//    if (renderer3D->mButton == BUTTON_LEFT)
//    {
//        /* rotates screen */
//        renderer3D->rot[0] -= (renderer3D->mOldY - y);
//        renderer3D->rot[1] -= (renderer3D->mOldX - x);
//        clamp (renderer3D->rot);
//    }
//	else if (renderer3D->mButton == BUTTON_RIGHT)
//    {
//        /*
//           translate the screen, z axis
//           gives the idea of zooming in and out
//        */
//        renderer3D->eye[2] -= (renderer3D->mOldY - y) * 0.05f; // here I multiply by a 0.2 factor to
//                                      // slow down the zoom
//        clamp (renderer3D->rot);
//    }
//    else if (renderer3D->mButton == BUTTON_LEFT_TRANSLATE)
//    {
//        renderer3D->eye[0] += (renderer3D->mOldX - x) * 0.01f;
//        renderer3D->eye[1] -= (renderer3D->mOldY - y) * 0.01f;
//        clamp (renderer3D->rot);
//    }
//
//    renderer3D->mOldX = x;
//    renderer3D->mOldY = y;
//}

/*----------------------------------------------------------------------
  Utility function to get the elapsed time (in msec) since a given point
  in time (in sec)  (because current version of wxGetElapsedTime doesn�t
  works right with glibc-2.1 and linux, at least for me)
-----------------------------------------------------------------------*/
unsigned long Renderer3D::StopWatch( unsigned long *sec_base )
{
    unsigned long secs,msec;

#if defined(__WXMSW__)
    struct timeb tb;
    ftime( &tb );
    secs = tb.time;
    msec = tb.millitm;
#elif defined(__WXMAC__) && !defined(__DARWIN__)
    wxLongLong tl = wxGetLocalTimeMillis();
    secs = (unsigned long) (tl.GetValue() / 1000);
    msec = (unsigned long) (tl.GetValue() - secs*1000);
#else
    // think every unice has gettimeofday
    struct timeval tv;
    gettimeofday( &tv, (struct timezone *)NULL );
    secs = tv.tv_sec;
    msec = tv.tv_usec/1000;
#endif

    if ( *sec_base == 0 )
        *sec_base = secs;

    return( (secs-*sec_base)*1000 + msec );
}
