#ifndef TIMER_H
#define TIMER_H

//#include <windows.h>
//#include <mmsystem.h>

class Timer
{
public:
	Timer() : isPaused(false)
	{ startTime=0; }
	~Timer()	{}

	void Reset();
	double GetTime();
	void Pause();
	void Unpause();
    bool hasBeenReset();

protected:
	bool isPaused;
	double pauseTime;
	double startTime;
};

#endif	//TIMER_H

