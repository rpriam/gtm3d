#include "CreateFileIniGTMDialog.h"

CreateFileIniGTMDialog::CreateFileIniGTMDialog( wxWindow* parent, const wxString& title )
        : wxDialog(parent, -1, title, wxDefaultPosition, wxDefaultSize,wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER)
{
    // Constructing a vertical sizer
    wxBoxSizer *dialogSizer = new wxBoxSizer(wxVERTICAL);

    nameFileData=new wxTextCtrl(this, -1);
    nameFileLabel=new wxTextCtrl(this, -1);
    dim1_W_init=new wxTextCtrl(this, -1);
    dim2_W_init=new wxTextCtrl(this, -1);
    dim1_W_end=new wxTextCtrl(this, -1);
    dim2_W_end=new wxTextCtrl(this, -1);
    dim1_W_last=new wxTextCtrl(this, -1);
    dim2_W_last=new wxTextCtrl(this, -1);
    evaluate_last=new wxTextCtrl(this, -1);
    dim1_M=new wxTextCtrl(this, -1);
    dim2_M=new wxTextCtrl(this, -1);
    sM=new wxTextCtrl(this, -1);
    type_basis=new wxTextCtrl(this, -1);
    type_init=new wxTextCtrl(this, -1);
    name_file_init=new wxTextCtrl(this, -1);
    type_gtm=new wxTextCtrl(this, -1);
    beta=new wxTextCtrl(this, -1);

    // Constructing a grid sizer with 2 rows and 2 columns (use 10 pixels
    //wxFlexGridSizer *textSizer = new wxFlexGridSizer(13, 2, 10, 10);
    wxFlexGridSizer *textSizer = new wxFlexGridSizer(17, 2, 10, 10);

    // Adding static text control
    textSizer->Add(new wxStaticText(this, -1, wxT("Name file data ")), 1, wxEXPAND);
    textSizer->Add(nameFileData, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("Name file label ")), 1, wxEXPAND);
    textSizer->Add(nameFileLabel, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("dim1_W_init ")), 1, wxEXPAND);
    textSizer->Add(dim1_W_init, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("dim2_W_init ")), 1, wxEXPAND);
    textSizer->Add(dim2_W_init, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("dim1_W_end ")), 1, wxEXPAND);
    textSizer->Add(dim1_W_end, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("dim2_W_end ")), 1, wxEXPAND);
    textSizer->Add(dim2_W_end, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("dim1_W_last ")), 1, wxEXPAND);
    textSizer->Add(dim1_W_last, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("dim2_W_last ")), 1, wxEXPAND);
    textSizer->Add(dim2_W_last, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("evaluate last ")), 1, wxEXPAND);
    textSizer->Add(evaluate_last, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("dim1_M ")), 1, wxEXPAND);
    textSizer->Add(dim1_M, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("dim2_M ")), 1, wxEXPAND);
    textSizer->Add(dim2_M, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("sM ")), 1, wxEXPAND);
    textSizer->Add(sM, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("basis type ")), 1, wxEXPAND);
    textSizer->Add(type_basis, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("init type ")), 1, wxEXPAND);
    textSizer->Add(type_init, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("file init ")), 1, wxEXPAND);
    textSizer->Add(name_file_init, 1, wxEXPAND);

    textSizer->Add(new wxStaticText(this, -1, wxT("opt1 ")), 1, wxEXPAND);
    textSizer->Add(type_gtm, 1, wxEXPAND);
    textSizer->Add(new wxStaticText(this, -1, wxT("opt1 ")), 1, wxEXPAND);
    textSizer->Add(beta, 1, wxEXPAND);

    // Adding button control
    wxButton *button = new wxButton(this, ID_BUTTON_CLICK, wxT("OK"));
    dialogSizer->Add(textSizer, 0, wxALIGN_CENTER);
    dialogSizer->Add(button,
        0, // make vertically unstretchable
        wxALIGN_CENTER | wxALL, 10); // centre horizontally and set border width to 10

    SetSizer(dialogSizer); // Use dialog sizer for layout
    dialogSizer->Fit(this); // Fit dialog to components
}

BEGIN_EVENT_TABLE(CreateFileIniGTMDialog, wxDialog)
EVT_BUTTON(ID_BUTTON_CLICK, CreateFileIniGTMDialog::OnButtonClick)
END_EVENT_TABLE()

void CreateFileIniGTMDialog::OnButtonClick(wxCommandEvent &event) {
 this->Show(false);
}
