#include "SObject3D.h"
#include <fstream>

SObject3D::SObject3D() {
   labelclass=-1;
   labelcluster=-1;
   name=NULL;
   //drawname=false;
}

SObject3D::~SObject3D() {
   if (name!=NULL) delete [] name;
}

void SObject3D::setName(char *_name) {
     name = _name;
}

void SObject3D::setCenter(float _x, float _y, float _z) {
     x=_x;
     y=_y;
     z=_z;
}

void SObject3D::setType(OBJECT_TYPE _type) {
     type=_type;
}

void SObject3D::setSize(float _size) {
     size=_size;
}

void SObject3D::setClass(int _labelclass) {
     if (_labelclass<0)
        labelclass=-1;
     else
        labelclass=_labelclass;
}

void SObject3D::setCluster(int _labelcluster) {
     if (_labelcluster<0)
        labelcluster=-1;
     else
         labelcluster=_labelcluster;
}

void SObject3D::setColor(float _Rc, float _Gc, float _Bc) {
     Rc=_Rc;
     Gc=_Gc;
     Bc=_Bc;
}

void SObject3D::setLowRenderer(LowRenderer* _lr) {
     lr=_lr;
}

void SObject3D::paint(OBJECT_COLOR _drawColor, bool _drawName, bool _useZ) {
 float _Rc=Rc, _Gc=Gc, _Bc=Bc;
 //static float posy=(float)rand()/(1+RAND_MAX)*1;
 //static float posz=(float)rand()/(1+RAND_MAX)*1;

 if (_drawColor==CLASS || _drawColor==CLUSTER) {
     int labc;
     if (_drawColor==CLASS) {
       labc=labelclass;
     } else {
       labc=labelcluster;
     }
     if (labc>=0) {
       switch(labc) {
         case 0 : _Rc=1.0f, _Gc=1.0f, _Bc=1.0f; break;
         case 1 : _Rc=1.0f, _Gc=0.0f, _Bc=0.0f;break;
         case 2 : _Rc=0.0f, _Gc=1.0f, _Bc=0.0f;break;
         case 3 : _Rc=0.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 4 : _Rc=1.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 5 : _Rc=0.0f, _Gc=1.0f, _Bc=1.0f;break;
         case 6 : _Rc=1.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 7 : _Rc=1.0f, _Gc=1.0f, _Bc=0.0f;break;
         otherwise : _Rc=0.5f, _Gc=0.5f, _Bc=0.5f;
       }
     }
 } else {
     //_Rc=0.5f, _Gc=0.5f, _Bc=0.5f;
 }

 if (lr!=NULL) {
   float xx, yy, zz, xx1, yy1, zz1, xx2, yy2, zz2;
   xx=lr->normalizeX(x,min_x,max_x);
   yy=lr->normalizeY(y,min_y,max_y);
   zz=lr->normalizeZ(z,min_z,max_z);
   if (!_useZ) zz=0.0f;

   if (type==SPHERE) {
      LIB3D::drawSphere2(xx, yy, zz+0.05, size/2,
                     _Rc, _Gc, _Bc);
   } else if (type==CUBE){
      LIB3D::drawTetrahed(xx-size/3, xx+size/3,
                       yy-size/3, yy+size/3,
                       zz+0.05-size/3, zz+0.05+size/3,
                       _Rc, _Gc, _Bc, 0.0f);
   }
   if (_drawName) {
//     LIB3D::drawStringText(name, xx, yy, zz+size/2+0.1, _Rc, _Gc, _Bc);
   }
 }
}

void SObject3D::paintText(OBJECT_COLOR _drawColor, bool _useZ) {
 float _Rc=Rc, _Gc=Gc, _Bc=Bc;
 //static float posy=(float)rand()/(1+RAND_MAX)*1;
 //static float posz=(float)rand()/(1+RAND_MAX)*1;

 if (_drawColor==CLASS || _drawColor==CLUSTER) {
     int labc;
     if (_drawColor==CLASS) {
       labc=labelclass;
     } else {
       labc=labelcluster;
     }
     if (labc>=0) {
       switch(labc) {
         case 0 : _Rc=1.0f, _Gc=1.0f, _Bc=1.0f; break;
         case 1 : _Rc=1.0f, _Gc=0.0f, _Bc=0.0f;break;
         case 2 : _Rc=0.0f, _Gc=1.0f, _Bc=0.0f;break;
         case 3 : _Rc=0.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 4 : _Rc=1.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 5 : _Rc=0.0f, _Gc=1.0f, _Bc=1.0f;break;
         case 6 : _Rc=1.0f, _Gc=0.0f, _Bc=1.0f;break;
         case 7 : _Rc=1.0f, _Gc=1.0f, _Bc=0.0f;break;
         otherwise : _Rc=0.5f, _Gc=0.5f, _Bc=0.5f;
       }
     }
 } else {
     _Rc=0.5f, _Gc=0.5f, _Bc=0.5f;
 }

 if (lr!=NULL) {
   float xx, yy, zz, xx1, yy1, zz1, xx2, yy2, zz2;
   xx=lr->normalizeX(x,min_x,max_x);
   yy=lr->normalizeY(y,min_y,max_y);
   zz=lr->normalizeZ(z,min_z,max_z);
   if (!_useZ) zz=0.0f;
//   LIB3D::drawStringText(name, xx, yy, zz+size/2+0.1, _Rc, _Gc, _Bc);
 }
}

void SObject3D::setMM(float _min_x, float _max_x,
                      float _min_y, float _max_y,
                      float _min_z, float _max_z) {
 min_x = _min_x;
 max_x = _max_x;
 min_y = _min_y;
 max_y = _max_y;
 min_z = _min_z;
 max_z = _max_z;
}

float SObject3D::get_x() {
  return x;
}

float SObject3D::get_y() {
  return y;
}

float SObject3D::get_z() {
  return z;
}

float SObject3D::get_min_x() {
  return min_x;
}

float SObject3D::get_min_y() {
  return min_y;
}

float SObject3D::get_min_z() {
  return min_z;
}

float SObject3D::get_max_x() {
  return max_x;
}

float SObject3D::get_max_y() {
  return max_y;
}

float SObject3D::get_max_z() {
  return max_z;
}
