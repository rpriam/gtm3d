#ifndef LIB3D_H
#define LIB3D_H

//#include <windows.h>
#include <GL\gl.h>
#include <GL\glu.h>
//#include <GL\glext.h>
//#include <GL\wglext.h>
//#include <GL\glut.h>

#include <math.h>

//#include "SObject3D.h"
//#include "LIBS.h"
//#include "data.h"
//#include "Timer.h"

#include <vector>

class LIB3D {
  public:

    static void drawPlane(float xmin, float xmax,
                                float ymin, float ymax,
                                float zmin, float zmax,
                                float r, float g, float b){
                glPushMatrix();
                glPolygonMode( GL_BACK, GL_LINE );
                glPolygonMode( GL_FRONT, GL_LINE );
    			glColor3f(r, g, b);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymin, zmax);
                  glVertex3f (xmax, ymin, zmax);
                  glVertex3f (xmax, ymax, zmax);
                  glVertex3f (xmin, ymax, zmax);
                }
                glEnd();
                glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
                glPolygonMode( GL_FRONT, GL_FILL );
                glPopMatrix();
    }

    static void drawTetrahed(float xmin, float xmax,
                                    float ymin, float ymax,
                                    float zmin, float zmax,
                                    float r, float g, float b,
                                    float alpha){
    			float i;

                glPushMatrix();
                glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
                glPolygonMode( GL_FRONT, GL_FILL );
                glMaterialf(GL_FRONT, GL_DIFFUSE, 32.0f);
    			glColor4f(r, g, b, alpha);
    			//glColor3f(r, g, b);

                //glNormal3f(0.0f, 0.0f, 1.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymin, zmax);
                  glVertex3f (xmax, ymin, zmax);
                  glVertex3f (xmax, ymax, zmax);
                  glVertex3f (xmin, ymax, zmax);
                }
                glEnd();

    			//glNormal3f(0.0f, 0.0f, -1.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymin, zmin);
                  glVertex3f (xmin, ymax, zmin);
                  glVertex3f (xmax, ymax, zmin);
                  glVertex3f (xmax, ymin, zmin);
                }
                glEnd();

    			//glNormal3f(-1.0f, 0.0f, 0.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymin, zmax);
                  glVertex3f (xmin, ymax, zmax);
                  glVertex3f (xmin, ymax, zmin);
                  glVertex3f (xmin, ymin, zmin);
                }
                glEnd();

    			//glNormal3f(1.0f, 0.0f, 0.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmax, ymin, zmax);
                  glVertex3f (xmax, ymin, zmin);
                  glVertex3f (xmax, ymax, zmin);
                  glVertex3f (xmax, ymax, zmax);
                }
                glEnd();

    			//glNormal3f(0.0f, -1.0f, 0.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymin, zmax);
                  glVertex3f (xmin, ymin, zmin);
                  glVertex3f (xmax, ymin, zmin);
                  glVertex3f (xmax, ymin, zmax);
                }
                glEnd();

    			//glNormal3f(0.0f, -1.0f, 0.0f);
    			glBegin(GL_POLYGON);
    			{
                  glVertex3f (xmin, ymax, zmax);
                  glVertex3f (xmax, ymax, zmax);
                  glVertex3f (xmax, ymax, zmin);
                  glVertex3f (xmin, ymax, zmin);
                }
                glEnd();
                //glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
                //glPolygonMode( GL_FRONT, GL_FILL );
               glPopMatrix();
    }

    static void drawPoint(float x, float y, float z, float radius,
                                 float r, float g, float b){
        glPushMatrix();
            //glMaterialf(GL_FRONT, GL_SHININESS, 32.0f);
            glColor3f(r, g, b);
            glPointSize (radius*500);
            //Antialiasing sur les points
            glEnable (GL_POINT_SMOOTH);
            //Gestion de la transparence
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,
            GL_ONE_MINUS_SRC_ALPHA);
            //glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
            //glPolygonMode( GL_FRONT, GL_FILL );
            //glMaterialf(GL_FRONT, GL_DIFFUSE, 32.0f);
            glBegin (GL_POINTS);
                glVertex3f(x, y, z);
            glEnd();
        glPopMatrix();
    }

    static void drawSphere(float x, float y, float z, float radius,
                                 float r, float g, float b){
        glPushMatrix();
        //glMaterialf(GL_FRONT, GL_SHININESS, 32.0f);
        glColor3f(r, g, b);
        glPolygonMode( GL_BACK, GL_FILL ); //GL_FILL GL_LINE
        glPolygonMode( GL_FRONT, GL_FILL );
        glMaterialf(GL_FRONT, GL_DIFFUSE, 32.0f);
        glTranslatef(x, y, z);
//        glutSolidSphere(radius, 24, 24);
        glPopMatrix();
    }

    static void renderCylinder(float x1, float y1, float z1, float x2,float y2, float z2, float radius, GLUquadricObj *quadric)
    {
        float vx = x2-x1;
        float vy = y2-y1;
        float vz = z2-z1;

        //handle the degenerate case of z1 == z2 with an approximation
        if(vz == 0)
            vz = .00000001;

        float v = sqrt( vx*vx + vy*vy + vz*vz );
        float ax = 57.2957795*acos( vz/v );
        if ( vz < 0.0 )
            ax = -ax;
        float rx = -vy*vz;
        float ry = vx*vz;

        glPushMatrix();
        glTranslatef( x1,y1,z1 );
        glRotatef(ax, rx, ry, 0.0);
        gluQuadricOrientation(quadric,GLU_OUTSIDE);
        gluCylinder(quadric, radius, radius, v, 32, 1);

        gluQuadricOrientation(quadric,GLU_INSIDE);
        gluDisk( quadric, 0.0, radius, 32, 1);
        glTranslatef( 0,0,v );

        gluQuadricOrientation(quadric,GLU_OUTSIDE);
        gluDisk( quadric, 0.0, radius, 32, 1);
        glPopMatrix();
    }

    static void drawCylinder(float x1, float y1, float z1, float x2,float y2, float z2, float radius, float r, float g, float b)
    {
        glColor3f(r, g, b);
        GLUquadricObj *quadric=gluNewQuadric();
        gluQuadricNormals(quadric, GLU_SMOOTH);
        renderCylinder(x1,y1,z1,x2,y2,z2,radius,quadric);
        gluDeleteQuadric(quadric);
    }

    static void renderSphere(float x, float y, float z, float radius, GLUquadricObj *quadric)
    {
        glPushMatrix();
        glTranslatef( x,y,z );
        gluSphere(quadric, radius, 32, 32);
        glPopMatrix();
    }

    static void drawSphere2(float x, float y, float z, float radius, float r, float g, float b)
    {
        glColor3f(r, g, b);
        GLUquadricObj *quadric=gluNewQuadric();
        gluQuadricNormals(quadric, GLU_SMOOTH);
        renderSphere(x,y,z,radius,quadric);
        gluDeleteQuadric(quadric);
    }

//    static void drawStringText(char *string,
//                                      float x,float y,float z,
//                                      float r, float g, float b) {
//      char *c;
//      glPushMatrix();
//      glColor3f(r, g, b);
//      glTranslatef(x, y,z);
//      glRotatef(+90.0f,1.0f,0.0f,0.0f);
//      glRotatef(+90.0f,0.0f,1.0f,0.0f);
//      //glRotatef(+90.0f,0.0f,0.0f,1.0f);
//      glScalef(0.0015,0.0015,0.5);
//      for (c=string; *c != '\0'; c++) {
////        glutStrokeCharacter(GLUT_STROKE_ROMAN, *c);
//      }
//      glPopMatrix();
//    }

    static void drawCone2(float x, float y, int na, int nb,
                        //float ax, float ay, float az, float angle,
                        //float tx, float ty, float tz,
                          float r, float g, float b) {

        //glPushMatrix();
        glColor3f(r, g, b);
        //glRotatef(angle, ax, ay, az);
        //glTranslatef(tx, ty, tz);
        renderSolidCone(x, y, na, nb);
        //glPopMatrix();
    }

   static void renderSolidCone(GLdouble base, GLdouble height, GLint slices, GLint stacks) {
      glBegin(GL_LINE_LOOP);
         GLUquadricObj* quadric = gluNewQuadric();
         gluQuadricDrawStyle(quadric, GLU_FILL);
         gluCylinder(quadric, base, 0, height, slices, stacks);
         gluDeleteQuadric(quadric);
   }

};

#endif

