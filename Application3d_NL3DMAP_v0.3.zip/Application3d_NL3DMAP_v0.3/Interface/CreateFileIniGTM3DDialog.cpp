#include "CreateFileIniGTM3DDialog.h"

CreateFileIniGTM3DDialog::CreateFileIniGTM3DDialog( wxWindow* parent, const wxString& title )
        : wxDialog(parent, -1, title, wxDefaultPosition, wxDefaultSize,wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER)
{
    // Constructing a vertical sizer
    wxBoxSizer *dialogSizer = new wxBoxSizer(wxVERTICAL);

    Xmin=new wxTextCtrl(this, -1);
    Xmax=new wxTextCtrl(this, -1);
    Ymin=new wxTextCtrl(this, -1);
    Ymax=new wxTextCtrl(this, -1);
    Zmin=new wxTextCtrl(this, -1);
    Zmax=new wxTextCtrl(this, -1);
    Bsiz=new wxTextCtrl(this, -1);
    illum=new wxTextCtrl(this, -1);
    m2=new wxTextCtrl(this, -1);
    m3=new wxTextCtrl(this, -1);
    d2=new wxTextCtrl(this, -1);
    d3=new wxTextCtrl(this, -1);
    d4=new wxTextCtrl(this, -1);
    col1R=new wxTextCtrl(this, -1);
    col2R=new wxTextCtrl(this, -1);
    col3R=new wxTextCtrl(this, -1);
    col4R=new wxTextCtrl(this, -1);
    col1G=new wxTextCtrl(this, -1);
    col2G=new wxTextCtrl(this, -1);
    col3G=new wxTextCtrl(this, -1);
    col4G=new wxTextCtrl(this, -1);
    col1B=new wxTextCtrl(this, -1);
    col2B=new wxTextCtrl(this, -1);
    col3B=new wxTextCtrl(this, -1);
    col4B=new wxTextCtrl(this, -1);

    // Constructing a grid sizer with 2 rows and 2 columns (use 10 pixels
    //wxFlexGridSizer *textSizer = new wxFlexGridSizer(13, 2, 10, 10);
    wxFlexGridSizer *textSizer = new wxFlexGridSizer(2, 1, 10, 1);

    wxFlexGridSizer *XYZSizer = new wxFlexGridSizer(4, 3, 10, 10);

    // Adding static text control
    XYZSizer->Add(new wxStaticText(this, -1, wxT("Xmin/Xmax")), 1, wxEXPAND);
    XYZSizer->Add(Xmin, 1, wxEXPAND);
    XYZSizer->Add(Xmax, 1, wxEXPAND);

    XYZSizer->Add(new wxStaticText(this, -1, wxT("Ymin/Ymax")), 1, wxEXPAND);
    XYZSizer->Add(Ymin, 1, wxEXPAND);
    XYZSizer->Add(Ymax, 1, wxEXPAND);

    XYZSizer->Add(new wxStaticText(this, -1, wxT("Zmin/Zmax")), 1, wxEXPAND);
    XYZSizer->Add(Zmin, 1, wxEXPAND);
    XYZSizer->Add(Zmax, 1, wxEXPAND);

    XYZSizer->Add(new wxStaticText(this, -1, wxT("Size/Illum")), 1, wxEXPAND);
    XYZSizer->Add(Bsiz, 1, wxEXPAND);
    XYZSizer->Add(illum, 1, wxEXPAND);

    textSizer->Add(XYZSizer,1, wxEXPAND);

    wxFlexGridSizer *ColSizer = new wxFlexGridSizer(4, 6, 10, 10);
    ColSizer->Add(new wxStaticText(this, -1, wxT("m1/d1/col1R/col1G/col1B")), 1, wxEXPAND);
    ColSizer->Add(new wxStaticText(this, -1, wxT("1")), 1, wxEXPAND);
    ColSizer->Add(new wxStaticText(this, -1, wxT("0")), 1, wxEXPAND);
    ColSizer->Add(col1R, 1, wxEXPAND);
    ColSizer->Add(col1G, 1, wxEXPAND);
    ColSizer->Add(col1B, 1, wxEXPAND);

    ColSizer->Add(new wxStaticText(this, -1, wxT("m2/d2/col2R/col2G/col2B")), 1, wxEXPAND);
    ColSizer->Add(m2, 1, wxEXPAND);
    ColSizer->Add(d2, 1, wxEXPAND);
    ColSizer->Add(col2R, 1, wxEXPAND);
    ColSizer->Add(col2G, 1, wxEXPAND);
    ColSizer->Add(col2B, 1, wxEXPAND);

    ColSizer->Add(new wxStaticText(this, -1, wxT("m3/d3/col3R/col3G/col3B")), 1, wxEXPAND);
    ColSizer->Add(m3, 1, wxEXPAND);
    ColSizer->Add(d3, 1, wxEXPAND);
    ColSizer->Add(col3R, 1, wxEXPAND);
    ColSizer->Add(col3G, 1, wxEXPAND);
    ColSizer->Add(col3B, 1, wxEXPAND);

    ColSizer->Add(new wxStaticText(this, -1, wxT("m4/d4/col4R/col4G/col4B")), 1, wxEXPAND);
    ColSizer->Add(new wxStaticText(this, -1, wxT("64")), 1, wxEXPAND);
    ColSizer->Add(d4, 1, wxEXPAND);
    ColSizer->Add(col4R, 1, wxEXPAND);
    ColSizer->Add(col4G, 1, wxEXPAND);
    ColSizer->Add(col4B, 1, wxEXPAND);

    textSizer->Add(ColSizer,1, wxEXPAND);



//    textSizer->Add(new wxStaticText(this, -1, wxT("Node Size")), 1, wxEXPAND);
//    textSizer->Add(Bsiz, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Opt")), 1, wxEXPAND);
//    textSizer->Add(illum, 1, wxEXPAND);
//
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 1 R")), 1, wxEXPAND);
//    textSizer->Add(col1R, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 2 R")), 1, wxEXPAND);
//    textSizer->Add(col2R, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 3 R")), 1, wxEXPAND);
//    textSizer->Add(col3R, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 4 R")), 1, wxEXPAND);
//    textSizer->Add(col4R, 1, wxEXPAND);
//
//    textSizer->Add(new wxStaticText(this, -1, wxT("1<=m2<=64")), 1, wxEXPAND);
//    textSizer->Add(m2, 1, wxEXPAND);
//
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 1 G")), 1, wxEXPAND);
//    textSizer->Add(col1G, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 2 G")), 1, wxEXPAND);
//    textSizer->Add(col2G, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 3 G")), 1, wxEXPAND);
//    textSizer->Add(col3G, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 4 G")), 1, wxEXPAND);
//    textSizer->Add(col4G, 1, wxEXPAND);
//
//    textSizer->Add(new wxStaticText(this, -1, wxT("1<=m3<=64")), 1, wxEXPAND);
//    textSizer->Add(m3, 1, wxEXPAND);
//
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 1 B")), 1, wxEXPAND);
//    textSizer->Add(col1B, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 2 B")), 1, wxEXPAND);
//    textSizer->Add(col2B, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 3 B")), 1, wxEXPAND);
//    textSizer->Add(col3B, 1, wxEXPAND);
//    textSizer->Add(new wxStaticText(this, -1, wxT("Col 4 B")), 1, wxEXPAND);
//    textSizer->Add(col4B, 1, wxEXPAND);

    // Adding button control
    wxButton *button = new wxButton(this, ID_BUTTON_CLICK, wxT("OK"));
    dialogSizer->Add(textSizer, 0, wxALIGN_CENTER);
    dialogSizer->Add(button,
        0, // make vertically unstretchable
        wxALIGN_CENTER | wxALL, 10); // centre horizontally and set border width to 10

    SetSizer(dialogSizer); // Use dialog sizer for layout
    dialogSizer->Fit(this); // Fit dialog to components
}

BEGIN_EVENT_TABLE(CreateFileIniGTM3DDialog, wxDialog)
EVT_BUTTON(ID_BUTTON_CLICK, CreateFileIniGTM3DDialog::OnButtonClick)
END_EVENT_TABLE()

void CreateFileIniGTM3DDialog::OnButtonClick(wxCommandEvent &event) {
 this->Show(false);
}
