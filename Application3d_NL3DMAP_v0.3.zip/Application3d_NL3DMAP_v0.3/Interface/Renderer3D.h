#ifndef _RENDERER3D_H_
#define _RENDERER3D_H_

// ------------- WX_LIB -------------------------------------------------------
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif
// -----------------------------------------------------------------------------
#if !wxUSE_GLCANVAS
#error "OpenGL required: set wxUSE_GLCANVAS to 1 and rebuild the library"
#endif

#if wxUSE_GLCANVAS

#include "wx/glcanvas.h"

#ifndef __WXMSW__     // for StopWatch, see remark below
#if defined(__WXMAC__) && !defined(__DARWIN__)
#include <utime.h>
#include <unistd.h>
#else
#include <sys/time.h>
#include <sys/unistd.h>
#endif
#else
#include <sys/timeb.h>
#endif

#include "LowRenderer.h"
#include "Controler.h"

class Controler;

class Renderer3D: public wxGLCanvas
{
    friend class MyFrame;
public:
    Renderer3D( wxWindow *parent, wxWindowID id = wxID_ANY,
                const wxPoint& pos = wxDefaultPosition,
                const wxSize& size = wxDefaultSize,
                long style = 0, const wxString& name = _T("Renderer3D") );

    Renderer3D( wxWindow *parent, const Renderer3D *other,
                wxWindowID id = wxID_ANY, const wxPoint& pos = wxDefaultPosition,
                const wxSize& size = wxDefaultSize, long style = 0,
                const wxString& name = _T("Renderer3D") );

    ~Renderer3D();

    void OnPaint(wxPaintEvent& event);
    void OnSize(wxSizeEvent& event);
    void OnEraseBackground(wxEraseEvent& event);
    void OnKeyDown(wxKeyEvent& event);
    void OnKeyUp(wxKeyEvent& event);
    void OnEnterWindow(wxMouseEvent& event);
    void OnMouseEvent(wxMouseEvent& event);

    void Render();
    void InitGL();

    // ------------------------------------------------------------
    void initCL(Controler* _c, LowRenderer* _l);
    LowRenderer* getLowRenderer();
    Controler* getControler();

    void display();
    void keyboard(unsigned char key, int x, int y);
    void special(int key, int x, int y);
    void loop();
    void fullScreenTogle();

    void motion(int x, int y);
    void mouse(int button, int state, int x, int y);
    //int mButton;
    int mOldY, mOldX;
    float eye[3];
    float rot[3];

    PICK_MODE mode; //PICK_MODE getMode() {return mode;}
    bool isSelected;
    // ------------------------------------------------------------
private:
    // ------------------------------------------------------------
   Controler* controler;
   LowRenderer* lowrenderer;

   void beginPicking();
   void finishPicking();
   int BUFSIZE;
   GLuint* selectBuf;
   GLint hits;

   void drawColorMap(void *font);
   void setDrawText(bool);
   void drawText(char *str, void *font, GLclampf r, GLclampf g, GLclampf b,
                  GLfloat x, GLfloat y);

   // member value
    int width, height;
    int initial_X, initial_Y;
    int initial_W, initial_H;
    //int wireframe;
    //GLuint g_TexturesArray[MAX_TEXTURES];
     int objectSelected;
    // ------------------------------------------------------------
    bool   m_init;
    //GLuint m_gllist;
    //long   m_rleft;
    //long   m_rright;

    static unsigned long  m_secbase;
    static int            m_TimeInitialized;
    static unsigned long  m_xsynct;
    static unsigned long  m_gsynct;

    long           m_Key;
    unsigned long  m_StartTime;
    unsigned long  m_LastTime;
    unsigned long  m_LastRedraw;

    unsigned long StopWatch( unsigned long *sec_base );

    void setViewport(int width, int height);
    void initLights();

    void clamp(float *v);

    char text_params[164];

    DECLARE_EVENT_TABLE()
};

#endif // #if wxUSE_GLCANVAS

#endif

