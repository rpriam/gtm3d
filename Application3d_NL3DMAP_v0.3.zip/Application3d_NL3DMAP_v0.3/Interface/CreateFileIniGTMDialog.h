#ifndef _CreateFileIniGTMDialog_H_
#define _CreateFileIniGTMDialog_H_

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

class CreateFileIniGTMDialog : public wxDialog {

public:
    CreateFileIniGTMDialog( wxWindow* parent, const wxString& title );

    // --- Processes Click Button
    void OnButtonClick(wxCommandEvent &event);

    void set_nameFileData(wxString _s)   { nameFileData->SetLabel(_s); }
    void set_nameFileLabel(wxString _s)  { nameFileLabel->SetLabel(_s); }
    void set_dim1_W_init(wxString _s)    { dim1_W_init->SetLabel(_s); }
    void set_dim2_W_init(wxString _s)    { dim2_W_init->SetLabel(_s); }
    void set_dim1_W_end(wxString _s)     { dim1_W_end->SetLabel(_s); }
    void set_dim2_W_end(wxString _s)     { dim2_W_end->SetLabel(_s); }
    void set_dim1_W_last(wxString _s)    { dim1_W_last->SetLabel(_s); }
    void set_dim2_W_last(wxString _s)    { dim2_W_last->SetLabel(_s); }
    void set_evaluate_last(wxString _s)  { evaluate_last->SetLabel(_s); }
    void set_dim1_M(wxString _s)         { dim1_M->SetLabel(_s); }
    void set_dim2_M(wxString _s)         { dim2_M->SetLabel(_s); }
    void set_sM(wxString _s)             { sM->SetLabel(_s); }
    void set_type_basis(wxString _s)     { type_basis->SetLabel(_s); };
    void set_type_init(wxString _s)      { type_init->SetLabel(_s); };
    void set_name_file_init(wxString _s) { name_file_init->SetLabel(_s); };
    void set_type_gtm(wxString _s)      { type_gtm->SetLabel(_s); }//wxAtoi(type_gtm->GetLabelText()); }
    void set_beta(wxString _s)          { beta->SetLabel(_s); }//wxAtof(beta->GetLabelText()); }


    char* get_nameFileData()
    {
        wxString nfd = nameFileData->GetLabelText();
        std::string nomtr((char const*)nfd.mb_str(*wxConvCurrent));
        const char* nomch = nomtr.c_str();
        return(strcpy(new char[256],nomch));
    }

    char* get_nameFileLabel()
    {
        std::string nomtr((char const*)(nameFileLabel->GetLabelText()).mb_str(*wxConvCurrent));
        const char* nomch = nomtr.c_str();
        return(strcpy(new char[256],nomch));
    }

    int get_dim1_W_init()      { return wxAtoi(dim1_W_init->GetLabelText()); }
    int get_dim2_W_init()      { return wxAtoi(dim2_W_init->GetLabelText()); }
    int get_dim1_W_end()       { return wxAtoi(dim1_W_end->GetLabelText()); }
    int get_dim2_W_end()       { return wxAtoi(dim2_W_end->GetLabelText()); }
    int get_dim1_W_last()      { return wxAtoi(dim1_W_last->GetLabelText()); }
    int get_dim2_W_last()      { return wxAtoi(dim2_W_last->GetLabelText()); }
    int get_evaluate_last()     { return wxAtoi(evaluate_last->GetLabelText()); }
    int get_dim1_M()           { return wxAtoi(dim1_M->GetLabelText()); }
    int get_dim2_M()           { return wxAtoi(dim2_M->GetLabelText()); }
    double get_sM()            { return wxAtof(sM->GetLabelText()); }

    char* get_type_basis()     {
        wxString nfd = type_basis->GetLabelText();
        std::string nomtr((char const*)nfd.mb_str(*wxConvCurrent));
        const char* nomch = nomtr.c_str();
        return(strcpy(new char[256],nomch));
    }

    char* get_type_init()     {
        wxString nfd = type_init->GetLabelText();
        std::string nomtr((char const*)nfd.mb_str(*wxConvCurrent));
        const char* nomch = nomtr.c_str();
        return(strcpy(new char[256],nomch));
    }

    char* get_name_file_init()     {
        wxString nfd = name_file_init->GetLabelText();
        std::string nomtr((char const*)nfd.mb_str(*wxConvCurrent));
        const char* nomch = nomtr.c_str();
        return(strcpy(new char[256],nomch));
    }

    int get_type_gtm()         { return wxAtoi(type_gtm->GetLabelText()); }//wxAtoi(type_gtm->GetLabelText()); }
    double get_beta()          { return wxAtof(beta->GetLabelText()); }//wxAtof(beta->GetLabelText()); }

protected:
    DECLARE_EVENT_TABLE()

private:
    wxTextCtrl *nameFileData;
    wxTextCtrl *nameFileLabel;
    wxTextCtrl *dim1_W_init;
    wxTextCtrl *dim2_W_init;
    wxTextCtrl *dim1_W_end;
    wxTextCtrl *dim2_W_end;
    wxTextCtrl *dim1_W_last;
    wxTextCtrl *dim2_W_last;
    wxTextCtrl *evaluate_last;
    wxTextCtrl *dim1_M;
    wxTextCtrl *dim2_M;
    wxTextCtrl *sM;
    wxTextCtrl *type_basis;
    wxTextCtrl *type_init;
    wxTextCtrl *name_file_init;
    wxTextCtrl *type_gtm;
    wxTextCtrl *beta;

    enum {
        ID_BUTTON_CLICK = wxID_HIGHEST+1
    };

};

#endif
