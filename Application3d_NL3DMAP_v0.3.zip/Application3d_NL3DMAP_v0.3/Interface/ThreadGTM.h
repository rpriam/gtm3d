#ifndef _WX_THREADGTM_H_
#define _WX_THREADGTM_H_

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#if !wxUSE_THREADS
    #error "This sample requires thread support!"
#endif // wxUSE_THREADS

#include "wx/thread.h"
#include "wx/dynarray.h"
#include "wx/numdlg.h"

#include "wx/progdlg.h"

// define this to use wxExecute in the exec tests, otherwise just use system
#define USE_EXECUTE

#ifdef USE_EXECUTE
    #define EXEC(cmd) wxExecute((cmd), wxEXEC_SYNC)
#else
    #define EXEC(cmd) system(cmd)
#endif

#include "..\Algorithms\GTM.h"
#include "..\Algorithms\Data.h"
#include "..\AppliFrame.h"

class ThreadGTM : public wxThread
{
public:
    ThreadGTM(AppliFrame *frame);

    // thread execution starts here
    virtual void *Entry();

    // called when the thread exits - whether it terminates normally or is
    // stopped with Delete() (but not when it is Kill()ed!)
    virtual void OnExit();

    // write something to the text control
    void WriteText(const wxString& text);

    //
    void InitValues(char *workDirectory, char* nameFileData,
                int dim1_W_init, int dim2_W_init,
                int dim1_W_end, int dim2_W_end, int dim1_W_last,
                int dim2_W_last, int _evaluate_last,
                int dim1_M, int dim2_M, double sM,
                GTM::BASIS_TYPE _basistypeM,
                GTM::INIT_GTM _type_initW, char* _nameFileInitW,
                int type_gtm, double beta);

protected:
//    unsigned m_count;
    AppliFrame *m_frame;

    char* nameFileData;
    char* workDirectory;

    //GTM* gtm;
    //Data* d;
    int dim1_W_init;
    int dim2_W_init;
    int dim1_W_end;
    int dim2_W_end;
    int dim1_W_last;
    int dim2_W_last;
    int dim1_M;
    int dim2_M;
    double sM;
    GTM::BASIS_TYPE basistypeM;

    int type_gtm;
    double beta;

    GTM::INIT_GTM type_initW;
    char* nameFileInitW;

    int evaluate_last;
};

#endif
