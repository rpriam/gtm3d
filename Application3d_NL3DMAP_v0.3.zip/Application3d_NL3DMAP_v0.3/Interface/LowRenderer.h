#ifndef LOWRENDERER_H
#define LOWRENDERER_H

//#include <windows.h>
#include <GL\gl.h>
//#include <GL\glu.h>
//#include <GL\glext.h>
//#include <GL\wglext.h>
//#include <GL\glut.h>
#include <vector>

#include "SObject3D.h"
#include "Timer.h"

#include "LIBS.h"
#include "LIB3D.h"

#include "../Algorithms/Data.h"

class SObject3D;
class Control;

class LowRenderer
{

public:

    LowRenderer();

    void updateObjects3D_Data(int n,
                              float** data_proj,
                              float* min, float* max,
                              int* data_cl,
                              MAP_TYPE _type,
                              OBJECT_TYPE _type3D);

    void updateObjects3D_Map(int n, int k,
                             int dim1, int dim2,
                             float** map,
                             float* min,float* max,
                             int* map_cl,
                             MAP_TYPE _type,
                             OBJECT_TYPE _type3D);

    double normalizeX(float x, float min_x, float max_x);
    double normalizeY(float y, float min_y, float max_y);
    double normalizeZ(float z, float min_z, float max_z);
//    void setConstants(float _Xmin, float _Xmax,
//                      float _Ymin, float _Ymax,
//                      float _Zmin, float _Zmax);

    GLuint generateMapList();
    GLuint generateInPlaneList();
    GLuint generateobjects3DList();
    GLuint generateobjects3DTextList();
    GLuint generateBoxList();
    GLuint generateAxisList();
    GLuint generateGridList();
    GLuint generateGridTextList();
    GLuint generateGridNodeList(bool selectMode);

    void DrawScene(bool selectMode);

    float heighColotMap_R(float x, float y, float z);
    float heighColotMap_G(float x, float y, float z);
    float heighColotMap_B(float x, float y, float z);

    void setNeedUpdateOs3D()
    {
        needUpdateO3D=true;
        needUpdateOT3D=true;
        /*MessageBox (NULL, "need set data", "need set data", 0);*/
    }
    void setNeedUpdateMs3D()
    {
        needUpdateM3D=true;
        needUpdateG3D=true;
        needUpdateGT3D=true;
        needUpdateGN3D=true;
        /*MessageBox (NULL, "need set map", "need set map", 0);*/
    }

    void setNeedUpdateAll()
    {
        needUpdateO3D=true;
        needUpdateOT3D=true;
        needUpdateM3D=true;
        needUpdateG3D=true;
        needUpdateGT3D=true;
        needUpdateGN3D=true;
        needUpdateAxis=true;
        needUpdateBox=true;
        needUpdatePlane=true;
    }

    bool updateAngle, paintAxisXYZ, paintInPlaneXYZ,
    paintOutBoxXYZ, paintNameObject3D, paintMap,
    paintData, paintGrid, paintTextGrid,
    paintNodeGrid, allowHeighMap, allowColorMap,
    paintColorMap, paintColorGrid,
    paintKeyHelp, paintInformations;

    OBJECT_COLOR paintColorObject3D;

    Timer* getTimer()
    {
        return &timer;
    }

// Pb valeur nulle � corriger ....................... ?????????? PATCH !!!!!!!!!!!!!!!
    float getColR(int m)
    {
        if (m>=0 && m<64)
        {
            return cols[m][0];
        }
        else
        {
            if (m<0)
                return cols[0][0];
            else if (m>63)
                return cols[63][0];
        }
    }
    float getColG(int m)
    {
        if (m>=0 && m<64)
        {
            return cols[m][1];
        }
        else
        {
            if (m<0)
                return cols[0][1];
            else if (m>63)
                return cols[63][1];
        }
    }
    float getColB(int m)
    {
        if (m>=0 && m<64)
        {
            return cols[m][2];
        }
        else
        {
            if (m<0)
                return cols[0][2];
            else if (m>63)
                return cols[63][2];
        }
    }

    float constructColorMap();

protected:
    MAP_TYPE type;

    std::vector<SObject3D*> objects3D;
    std::vector<SObject3D*> objects3D_map;

    float*** coords_map;
    void construct_coords_map();
    void destruct_coords_map();

    bool needUpdateO3D; // update object view when data change
    bool needUpdateOT3D; // update text object view when data change

    bool needUpdateM3D; // update map view when data map change
    bool needUpdateG3D; // update grid map view when data map change
    bool needUpdateGT3D; // update grid text map view when data map change
    bool needUpdateGN3D; // update grid node map view when data map change

    bool needUpdateAxis;
    bool needUpdateBox;
    bool needUpdatePlane;

//void setModel(vector<SObject3D*>& _objects3D);
//void setModel_map(vector<SObject3D*>& _objects3D_map);

    int dim1_map, dim2_map;
//    float Xmax, Xmin, Ymax, Ymin, Zmin, Zmax;

    GLuint base;					//display list base for font
    GLuint startTextModeList;

    Timer timer;

    float** cols;
};
#endif	//LOWRENDERER_H

//void invert_bool(bool* b) {*b=!*b;}
