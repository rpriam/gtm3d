#ifndef CONTROLER_H
#define CONTROLER_H

#include "Renderer3D.h"
#include "../Algorithms/Data.h"
#include "Parameters.h"

class Renderer3D;

class Controler {

  public:
    Controler();
    //Controler(Data* _data);
    void updateObjects3D_Data();
    void updateObjects3D_Map();
    void keyboard(long key);
    void special(int key);
    void motion(int x, int y);
    void mouse(int button, int state, int x, int y);
    //void save_snapshot();

    void setData(Data* _data);
    void setRenderer3D(Renderer3D* _r3d);
    void setMapType(MAP_TYPE _type);

    MAP_TYPE getType() {return type;}

    bool isDataNull() { return (data==(Data*)NULL);}

    int get_data_n()   {if (data!=(Data*)NULL) return data->get_n(); return -1;}
    int get_data_p()   {if (data!=(Data*)NULL) return data->get_p(); return -1;}
    int get_map_k()    {if (data!=(Data*)NULL) return data->get_reducmap(type)->get_k(); return -1;}
    int get_map_p()    {if (data!=(Data*)NULL) return data->get_reducmap(type)->get_p(); return -1;}
    int get_map_dim1() {if (data!=(Data*)NULL) return data->get_reducmap(type)->get_dim1(); return -1;}
    int get_map_dim2() {if (data!=(Data*)NULL) return data->get_reducmap(type)->get_dim1(); return -1;}

    int get_map_dim1M() {if (data!=(Data*)NULL) return Parameters::get_xdimM(); return -1;}
    int get_map_dim2M() {if (data!=(Data*)NULL) return Parameters::get_ydimM(); return -1;}
    double get_map_sM() {if (data!=(Data*)NULL) return Parameters::get_sM(); return -1;}

    MAP_TYPE type;

  protected:
    Renderer3D* renderer3D;
    Data* data;

    int j_1;
    int j_2;
    int j_3;
};

#endif	//CONTROLER_H
