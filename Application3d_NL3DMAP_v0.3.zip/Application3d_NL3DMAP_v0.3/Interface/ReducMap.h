#ifndef REDUCMAP_H
#define REDUCMAP_H

#include "LIBS.h"

class LIBS;

class ReducMap {

public:       
    ReducMap(char* workDirectory, int _xdim, int _ydim, MAP_TYPE _type);
    void readMap(char* filename);
    
    int get_n() {return n;}
    int get_p() {return p;}
    int get_k() {return k;}
    
    int get_dim1() {return dim1;}
    int get_dim2() {return dim2;}
    
    float**& get_dataproj(int j1, int j2, int j3);
    float**& get_map(int j1, int j2, int j3);
    float*& get_min();
    float*& get_max();

    MAP_TYPE get_type();

    //void readRowClass(char* filename);
    //void readColumnClass(char* filename);

protected:
    MAP_TYPE type;

    int dim1;
    int dim2;
    int k;
    int p;
    int n;
    
    float* min;
    float* max;

    //int** coord_graph;
    //int** vicinity_matrix;
    //int* reverse_clusters;

    float** d_ip; // data coord proj
    float** d_kp; // center coord
    
    //float** d_k2_u; //umap
    //float** d_k2_d; //density
    /*
    float* min_i3_u;
    float* max_i3_u;
    float* min_i3_d;
    float* max_i3_d;
    */
    
    //float** d_i3_u; //indiv projected (umap)
    //float** d_i3_d; //indiv projected (density)
    
    //int* c_k;
    //int* c_p;
    //char ** l_k;
    //char ** l_p;
    
    float** readMatrix(char* filename, int* n, int* p);
};

#endif
