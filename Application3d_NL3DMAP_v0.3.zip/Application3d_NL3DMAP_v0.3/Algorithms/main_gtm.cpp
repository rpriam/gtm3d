#include <cstdlib>
#include <iostream>
//#include "PCA.h"
#include "GTM.h"
//#include "NGGTM.h"
#include "Data.h"

using namespace std;

int main(int argc, char *argv[])
{
    char* workDirectory;
    if (argc==2)
    {
        workDirectory=argv[1];
    }
    else
    {
        cerr << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        cerr << "Use : gtm directory         (work place with gtm.ini !" << endl;
        cerr << endl;
        cerr << "The gtm.ini contains" << endl;
        cerr << "______________________" << endl;
        cerr << "|data filename        |" << endl;
        cerr << "|x size of the W-map d|" << endl;
        cerr << "|y size of the W-map d|" << endl;
        cerr << "|x size of the W-map f|" << endl;
        cerr << "|y size of the W-map f|" << endl;
        cerr << "|x size of the Phi-map|" << endl;
        cerr << "|y size of the Phi-map|" << endl;
        cerr << "|variance for Phi-base|" << endl;
        cerr << "|_____________________|" << endl;
        cerr << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        system("PAUSE");
        exit(1);
    }

    char* namefileInit = new char[256];
    strcpy(namefileInit,workDirectory);
    strcat(namefileInit,"gtm.ini");

    //cout << namefileInit << endl;

    ifstream in;
    in.open(namefileInit);
    char* namefileData = new char[256];
    char* chaux = new char[256];
    in >> chaux;
    strcpy(namefileData,workDirectory);
    strcat(namefileData,chaux);
    //cout << namefileData << endl;

    //char* nameFileLabel = new char[256]; // unused for unsupervised case !
    in >> chaux; // ----------------------------------------------------- !
    
    int dim1_W_init;
    int dim2_W_init;
    int dim1_W_end;
    int dim2_W_end;
    int dim1_M;
    int dim2_M;
    double sM;
    
    in >> dim1_W_init;
    in >> dim2_W_init;
    in >> dim1_W_end;
    in >> dim2_W_end;
    in >> dim1_M;
    in >> dim2_M;
    in >> sM;
    
    Data d;
    d.readData(namefileData);

    cout << endl << "n=" << d.n << " p=" << d.p;
    cout << " d1_init=" << dim1_W_init << " d2_init=" << dim2_W_init;
    cout << " d1_end=" << dim1_W_end << " d2_end=" << dim2_W_end;
    cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
    cout << " sM=" << sM << endl;
    
    //std::ofstream out("../out/results_gtm.txt");
    //out << "t_end" << " L" << " sigma " << " sM" << endl;

    //for (float epsilon=0.01 ; epsilon>=1e-12 ; epsilon/=10) {
    //  for (float s=0.1; s<=1; s+=0.1) {
    //double sM=0.1;
    //double sM=0.3; //0.3
    
    GTM* gtm = new GTM(workDirectory);
    int dim1_W=dim1_W_init;
    int dim2_W=dim2_W_init;
    gtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);
    gtm->apprentissage_init(GTM::INIT_PCA, NULL, true);
    gtm->apprentissage(2);
    
    int delta1=dim1_W_end-dim1_W_init;
    int delta2=dim2_W_end-dim2_W_init;    
    int delta_max=delta1; if (delta2>delta1) {delta_max=delta2;}
    for (int g=1; g<=delta_max; g++) {
      if (dim1_W+1<=dim1_W_end) {dim1_W++;}
      if (dim2_W+1<=dim2_W_end) {dim2_W++;}
      cout << endl << "n=" << d.n << " p=" << d.p;
      cout << " d1=" << dim1_W << " d2=" << dim2_W;
      cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
      cout << " sM=" << sM << endl;
      gtm->updateSizeVariables(dim1_W, dim2_W, sM);
      gtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
      gtm->apprentissage(2);
    }
    
    gtm->calculer_mapping3D_all();
    
    //system("PAUSE");
    gtm->sauvegarde();
    
    // warning ! only at the end (modify data and file)
    gtm->recenterData();
    gtm->apprentissage_init(GTM::INIT_PCA, NULL, true); // nouveau calcul car modif taille carte     

    system("PAUSE");
    delete [] namefileInit;
    delete [] namefileData;
    delete [] chaux;
    //exit(0);
    return EXIT_SUCCESS;
}

//    gtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);//,epsilon);
//    gtm->apprentissage_init(GTM::INIT_PCA, NULL, true);
//    gtm->apprentissage(true);
//    
//    dim1_W=dim1_W_end;
//    dim2_W=dim2_W_end;
//    
//    gtm->updateSizeVariables(dim1_W, dim2_W, sM);
//    gtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
//    gtm->apprentissage(true);
