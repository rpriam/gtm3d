#ifndef NGGTM_H
#define NGGTM_H

#define WANT_STREAM
#define WANT_MATH

#include "./newmat/newmatap.h"
#include "./newmat/newmatio.h"

#include <iostream>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <time.h>

#include "GTM.h"

#include "./graph/GraphNN.h"

#define nb_NN 3

class NGGTM : public GTM {

 public:
  NGGTM(char* _w);

  void initializeNearestNeighboor();
  int get_nearestData2Centr(int k); // datum nearer to a class center
  
  double apprentissage(int aff);
  //void apprentissage_init(int type_init, double** mk_init, bool save);
  
  double distance_IndivCentr(int i, int k);
  double distance_IndivIndiv(int i1, int i2);
  double distance_IndivCentr_2(int i, int k);
  double distance_IndivIndiv_2(int i1, int i2);
    
 protected :
    double dijkstra(int src, int dest);
    int** matrix_NN;
    GraphNN* g_NN;
    
    double* d;
    int *t;
    int *s;
    
    double dist_MAX;
};

#endif
