#ifndef TNGTM_H
#define TNGTM_H

#include "GTM.h"

class TNGTM : public GTM
{
public:
    TNGTM(char* _w, float _beta);
    double apprentissage(int aff);
    void constructVicinity();
    
protected :
    Matrix V;
    float beta;
    void tnem();
};

#endif
