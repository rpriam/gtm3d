#include "GraphNN.h"

using namespace graph;

