#ifndef GRAPHNN_H
#define GRAPHNN_H

#include "graph-c++.h"
#include "graph-c++-comp.h"
#include <map>

using namespace graph;

class GraphNN : public Graph<int, double, false, int>
{

public:
  GraphNN() {}

public:  

};

#endif
