#include <cstdlib>
#include <iostream>
//#include "PCA.h"
#include "GTM.h"
#include "NGGTM.h"
#include "TNGTM.h"
#include "Data.h"

using namespace std;

int main(int argc, char *argv[])
{
    char* workDirectory;
    if (argc==2)
    {
        workDirectory=argv[1];
    }
    else
    {
        cerr << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        cerr << "Use : gtm directory         (work place with gtm.ini !" << endl;
        cerr << endl;
        cerr << "The gtm.ini contains" << endl;
        cerr << "______________________" << endl;
        cerr << "|data filename        |" << endl;
        cerr << "|x size of the W-map d|" << endl;
        cerr << "|y size of the W-map d|" << endl;
        cerr << "|x size of the W-map f|" << endl;
        cerr << "|y size of the W-map f|" << endl;
        cerr << "|x size of the Phi-map|" << endl;
        cerr << "|y size of the Phi-map|" << endl;
        cerr << "|variance for Phi-base|" << endl;
        cerr << "|_____________________|" << endl;
        cerr << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        system("PAUSE");
        exit(1);
    }

    char* namefileInit = new char[256];
    strcpy(namefileInit,workDirectory);
    strcat(namefileInit,"gtm.ini");

    //cout << namefileInit << endl;

    ifstream in;
    in.open(namefileInit);
    char* namefileData = new char[256];
    char* chaux = new char[256];
    in >> chaux;
    strcpy(namefileData,workDirectory);
    strcat(namefileData,chaux);
    //cout << namefileData << endl;

    //char* nameFileLabel = new char[256]; // unused for unsupervised case !
    in >> chaux; // ----------------------------------------------------- !
    
    int dim1_W_init;
    int dim2_W_init;
    int dim1_W_end;
    int dim2_W_end;
    int dim1_W_last;
    int dim2_W_last;    
    int dim1_M;
    int dim2_M;
    
    double sM;
    int type_gtm;
    float beta;
    
    in >> dim1_W_init;
    in >> dim2_W_init;
    in >> dim1_W_end;
    in >> dim2_W_end;
    in >> dim1_W_last;
    in >> dim2_W_last;    
    in >> dim1_M;
    in >> dim2_M;
    in >> sM;
    
    in >> type_gtm;
    in >> beta; // dummy if not necessary
    
    Data d;
    d.readData(namefileData);

    cout << endl << "n=" << d.n << " p=" << d.p;
    cout << " d1_init=" << dim1_W_init << " d2_init=" << dim2_W_init;
    cout << " d1_end=" << dim1_W_end << " d2_end=" << dim2_W_end;
    cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
    cout << " sM=" << sM;
    
    if (type_gtm==7)
    {
        cout << endl;
        cout << "GTM with graph" << endl;
        NGGTM* nggtm = new NGGTM(workDirectory);
        int dim1_W=dim1_W_init;
        int dim2_W=dim2_W_init;
        nggtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);        
        nggtm->initializeNearestNeighboor();    
        nggtm->apprentissage_init(GTM::INIT_PCA, NULL, true);    
        cout << "end apprentissage init" << endl;        
        cout << "begin learning" << endl;
        nggtm->apprentissage(2);        
        int delta1=dim1_W_end-dim1_W_init;
        int delta2=dim2_W_end-dim2_W_init;    
        int delta_max=delta1; if (delta2>delta1) {delta_max=delta2;}
        for (int g=1; g<=delta_max; g++) {
          if (dim1_W+1<=dim1_W_end) {dim1_W++;}
          if (dim2_W+1<=dim2_W_end) {dim2_W++;}
          cout << endl << "n=" << d.n << " p=" << d.p;
          cout << " d1=" << dim1_W << " d2=" << dim2_W;
          cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
          cout << " sM=" << sM << endl;
          nggtm->updateSizeVariables(dim1_W, dim2_W, sM);
          nggtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
          nggtm->apprentissage(3);
        }
        cout << "end learning" << endl;
        cout << "begin mapping all !" << endl;
        nggtm->calculer_mapping3D_all();
        cout << "end mapping all !" << endl;
        cout << "begin save all !" << endl;
        nggtm->sauvegarde();
        // warning ! only at the end (modify data and file)
        nggtm->recenterData();
        nggtm->apprentissage_init(GTM::INIT_PCA, NULL, true); // nouveau calcul car modif taille carte
        cout << "end save all !" << endl;        
        cout << "end all !" << endl;
    } else if(type_gtm==1) {
        cout << endl;           
        cout << "GTM classical" << endl;
        GTM* gtm = new GTM(workDirectory);
        int dim1_W=dim1_W_init;
        int dim2_W=dim2_W_init;
        gtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);            
        gtm->apprentissage_init(GTM::INIT_PCA, NULL, true);    
        cout << "end apprentissage init" << endl;        
        cout << "begin learning" << endl;                
        gtm->apprentissage(2);
        
        int delta1=dim1_W_end-dim1_W_init;
        int delta2=dim2_W_end-dim2_W_init;    
        int delta_max=delta1; if (delta2>delta1) {delta_max=delta2;}        
        if (delta_max!=0) {
            for (int g=1; g<=delta_max; g++) {
              if (dim1_W+1<=dim1_W_end) {dim1_W++;}
              if (dim2_W+1<=dim2_W_end) {dim2_W++;}
              cout << endl << "n=" << d.n << " p=" << d.p;
              cout << " d1=" << dim1_W << " d2=" << dim2_W;
              cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
              cout << " sM=" << sM << endl;
              gtm->updateSizeVariables(dim1_W, dim2_W, sM);
              gtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
              gtm->apprentissage(3);
            }        
        }
        
        // size larger !!
        if (dim1_W_last!=dim1_W_end  || dim2_W_last!=dim2_W_end) {
            cout << endl << "n=" << d.n << " p=" << d.p;
            cout << " last !!" << endl;
            gtm->updateSizeVariables(dim1_W_last, dim2_W_last, sM);
            gtm->apprentissage_init(GTM::INIT_DONE, NULL, true);            
            gtm->apprentissage(2);
        }
        
        // final ACP map (good size!)
        cout << "end learning" << endl;
        cout << "begin mapping all !" << endl;
        gtm->calculer_mapping3D_all();
        cout << "end mapping all !" << endl;
        //system("PAUSE");        
        cout << "begin save all !" << endl;
        gtm->sauvegarde();        
        // warning ! only at the end (modify data and file)
        gtm->recenterData();
        gtm->apprentissage_init(GTM::INIT_PCA, NULL, true); // nouveau calcul car modif taille carte
        cout << "end save all !" << endl;        
        cout << "end all !" << endl;
    } else if(type_gtm==2) {
        cout << endl;
        cout << "GTM with tnem (beta=" << beta << ")" << endl;
        TNGTM* tngtm = new TNGTM(workDirectory,beta);
        int dim1_W=dim1_W_init;
        int dim2_W=dim2_W_init;
        tngtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);            
        tngtm->apprentissage_init(GTM::INIT_PCA, NULL, true);    
        cout << "end apprentissage init" << endl;        
        cout << "begin learning" << endl;
        tngtm->constructVicinity();
        tngtm->apprentissage(2);        
        int delta1=dim1_W_end-dim1_W_init;
        int delta2=dim2_W_end-dim2_W_init;    
        int delta_max=delta1; if (delta2>delta1) {delta_max=delta2;}
        for (int g=1; g<=delta_max; g++) {
          if (dim1_W+1<=dim1_W_end) {dim1_W++;}
          if (dim2_W+1<=dim2_W_end) {dim2_W++;}
          cout << endl << "n=" << d.n << " p=" << d.p;
          cout << " d1=" << dim1_W << " d2=" << dim2_W;
          cout << " d1_M=" << dim1_M << " d2_M=" << dim2_M;
          cout << " sM=" << sM << endl;
          tngtm->updateSizeVariables(dim1_W, dim2_W, sM);
          tngtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
          tngtm->apprentissage(3);
        }
        cout << "end learning" << endl;
        cout << "begin mapping all !" << endl;
        tngtm->calculer_mapping3D_all();
        cout << "end mapping all !" << endl;
        cout << "begin save all !" << endl;
        tngtm->sauvegarde();
        // warning ! only at the end (modify data and file)
        tngtm->recenterData();
        tngtm->apprentissage_init(GTM::INIT_PCA, NULL, true); // nouveau calcul car modif taille carte     
        cout << "end save all !" << endl;
        cout << "end all !" << endl;
    }
        system("PAUSE");
        //delete [] namefileInit;
        //delete [] namefileData;
        //delete [] chaux;        
        //exit(0);     
    return EXIT_SUCCESS;
}

//    gtm->setVariables(d.n, d.p, d.d_np, dim1_W, dim2_W, dim1_M, dim2_M, sM);//,epsilon);
//    gtm->apprentissage_init(GTM::INIT_PCA, NULL, true);
//    gtm->apprentissage(true);
//    
//    dim1_W=dim1_W_end;
//    dim2_W=dim2_W_end;
//    
//    gtm->updateSizeVariables(dim1_W, dim2_W, sM);
//    gtm->apprentissage_init(GTM::INIT_DONE, NULL, true);
//    gtm->apprentissage(true);
