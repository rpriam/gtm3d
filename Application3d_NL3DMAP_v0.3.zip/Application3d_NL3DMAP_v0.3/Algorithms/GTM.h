#ifndef GTM_H
#define GTM_H

#define WANT_STREAM
#define WANT_MATH

#include "./newmat/newmatap.h"
#include "./newmat/newmatio.h"

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include <cstring>

#ifdef use_namespace
using namespace NEWMAT;
#endif

#ifndef SMALL_FLOAT
#define SMALL_FLOAT 1.0E-10
#endif

#ifndef MAX_DOUBLE
#define MAX_DOUBLE ((double) 1.0 / (double) SMALL_FLOAT)
#endif

#ifndef PI
#define PI 3.14159265
#endif

#define T_MAX 300

#define SIGMA_0 0.001  //////////  A REGLER AUTO

#define EPSILON 1e-12


class GTM
{

public:

    typedef enum {PHINL_ONLY,PHINL_AND_INTERCEPT,PHINL_AND_COOR2D,PHINL_AND_INTERCEPT_COOR2D} BASIS_TYPE;
    typedef enum {INIT_PCA, INIT_RANDOM, INIT_FILE_W, INIT_FILE_Mk, INIT_DONE} INIT_GTM;

    GTM(char* _w);
    void setVariables(int _I,
                      int _J,
                      double** tabdata,
                      int _xdimK,
                      int _ydimK,
                      int _xdimM,
                      int _ydimM,
                      double _sM,
                      BASIS_TYPE _basistypeM);

    static GTM::BASIS_TYPE GetPHITYPE(char* str_type_basis) {
        GTM::BASIS_TYPE type_basis=GTM::PHINL_ONLY;

        if (strcmp(str_type_basis,"PHINL_AND_INTERCEPT")==0)
            {type_basis=GTM::PHINL_AND_INTERCEPT;}
        else if (strcmp(str_type_basis,"PHINL_AND_COOR2D")==0)
            {type_basis=GTM::PHINL_AND_COOR2D;}
        else if (strcmp(str_type_basis,"PHINL_AND_INTERCEPT_COOR2D")==0)
            {type_basis=GTM::PHINL_AND_INTERCEPT_COOR2D;}
        return type_basis;
    }

    static GTM::INIT_GTM GetINITTYPE(char* str_type_init) {
        GTM::INIT_GTM type_init=GTM::INIT_RANDOM;

        if (strcmp(str_type_init,"INIT_PCA")==0)
        {
            type_init=GTM::INIT_PCA;
        }
        else if (strcmp(str_type_init,"INIT_FILE_W")==0)
        {
            type_init=GTM::INIT_FILE_W;
        }
        else if (strcmp(str_type_init,"INIT_FILE_Mk")==0)
        {
            type_init=GTM::INIT_FILE_Mk;
        }

        return type_init;
    }

    void updateSizeVariables(int _xdimK, int _ydimK, double _sM);

    virtual void apprentissage_init(INIT_GTM type_init, char* nameFile, bool save);
    virtual double apprentissage(int aff);

    void sauvegarde();
    void sauvegarde_init();

    void calculer_mapping2D();
    double** get_mapping2D();
// void sauvegarder_mapping2D();

    void calculer_mapping3D_all();

    double distanceEuclidian_IndivCentr(int i, int k);
    double distanceEuclidian_IndivIndiv(int i1, int i2);
    double distanceEuclidian_IndivCentr_2(int i, int k);
    double distanceEuclidian_IndivIndiv_2(int i1, int i2);

    virtual double distance_IndivCentr(int i, int k);
    virtual double distance_IndivIndiv(int i1, int i2);
    virtual double distance_IndivCentr_2(int i, int k);
    virtual double distance_IndivIndiv_2(int i1, int i2);

    double** get_Pik();
    double** get_Pik_j(int j);
    int get_n();
    int get_p();

    int get_tend();
    double get_L();
    double get_sigma();
    double get_sM();
    //double get_epsilon();
    void stocha_move_sM(int t);

    void recenterData();

protected :
    char* workDirectory;

    int I, J, K, M;

    int xdim, ydim;
    int xdimM, ydimM;
    double sM;
    //double epsilon;
    int t_end;

    Matrix U_matrix; // matrix U (as a vector+coord)
    Matrix D_matrix; // matrix density (as a vector+coord)

    Matrix A_3d;
    Matrix A_3d_U;
    Matrix A_3d_D;

    Matrix data;                 // Taille (I,J)
    Matrix Mk;                   // Taille (K,J)
    Matrix Mk_init;              // Taille (K,J)
    Matrix Mk_init_2d;
    Matrix Pik;                  // Taille (I,K)
    Matrix Pk;                   // Taille  (K)
    Matrix Sk;                   // Taille (K,2)
    Matrix Phi;                  // Taille (K,M) (Matrice des noeuds)
    Matrix W;                    // Taille (J,M) (Matrice de project)
    ColumnVector mean_js;        // Taille  (J)
    ColumnVector sigma_js;       // Taille  (J)
    ColumnVector labels;         // Taille (I,1)
    //Matrix pDis;                 // Taille (I,2)
    ColumnVector sigmas;         // Taille (T_MAX)
    double sigma;
    ColumnVector logLs;          // Taille (T_MAX)
    double logL;
    ColumnVector erreurKs;       // Taille (T_MAX)

    BASIS_TYPE basistypeM;

    double max(double a, double b);
    void generer_data();
    void lire_data(char *s);
    void lire_labels(char *s);
    void afficher_p(char* s, const Matrix &mat, int n1, int n2);
    void afficher_v(char *s, const ColumnVector &vect, int n1);
    virtual void calculer_pki();
    virtual void calculer_pki_kmeans();
    void evaluer_mk();
    void calculer_mk();
    void calculer_mk_et_sigma();
    void calculer_mk_sanscontrainte();
    void calculer_sigma();

    void calculer_mapping3D(const Matrix &_matrix, Matrix &A_3d);
    double** get_mapping3D();
    void calculer_umap();//void sauvegarder_umat();
    void calculer_density();//void sauvegarder_density();

    void init_W_parACP();
    void init_Phi_nonlineaire();
    void init_Sk();
    void init_W_alea();
    void init_parametres();
    void init_parametres_sanscontrainte();
    void init_W_parFile(INIT_GTM type_init, char* nameFile);
    double calculer_logvraisemblance();
    double calculer_erreurintra();

    void sauvegarder_v(char* nomfic, const ColumnVector &vect, int n1);
    void sauvegarder_p(char* nomfic, const Matrix &mat, int n1, int n2);
    void sauvegarder_params(char* nomfic);
};

#endif
