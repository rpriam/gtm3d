#include "Data.h"
#include <fstream>
//#include <iostream>

Data::Data() {
  n_maps=0;
}

void Data::readData(char* filename) {
  std::ifstream fic(filename);
  fic >> n;
  fic >> p;
  d_np = (double**)new double[n];
  for (int i=0; i<n; i++)
     {d_np[i] = new double[p];}
  for (int i=0; i<n; i++) {
      for (int j=0; j<p; j++) {
          fic >> d_np[i][j];
       }
  }
  fic.close();
  min = new double[p];
  max = new double[p];
  for (int j=0; j<p; j++) {
      for (int i=0; i<n; i++) {
          if (i==0) {
             min[j]=d_np[i][j];
             max[j]=d_np[i][j];
          } else {
             if (max[j]<d_np[i][j]) {max[j]=d_np[i][j];}
             if (min[j]>d_np[i][j]) {min[j]=d_np[i][j];}
          }
      }
  }

}

void Data::readRowClass(char* filename) {
  std::ifstream fic(filename);
  fic >> n;
  c_n = new int[n];
  for (int i=0; i<n; i++) {
     fic >> c_n[i];
  }
  fic.close();
}

void Data::readColumnClass(char* filename) {
  std::ifstream fic(filename);
  fic >> p;
  c_p = new int[p];
  for (int j=0; j<p; j++) {
     fic >> c_p[j];
  }
  fic.close();
}

void Data::readReducMap(char* workDirectory, int _xdim, int _ydim) {
  dim1=_xdim;
  dim2=_ydim;
  k=_xdim*_ydim;

  n_maps=4;
  maps.resize(4);

  maps[0] = new ReducMap(workDirectory,_xdim,_ydim, MAP_CENTER);
  maps[1] = new ReducMap(workDirectory,_xdim,_ydim, MAP_UMAT);
  maps[2] = new ReducMap(workDirectory,_xdim,_ydim, MAP_DENS);
  maps[3] = new ReducMap(workDirectory,_xdim,_ydim, MAP_ACP);
}

ReducMap* Data::get_reducmap(int num_map) {
  if (num_map>=0 && num_map<n_maps) {
    return maps[num_map];
  } else
    return NULL;
}

Data::~Data() {
 delete [] min, max;
 for (int i=0; i<n; i++) delete[] d_np[i];
 delete[] d_np;
}



//void Data::readReducMap(char* filename) {
//  n_maps++;
//  maps.resize(n_maps);
//  maps[n_maps-1] = new ReducMap(filename);
//}

  /*
  for (int i=0; i<n; i++) {
      for (int j=0; j<p; j++) {
          cout << data[i][j] << " ";
      }
      cout << endl;
  }
  */

