#include"TNGTM.h"

TNGTM::TNGTM(char* _w, float _beta) : GTM(_w)
{
  beta=_beta;
}

void TNGTM::tnem() {
    int i=-1, j=-1, k=-1, l=-1;
    double dmin=0;
    double pnorm=0;
    double factor_tnem;
    double* dists = new double[K];
    
    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        pnorm=0;
        for (k=0; k<K; k++)
        {
            dists[k]=1e-10+distance_IndivCentr_2(i,k);
            if (dists[k]<dmin) {dmin=dists[k];}
        }        
        for (k=0; k<K; k++)
        {
            Pik(i+1,k+1)=exp((-dists[k]+dmin)/2/sigma/sigma);
            pnorm=pnorm+Pik(i+1,k+1);
        }
        for (k=0; k<K; k++)
        {
            Pik(i+1,k+1) = Pik(i+1,k+1)/pnorm;
        }
    }    
    Matrix Pik_old;
    Matrix Diff;
    int c=0;
    do
    {
        Pik_old=Pik;
        for (i=0; i<I; i++)
        {
            dmin=MAX_DOUBLE;
            pnorm=0;
            for (k=0; k<K; k++)
            {
                dists[k]=0;
                for (l=0; l<K; l++) {
                      if (V(k+1,l+1)>0.5)
                        dists[k]=dists[k]+beta*V(k+1,l+1)*distance_IndivCentr_2(i,l);
                }
                if (dists[k]<dmin) {dmin=dists[k];}
            }
            for (k=0; k<K; k++)
            {
                //Pik(i+1,k+1)=exp((-dists[k]+dmin)/2/sigma/sigma);
                Pik(i+1,k+1)=Pik_old(i+1,k+1)*exp(dists[k]);
                pnorm=pnorm+Pik(i+1,k+1);
            }
            for (k=0; k<K; k++)
            {
                Pik(i+1,k+1) = Pik(i+1,k+1)/pnorm;
            }
        }
        for (i=0; i<I; i++)
        {
            for (k=0; k<K; k++)
            {
                if (Pik(i+1,k+1)<1E-8) Pik(i+1,k+1)=1E-8;
                if (Pik(i+1,k+1)>1-1E-8) Pik(i+1,k+1)=1-1E-8;
            }
        }
        Diff=Pik-Pik_old;
        cout << Diff.NormFrobenius() << " ";
    } while (c<120 & Diff.NormFrobenius()>1e-3);
        cout << "beta=" << beta << endl << endl;
//    int c=0;
//    while(1) {
//        Matrix Pik_old=Pik;
//        for (int i=0; i<I; i++) {
//            for (int k=0; k<K; k++) {
//                Pik(i+1,k+1)=exp(log(Pik(i+1,k+1)));
//            }
//        }
////        Pik = Pik.KP(exp(beta*Pik_old*V);
////        Pkij= diag(sum(Pkij').^-1)*Pkij;
////        if (norm(Pkij-Pkij_old,'fro'))/K*I<10^-3 %| c>120
////            break;
////        end;
////        c=c+1;
////        %[c norm(Pkij-Pkij_old,'fro')]
////    end;
//    }    
}

double TNGTM::apprentissage(int aff)
{
    calculer_logvraisemblance();
    static int t=0;
    int t0=t;
    
    bool end=false;
    for (;t-t0<T_MAX && !end ;t++)
    {
        //calculer_pki();
        tnem();
        calculer_mk_et_sigma();
        sigmas(t+1) = sigma;
        logLs(t+1)  = calculer_logvraisemblance();
        if (aff==1||aff==2)
        {
            cout << t << " " << logLs(t+1) << " " << sigmas(t+1) <<  " " << sM << endl;
        }
        if (t>0)
        {
            if (fabs(logLs(t+1)-logLs(t))/fabs(logLs(t))<1E-9)
            {
                end=true;
                t_end=t+1;
            }
        }
    }
    if (aff==2||aff==3) {cout << "t_end=" << t_end << " L=" << logLs(t_end) << " sigma=" << sigmas(t_end) << " sM=" << sM << endl;}
}

void TNGTM::constructVicinity() {
    V = Matrix(K,K);
    for (int j1=0; j1<ydim; j1++){
        for (int i1=0; i1<xdim; i1++){
            int k1=j1*xdim+i1+1;
            for (int j2=0; j2<ydim; j2++){
                for (int i2=0; i2<xdim; i2++){
                    int k2=j2*xdim+i2+1;
                    float d = sqrt((float)((i1-i2)*(i1-i2)+(j1-j2)*(j1-j2)));
                    if (d>0 & d<1.5 & k1!=k2 & (i1==i2 || j1==j2))
                      V(k1,k2) = 1;
                    else
                      V(k1,k2) = 0;
                }
            }
        }
    }
    cout << endl;
}
