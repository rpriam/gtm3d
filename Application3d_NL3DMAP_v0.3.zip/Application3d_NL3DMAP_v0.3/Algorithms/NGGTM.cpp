#include <time.h>
#include "NGGTM.h"
    
NGGTM::NGGTM(char* _w) : GTM(_w)
{
    ;
}

double NGGTM::apprentissage(int aff)
{
    calculer_logvraisemblance();
    static int t=0;
    int t0=t;
    
    bool end=false;
    for (;t-t0<T_MAX && !end ;t++)
    {
        calculer_pki();
        calculer_mk_et_sigma();
        sigmas(t+1) = sigma;
        logLs(t+1)  = calculer_logvraisemblance();
        if (aff==1||aff==2)
        {
            cout << t << " " << logLs(t+1) << " " << sigmas(t+1) <<  " " << sM << endl;
        }
        if (t>0)
        {
            if (fabs(logLs(t+1)-logLs(t))/fabs(logLs(t))<1E-9)
            {
                end=true;
                t_end=t+1;
            }
        }
    }
    if (aff==2||aff==3) {cout << "t_end=" << t_end << " L=" << logLs(t_end) << " sigma=" << sigmas(t_end) << " sM=" << sM << endl;}
}

void NGGTM::initializeNearestNeighboor() {
   cout << "begin graph init !" << endl;
   matrix_NN = (int**)new int[I];
   for (int i=0; i<I; i++) {
     matrix_NN[i] = (int*)new int[nb_NN];
   }
   
   double* ds = new double[I];
   int* is = new int[I];
   // NN graph construction (brute force !)
   for (int i=0; i<I; i++) {
       for (int i2=0; i2<I; i2++) {
         ds[i2]=distanceEuclidian_IndivIndiv(i,i2);
         is[i2]=i2;
       }
       for (int k=0; k<nb_NN; k++) {
          matrix_NN[i][k]=0;
       }

      int dernierChg, marqueur, auxi;
      double auxf;
      for (marqueur=I; marqueur!=0;) {
        dernierChg=-1;
        for(int i2=0;i2<marqueur-1;i2++)
          if(ds[i2]>ds[i2+1]) {
            auxf=ds[i2];
            ds[i2]=ds[i2+1];
            ds[i2+1]=auxf;
            auxi=is[i2];
            is[i2]=is[i2+1];
            is[i2+1]=auxi;
            dernierChg=i2;
          }
          marqueur=dernierChg+1;
      }
//      for (int i2=0; i2<I;i2++)
//        cout << "[" << is[i2] << "]=" << ds[i2] << " ";
//      cout << endl;

     for (int k=0; k<nb_NN; k++) {
       matrix_NN[i][k]=is[k];
     }
  }

  delete [] ds;
  delete [] is;
  
  // graph sparse voisinage
  
  g_NN = new GraphNN();
  for (int i = 0; i < I; i++) {
     g_NN->insert(i);
  }  
  for (int i=0; i<I; i++)
  {
     GraphNN::node_iterator ni = g_NN->find(i);
     for (int k = 0; k < nb_NN; k++)
     {
       int i2=matrix_NN[i][k];
       double w=distanceEuclidian_IndivIndiv(i,i2);
       if (w > 1E-12)
         // cout << i << " " << i2 << " " << w << endl;
          ni->insert_edge(g_NN->find(i2), w);
       }
  }
  d = new double[I];
  t = new int[I];
  s = new int[I];
  
  dist_MAX=0;
  for (int i=0; i<I; i++) {
    for (int i2=0; i2<I; i2++) {
       double d12=distance_IndivIndiv(i,i2);
       if (d12>dist_MAX) dist_MAX=d12;
     }
  }
  dist_MAX=dist_MAX*100;
  cout << "dist_MAX=" << dist_MAX << endl;  
  cout << "end graph init !" << endl;  
}

int NGGTM::get_nearestData2Centr(int k) {
  double aux;
  double dist_min;
  int i_min;

  i_min=0;
  dist_min=distanceEuclidian_IndivCentr_2(i_min,k);

  for (int i=1; i<I; i++) {
    aux=distanceEuclidian_IndivCentr_2(i,k);
    if (aux<dist_min) {
        dist_min=aux;
        i_min=i;
    }
  }
  return i_min;
}

double NGGTM::distance_IndivCentr_2(int i, int k)
{
    double dist=distance_IndivCentr(i,k);
    return dist*dist;
}

double NGGTM::distance_IndivIndiv_2(int i1, int i2)
{       
   double dist=distance_IndivIndiv(i1,i2);
   return dist*dist;
}

double NGGTM::distance_IndivCentr(int i, int k)
{
    int i_nn=get_nearestData2Centr(k);
    return dijkstra(i,i_nn)+distanceEuclidian_IndivIndiv(i,i_nn);
}

double NGGTM::distance_IndivIndiv(int i1, int i2)
{
    return dijkstra(i1,i2);
}

double NGGTM::dijkstra(int src, int dest)
{
    int i;
    int n = g_NN->count_nodes();
//        
//    /* the distance array */
//    double *d = new double[n];
//    /* the parent array */
//    int *t = new int[n];
//    /* the selected array */
//    int *s = new int[n];

    /* assume weights << 30000 */
    const int INF = 30000;
       
    /* initialize distance, parent and selected arrays */
    for (i = 0; i < n; i++)
    {
        d[i] = INF;
        t[i] = -1;
        s[i] = 0;
    }

    /* make sure src will be the first selected node */
    d[src] = 0;

    /* while dest not selected */
    while (1)
    {
        int imin = -1;
        double dmin = INF;

        /* find the closest node to the selected set */
        for (i = 0; i < n; i++)
            if (!s[i] &&
                    (imin == -1 || d[i] < dmin))
            {
                imin = i;
                dmin = d[i];
            }

        /* no such node found, there may be no path to it */
        if (imin < 0)
            break;

        /* select node */
        s[imin] = 1;

        /* find its iterator */
        GraphNN::node_iterator ni = g_NN->find(imin);

        /* browse through its edges */
        for (GraphNN::edge_iterator ei = ni->begin(); ei != ni->end(); ei++)
        {
            /* relax its edges */
            double dd = *ei+d[imin];
            if (dd < d[*ei[1]])
            {
                d[*ei[1]] = dd;
                t[*ei[1]] = imin;
            }
        }

        /* if dest reached, stop */
        if (imin == dest)
            break;
    }

    if (s[dest] == 0)
    {
        //std::cout << "Could not reach destination node " << dest << std::endl;
        return dist_MAX; /// --------------------------- !!
    }

    //std::cout << "Path from " << dest << " to " << src << std::endl;

    /* output the path (in reverse order) */
    i = dest;
    double sum = 0;
    while (1)
    {
    //    std::cout << i << " ";
        int j = i;

        /* t[i] is i's father */
        i = t[i];
        if (i < 0)
            break;

        /* add the edge cost */
        sum += *(g_NN->find(i)->find_edge(g_NN->find(j)));
    }

    //std::cout << std::endl;
    //std::cout << "Cost: " << sum << std::endl;
    return sum;
}

//
//void NGGTM::initializeNearestNeighboor() {
//    int rows=I;
//    int cols=J;
//     
//    float* dataset = (float*) malloc(rows*cols*sizeof(float));
//    int c=0;
//    for (int i=0; i<I; i++) for (int j=0; j<J; j++) {dataset[c]=data(i+1,j+1);c++;}
//          
//	int tcount = 1;		
//	float* testset = (float*) malloc(tcount*cols*sizeof(float));
//    for (int j=0; j<J; j++) {dataset[j]=data(1+1,j+1);}
//	
//	IndexParameters p;
//		
//	int nn = 3;
//	int* result = (int*) malloc(tcount*nn*sizeof(int));
//	
//	FLANNParameters fp;
//	fp.log_level = LOG_INFO;
//	fp.log_destination = NULL;
//	
//    p.algorithm = KDTREE;
//    p.checks = 32;
//    p.trees = 8;
//    p.branching = 32;
//    p.iterations = 7;
//    p.target_precision = -1;
//
//	float speedup;
//	
//	printf("Computing index and optimum parameters.\n");
//	FLANN_INDEX index_id = flann_build_index(dataset, rows, cols, &speedup, &p, &fp);
//
//
//	flann_find_nearest_neighbors_index(index_id, testset, tcount, result, nn, p.checks, &fp);
//
//	//write_dat_file("results.dat",result, tcount, nn);
//	
//    flann_free_index(index_id, &fp);
//	free(dataset);
//    free(testset);
//	free(result);	
//}

//
//void NGGTM::initializeNearestNeighboor() {
//        int k = 3; // number of nearest neighbors
//        int dim = J; // dimension
//        double eps = 0; // error bound
//        int maxPts = I; // maximum number of data points
//        
//        int nPts; // actual number of data points
//        ANNpointArray dataPts; // data points
//        ANNpoint queryPt; // query point
//        ANNidxArray nnIdx; // near neighbor indices
//        ANNdistArray dists; // near neighbor distances
//        ANNkd_tree* kdTree; // search structure
//        queryPt = annAllocPt(dim); // allocate query point
//        dataPts = annAllocPts(maxPts, dim); // allocate data points
//        nnIdx = new ANNidx[k]; // allocate near neigh indices
//        dists = new ANNdist[k]; // allocate near neighbor dists
//        for (nPts=0;nPts<maxPts;nPts++) {
//            for (int j=0;j<dim;j++) {
//              //dataPts[nPts][j]=(double)data(nPts+1,j+1);
//            }
//        }
//        
//        kdTree = new ANNkd_tree( // build search structure
//            dataPts, // the data points
//            nPts, // number of points
//            dim); // dimension of space
//        
//        for (int j=0;j<dim;j++) {
//              //queryPt[j]=data(1+1,j+1);
//        }
//        
//        {
//            kdTree->annkSearch( // search
//                queryPt, // query point
//                k, // number of near neighbors
//                nnIdx, // nearest neighbors (returned)
//                dists, // distance (returned)
//                eps); // error bound
//            cout << "NN: Index Distance\n";
//            for (int i = 0; i < k; i++)   // print summary
//            {
//                dists[i] = sqrt(dists[i]); // unsquare distance
//                cout << i << " " << nnIdx[i] << " " << dists[i] << "\n";
//            }
//        }
//        delete [] nnIdx; // clean things up
//        delete [] dists;
//        delete kdTree;
//        annClose(); // done with ANN
////        return EXIT_SUCCESS;
//}


//void NGGTM::apprentissage_init(int type_init, double** mk_init, bool save) {
//    init_Sk();
//    init_Phi_nonlineaire();
//    if (type_init==INIT_RANDOM)
//    {
//        init_W_alea();
//    }
//    else if (type_init==INIT_PCA)
//    {
//        init_W_parACP();
//    }
//    else if (type_init==INIT_FILE)
//    {
//        int k,j;
//        for (k=0; k<K; k++)
//        {
//            for (j=0; j<J; j++)
//            {
//                Mk_init(k+1,j+1)=mk_init[k][j];
//            }
//        }
//        W = ((Phi.t()*Phi+IdentityMatrix(M)*EPSILON).i()*Phi.t()*Mk_init).t();
//        evaluer_mk();
//    }
//    else if (type_init==INIT_DONE)
//    {
//        evaluer_mk(); // use current W (already calculated) !
//    }
//    else
//    {
//        return;
//    }
//    //evaluer_mk();
//    calculer_pki_kmeans();
//    calculer_sigma();
//    calculer_mapping3D_all();
//    if (save) {sauvegarde_init();} // save ACP map;
//}
