#include "wx/msgdlg.h"

#include "AppliFrame.h"

#include "Interface/sample.xpm"
#include "Interface/Parameters.h"
#include "Interface/ReducMap.h"
#include "Interface/LowRenderer.h"
#include "Interface/Controler.h"
#include "Interface/debugDIALOG.h"

//#include "PCA.h"
#include "Algorithms/Data.h"
#include "Algorithms/GTM.h"
//#include "Algorithms/NGGTM.h"
//#include "Algorithms/TNGTM.h"
//#include "Algorithms/Data.h"

#include "Interface/CreateFileIniGTMDialog.h"
#include "Interface/CreateFileIniGTM3DDialog.h"

#include "Interface/ThreadGTM.h"

AppliFrame::AppliFrame(wxWindow *parent, const wxString& title, const wxPoint& pos,
                       const wxSize& size, long style)
        : wxFrame(parent, wxID_ANY, title, pos, size, style)
{
    m_canvas = NULL;
    SetIcon(wxIcon(sample_xpm));
    workDirectory=wxT("./");
    nameProject=wxT("");
    m_dlgProgress = (wxProgressDialog*)NULL;
    //m_semAllDone = new wxSemaphore();// (wxSemaphore*)NULL;
}

// Intercept menu commands
void AppliFrame::OnExit( wxCommandEvent& WXUNUSED(event) )
{
    // true is to force the frame to close
    Close(true);
}

//void AppliFrame::OnOpenDirectory( wxCommandEvent& WXUNUSED(event) )
//{
//    wxString defaultPath = wxT("/");
//    wxString path;
//    wxDirDialog dialog(this,
//                       wxT("Choose directory to work in"),
//                       defaultPath, wxDD_NEW_DIR_BUTTON);
//    if (dialog.ShowModal() == wxID_OK)
//    {
//        path = dialog.GetPath();
//        path+=wxT("\\");
//        wxMessageBox(path);
//    }
//    workDirectory=path;
////    const char* s = path.mb_str();;
////    workDirectory=new char[strlen(s)+1];
////    strcpy(workDirectory,s);
//}

void AppliFrame::OnOpenProject( wxCommandEvent& WXUNUSED(event) )
{

    wxString defaultPath = workDirectory;
    wxString path;
    wxDirDialog dialog(this,
                       wxT("Choose directory to open project (read data, ini+maps)"),
                       defaultPath, wxDD_NEW_DIR_BUTTON);
    if (dialog.ShowModal() == wxID_OK)
    {
        path = dialog.GetPath();
        SetTitle(wxT("GTM3D ")+path);
        path+=wxT("\\");
        //wxMessageBox(path);

        workDirectory=path;
        std::string nomtr((char const*)workDirectory.mb_str(*wxConvCurrent));
        const char* s = nomtr.c_str();//const char* s = "D:\\Recherche\\Application3D\\Work\\";
        char* s2=new char[strlen(s)+1];
        strcpy(s2,s);
        Parameters::readParameters(s2);
        Data* data = new Data();
        data->readData(Parameters::get_namefiledata());
        data->readRowClass(Parameters::get_namefilelabel());
        data->readReducMap(Parameters::get_workDirectory(),
                           Parameters::get_xdim(),Parameters::get_ydim());
        m_canvas->getControler()->setData(data);
        m_canvas->Refresh(false);
    }
}

void AppliFrame::OnCreateProject( wxCommandEvent& WXUNUSED(event) )
{
    wxString defaultPath = workDirectory;
    wxString path;
    wxDirDialog dialog(this,
                       wxT("Choose directory to create project (read data, write ini+maps)"),
                       defaultPath, wxDD_NEW_DIR_BUTTON);
    if (dialog.ShowModal() == wxID_OK)
    {

        path = dialog.GetPath();
        SetTitle(wxT("GTM3D ")+path);
        path+=wxT("\\");
        //wxMessageBox(path);

        workDirectory=path;
        std::string nomtr((char const*)workDirectory.mb_str(*wxConvCurrent));
        const char* s = nomtr.c_str();//const char* s = "D:\\Recherche\\Application3D\\Work\\";

        //const char* s = "D:\\Recherche\\Application3D\\Work\\";
        char* s2=new char[strlen(s)+1];
        strcpy(s2,s);

        char* namefileInit = new char[256];
        strcpy(namefileInit,s2);
        strcat(namefileInit,"gtm.ini");

        char* name_file_data=new char[256];
        char* name_file_label= new char[256];
        int dim1_W_init;
        int dim2_W_init;
        int dim1_W_end;
        int dim2_W_end;
        int dim1_W_last;
        int dim2_W_last;
        int evaluate_last;
        int dim1_M;
        int dim2_M;
        double sM;
        char* str_type_basisPhi=new char[256];
        char* str_type_initW=new char[256];
        char* name_file_initW=new char[256];
        int type_gtm;
        double beta;

        CreateFileIniGTMDialog* cpd = new CreateFileIniGTMDialog(this, wxT("Parameters setting"));

        ifstream in;
        in.open(namefileInit);  // NEED TEST TO CHECK IF FILE EXIST !!!!!!!!!!
        //if (in.exist()
        in >> name_file_data;
        in >> name_file_label;
        in >> dim1_W_init;
        in >> dim2_W_init;
        in >> dim1_W_end;
        in >> dim2_W_end;
        in >> dim1_W_last;
        in >> dim2_W_last;
        in >> evaluate_last;
        in >> dim1_M;
        in >> dim2_M;
        in >> sM;
        in >> str_type_basisPhi;
        in >> str_type_initW;
        in >> name_file_initW;
        in >> type_gtm;
        in >> beta;
        in.close();

        wxString mystring1(name_file_data, wxConvUTF8);
        cpd->set_nameFileData(mystring1);

        wxString mystring2(name_file_label, wxConvUTF8);
        cpd->set_nameFileLabel(mystring2);

        cpd->set_dim1_W_init(wxString::Format(wxT("%i"),dim1_W_init));
        cpd->set_dim2_W_init(wxString::Format(wxT("%i"),dim2_W_init));
        cpd->set_dim1_W_end(wxString::Format(wxT("%i"),dim1_W_end));
        cpd->set_dim2_W_end(wxString::Format(wxT("%i"),dim2_W_end));
        cpd->set_dim1_W_last(wxString::Format(wxT("%i"),dim1_W_last));
        cpd->set_dim2_W_last(wxString::Format(wxT("%i"),dim2_W_last));
        cpd->set_evaluate_last(wxString::Format(wxT("%i"),evaluate_last));
        cpd->set_dim1_M(wxString::Format(wxT("%i"),dim1_M));
        cpd->set_dim2_M(wxString::Format(wxT("%i"),dim2_M));
        cpd->set_sM(wxString::Format(wxT("%f"),sM));

        wxString mystring3(str_type_basisPhi, wxConvUTF8);
        cpd->set_type_basis(mystring3);
        wxString mystring4(str_type_initW, wxConvUTF8);
        cpd->set_type_init(mystring4);
        wxString mystring5(name_file_initW, wxConvUTF8);
        cpd->set_name_file_init(mystring5);

        cpd->set_type_gtm(wxString::Format(wxT("%i"),type_gtm));
        cpd->set_beta(wxString::Format(wxT("%f"),beta));

        cpd->ShowModal();

        name_file_data= cpd->get_nameFileData();
        char* namefileData = new char[256];
        strcpy(namefileData,s2);
        strcat(namefileData,name_file_data);

        name_file_label= cpd->get_nameFileLabel();

        dim1_W_init        = cpd->get_dim1_W_init();
        dim2_W_init        = cpd->get_dim2_W_init();
        dim1_W_end         = cpd->get_dim1_W_end();
        dim2_W_end         = cpd->get_dim2_W_end();
        dim1_W_last        = cpd->get_dim1_W_last();
        dim2_W_last        = cpd->get_dim2_W_last();
        evaluate_last      = cpd->get_evaluate_last();
        dim1_M             = cpd->get_dim1_M();
        dim2_M             = cpd->get_dim2_M();
        sM                 = cpd->get_sM();
        str_type_basisPhi  = cpd->get_type_basis();
        str_type_initW     = cpd->get_type_init();
        name_file_initW    = cpd->get_name_file_init();
        type_gtm           = cpd->get_type_gtm();
        beta               = cpd->get_beta();

        // save init file
        ofstream ou;
        ou.open(namefileInit);
        ou << name_file_data << endl;
        ou << name_file_label << endl;
        ou << dim1_W_init << endl;
        ou << dim2_W_init << endl;
        ou << dim1_W_end << endl;
        ou << dim2_W_end << endl;
        ou << dim1_W_last << endl;
        ou << dim2_W_last << endl;
        ou << evaluate_last << endl;
        ou << dim1_M << endl;
        ou << dim2_M << endl;
        ou << sM << endl;
        ou << str_type_basisPhi << endl;
        ou << str_type_initW << endl;
        ou << name_file_initW << endl;
        ou << type_gtm << endl;
        ou << beta << endl;
        ou.close();

        cpd->Destroy();

        //Parameters::readParameters(s2);

        //init canvas opengl
        //ofstream ou;
//        char* namefileInit3d = new char[256];
//        strcpy(namefileInit3d,s2);
//        strcat(namefileInit3d,"gtm3d.ini");
//        ou.open(namefileInit3d);
//        ou << "-3" << endl;
//        ou << "3" << endl;
//        ou << "-3" << endl;
//        ou << "3" << endl;
//        ou << "-3" << endl;
//        ou << "3" << endl;
//        ou << "0.04" << endl;
//        ou << "1" << endl;
//        ou << "1  9 0.2 0.4 0.05" << endl;
//        ou << "55 1 0.1 0.7 0.25" << endl;
//        ou << "60 0 0.9 0.9 0.3" << endl;
//        ou << "64 0 0.2 0.1 1.0" << endl;
//        ou.close();

        //Parameters::readParameters(s2);

        ////////m_semAllDone = new wxSemaphore();
//        ThreadGTM tgtm(this);
//        tgtm.InitValues(s2,namefileData,
//                        dim1_W_init, dim2_W_init, dim1_W_end, dim2_W_end,
//                        dim1_W_last, dim2_W_last, dim1_M, dim2_M, sM,
//                        type_gtm, beta);
//
//        if ( tgtm.Create() != wxTHREAD_NO_ERROR )
//        {
//            wxMessageBox(wxT("Can't create GTM thread!?"));
//            wxLogError(wxT("Can't create GTM thread!"));
//        }
//        if ( tgtm.Run() != wxTHREAD_NO_ERROR )
//        {
//            wxMessageBox(wxT("Can't run GTM thread!?"));
//            wxLogError(wxT("Can't start GTM thread!"));
//        }
//        //tgtm.Resume();
//        //tgtm.Wait();
//        //tgtm.Delete();
//
//        m_semAllDone->Wait();

//
        tgtm = new ThreadGTM (this);

        char* namefileInitW = new char[256];
        strcpy(namefileInitW,s2);
        strcat(namefileInitW,name_file_initW);

        tgtm->InitValues(s2,namefileData,
                         dim1_W_init, dim2_W_init, dim1_W_end, dim2_W_end,
                         dim1_W_last, dim2_W_last, evaluate_last, dim1_M, dim2_M, sM,
                         GTM::GetPHITYPE(str_type_basisPhi),
                         GTM::GetINITTYPE(str_type_initW), namefileInitW,
                         type_gtm, beta);
                          /*GTM::PHINL_ONLY*/

        if ( tgtm->Create() != wxTHREAD_NO_ERROR )
        {
            wxMessageBox(wxT("Can't create GTM thread!?"));
            wxLogError(wxT("Can't create GTM thread!"));
        }

        int delta1=dim1_W_end-dim1_W_init;
        int delta2=dim2_W_end-dim2_W_init;
        int delta_max=delta1;
        if (delta2>delta1)
        {
            delta_max=delta2;
        }
        int n_step = abs(delta_max)+1;
        if (dim1_W_last!=dim1_W_end  || dim2_W_last!=dim2_W_end)
        {
            n_step++;
        }

        if ( tgtm->Run() != wxTHREAD_NO_ERROR )
        {
            wxMessageBox(wxT("Can't run GTM thread!?"));
            wxLogError(wxT("Can't start GTM thread!"));
        }

        m_dlgProgress = new wxProgressDialog
        (
            _T("Progress dialog"),
            _T("Wait until estimation terminates"),
            n_step,
            this,
//            wxPD_CAN_ABORT |
            wxPD_APP_MODAL //|
//            wxPD_ELAPSED_TIME //|
//           wxPD_ESTIMATED_TIME |
//           wxPD_REMAINING_TIME
        );
        m_dlgProgress->ShowModal();

//        wxCommandEvent event( wxEVT_COMMAND_MENU_SELECTED, THREAD_START_WORKER );
//        wxPostEvent( this, event );


//        Data d;
//        d.readData(namefileData);
//        GTM* gtm = new GTM(s2);
//
//        DoGTM(gtm, d,
//              dim1_W_init, dim2_W_init, dim1_W_end, dim2_W_end,
//              dim1_W_last, dim2_W_last, dim1_M, dim2_M, sM,
//              type_gtm, beta);
//
//
//        // Read all from files
//        Data* data = new Data();
//        data->readData(Parameters::get_namefiledata());
//        data->readRowClass(Parameters::get_namefilelabel());
//        data->readReducMap(Parameters::get_workDirectory(),
//                           Parameters::get_xdim(),
//                           Parameters::get_ydim());
//
//        m_canvas->getControler()->setData(data);
//        Refresh(false);
    }
}

void AppliFrame::OnUpdateThreadGTM(wxUpdateUIEvent& event)
{
    event.Enable( m_dlgProgress == NULL );
}

void AppliFrame::OnThreadGTMEvent(wxCommandEvent& event)
{
    int n = event.GetInt();
    if ( n == -1 )
    {
        if (m_dlgProgress != (wxProgressDialog*)NULL)
        {
            m_dlgProgress->Destroy();
            m_dlgProgress = (wxProgressDialog *)NULL;
        }
        //if (tgtm != (ThreadGTM *)NULL) {tgtm->Delete();}
        // the dialog is aborted because the event came from another thread, so
        // we may need to wake up the main event loop for the dialog to be
        // really closed
        wxWakeUpIdle();
        // -------------------

        std::string nomtr((char const*)workDirectory.mb_str(*wxConvCurrent));
        const char* s = nomtr.c_str();
        char* s2=new char[strlen(s)+1];
        strcpy(s2,s);

        updateParameters();
        //Parameters::readParameters(s2);

        Data* data = new Data();
        data->readData(Parameters::get_namefiledata());
        data->readRowClass(Parameters::get_namefilelabel());
        data->readReducMap(Parameters::get_workDirectory(),
                           Parameters::get_xdim(),
                           Parameters::get_ydim());

        m_canvas->getControler()->setData(data);
        Refresh(false);
//        m_canvas->getLowRenderer()->constructColorMap();
//        m_canvas->getLowRenderer()->setNeedUpdateAll();
//        Refresh(false);
    }
    else
    {
        if (m_dlgProgress != (wxProgressDialog*)NULL)
        {
            if ( !m_dlgProgress->Update(n) )
            {
                //wxCriticalSectionLocker lock(m_critsectWork);

                //m_cancelled = true;
            }
        }
    }
}

void AppliFrame::OnCloseProject( wxCommandEvent& WXUNUSED(event) )
{
//
}

void AppliFrame::OnSaveProject( wxCommandEvent& WXUNUSED(event) )
{
//
}

//void AppliFrame::OnExecuteVIZ( wxCommandEvent& WXUNUSED(event) )
//{
////
//}
//
//void AppliFrame::OnExecutePCA( wxCommandEvent& WXUNUSED(event) )
//{
////
//}
//
//void AppliFrame::OnExecuteGTM( wxCommandEvent& WXUNUSED(event) )
//{
//
//}

void AppliFrame::OnAPropos( wxCommandEvent& WXUNUSED(event) )
{
    wxMessageDialog dialog(this,
                           _T("GTM 3d application (v0.3)\n")
                           _T("(c)  2009, Rodolphe Priam\n")
                           _T("Contact: rpriam@gmail.com\n"),
                           _T("About"),
                           wxOK | wxICON_INFORMATION);
    dialog.ShowModal();
}

/*static*/
AppliFrame *AppliFrame::Create(AppliFrame *parentFrame, bool isCloneWindow)
{
    wxString str = wxT("GTM3D");
    if (isCloneWindow) str += wxT(" - Clone");

    AppliFrame *frame = new AppliFrame(NULL, str, wxDefaultPosition,
                                       wxSize(800, 600));

    // Make a menubar
    wxMenu *winMenu = new wxMenu;
//    winMenu->Append(ID_OPEN_DIRECTORY, _T("&Open Directory"));
    winMenu->Append(ID_OPEN_PROJECT, _T("Open Project"));
    winMenu->Append(ID_CREATE_PROJECT, _T("Create &Project"));
//    winMenu->Append(ID_CLOSE_PROJECT, _T("Close Project"));
//    winMenu->Append(ID_SAVE_PROJECT, _T("Save Project"));
    winMenu->Append(wxID_EXIT, _T("Quit"));

//    wxMenu *algoMenu = new wxMenu;
//    algoMenu->Append(ID_EXECUTE_VIZ, _T("Viz &Data"));
//    algoMenu->Append(ID_EXECUTE_PCA, _T("Viz &Pca"));
//    algoMenu->Append(ID_EXECUTE_GTM, _T("Viz &Gtm"));

    wxMenu *diversMenu = new wxMenu;
    diversMenu->Append(ID_APROPOS, _T("About"));

    wxMenuBar *menuBar = new wxMenuBar;
    menuBar->Append(winMenu, _T("File"));
//    menuBar->Append(algoMenu, _T("&Methods"));
    menuBar->Append(diversMenu, _T("Help"));

    frame->SetMenuBar(menuBar);

    Renderer3D* glC3D=NULL;
    if (parentFrame)
    {
        glC3D = new Renderer3D( frame, parentFrame->m_canvas,
                                wxID_ANY, wxDefaultPosition, wxDefaultSize );
    }
    else
    {
        glC3D = new Renderer3D(frame, wxID_ANY, wxDefaultPosition, wxDefaultSize);
    }

    LowRenderer* l = new LowRenderer();   // Low level View (OpenGL)
    Controler* c = new Controler();       // Control
    glC3D->initCL(c,l);                   // View
    c->setRenderer3D(glC3D);              // <-->

    //frame->InitData(glC3D);

    //frame->m_canvas
    frame->m_canvas=glC3D;

    // Show the frame
    frame->Show(true);

    return frame;
}

void AppliFrame::updateParameters() {
        std::string nomtr((char const*)workDirectory.mb_str(*wxConvCurrent));
        const char* s = nomtr.c_str();
        char* s2=new char[strlen(s)+1];
        strcpy(s2,s);
        char* namefileInit3d = new char[256];
        strcpy(namefileInit3d,s2);
        strcat(namefileInit3d,"gtm3d.ini");

        CreateFileIniGTM3DDialog* cpd3D = new CreateFileIniGTM3DDialog(this, wxT("Parameters setting"));

        float Xmin, Xmax, Ymin, Ymax, Zmin, Zmax;
        float Bsiz;
        int illum;
        int m2, m3, d2, d3, d4;
        float col1R, col2R, col3R, col4R;
        float col1G, col2G, col3G, col4G;
        float col1B, col2B, col3B, col4B;

        int aux;

        ifstream in;
        in.open(namefileInit3d);  // NEED TEST TO CHECK IF FILE EXIST !!!!!!!!!!
        //if (in.exist()
        in >> Xmin;
        in >> Xmax;
        in >> Ymin;
        in >> Ymax;
        in >> Zmin;
        in >> Zmax;
        in >> Bsiz;
        in >> illum;
        in >> aux;
        in >> aux;
        in >> col1R;
        in >> col1G;
        in >> col1B;
        in >> m2;
        in >> d2;
        in >> col2R;
        in >> col2G;
        in >> col2B;
        in >> m3;
        in >> d3;
        in >> col3R;
        in >> col3G;
        in >> col3B;
        in >> aux;
        in >> d4;
        in >> col4R;
        in >> col4G;
        in >> col4B;
        in.close();

        cpd3D->set_xmin(wxString::Format(wxT("%f"),Xmin));
        cpd3D->set_xmax(wxString::Format(wxT("%f"),Xmax));
        cpd3D->set_ymin(wxString::Format(wxT("%f"),Ymin));
        cpd3D->set_ymax(wxString::Format(wxT("%f"),Ymax));
        cpd3D->set_zmin(wxString::Format(wxT("%f"),Zmin));
        cpd3D->set_zmax(wxString::Format(wxT("%f"),Zmax));
        cpd3D->set_size(wxString::Format(wxT("%f"),Bsiz));
        cpd3D->set_illum(wxString::Format(wxT("%i"),illum));

        cpd3D->set_col1R(wxString::Format(wxT("%f"),col1R));
        cpd3D->set_col2R(wxString::Format(wxT("%f"),col2R));
        cpd3D->set_col3R(wxString::Format(wxT("%f"),col3R));
        cpd3D->set_col4R(wxString::Format(wxT("%f"),col4R));
        cpd3D->set_col1G(wxString::Format(wxT("%f"),col1G));
        cpd3D->set_col2G(wxString::Format(wxT("%f"),col2G));
        cpd3D->set_col3G(wxString::Format(wxT("%f"),col3G));
        cpd3D->set_col4G(wxString::Format(wxT("%f"),col4G));
        cpd3D->set_col1B(wxString::Format(wxT("%f"),col1B));
        cpd3D->set_col2B(wxString::Format(wxT("%f"),col2B));
        cpd3D->set_col3B(wxString::Format(wxT("%f"),col3B));
        cpd3D->set_col4B(wxString::Format(wxT("%f"),col4B));
        cpd3D->set_m2(wxString::Format(wxT("%i"),m2));
        cpd3D->set_m3(wxString::Format(wxT("%i"),m3));

        cpd3D->set_d2(wxString::Format(wxT("%i"),d2));
        cpd3D->set_d3(wxString::Format(wxT("%i"),d3));
        cpd3D->set_d4(wxString::Format(wxT("%i"),d4));

        cpd3D->ShowModal();

        Xmin = cpd3D->get_xmin();
        Xmax = cpd3D->get_xmax();
        Ymin = cpd3D->get_ymin();
        Ymax = cpd3D->get_ymax();
        Zmin = cpd3D->get_zmin();
        Zmax = cpd3D->get_zmax();
        Bsiz = cpd3D->get_size();
        illum = cpd3D->get_illum();
        col1R = cpd3D->get_col1R();
        col1G = cpd3D->get_col1G();
        col1B = cpd3D->get_col1B();
        m2 = cpd3D->get_m2();
        d2 = cpd3D->get_d2();
        col2R = cpd3D->get_col2R();
        col2G = cpd3D->get_col2G();
        col2B = cpd3D->get_col2B();
        m3 = cpd3D->get_m3();
        d3 = cpd3D->get_d3();
        col3R = cpd3D->get_col3R();
        col3G = cpd3D->get_col3G();
        col3B = cpd3D->get_col3B();
        d4 = cpd3D->get_d4();
        col4R = cpd3D->get_col4R();
        col4G = cpd3D->get_col4G();
        col4B = cpd3D->get_col4B();
        // Read all from files

        ofstream ou;
        ou.open(namefileInit3d);
        ou << Xmin << endl;
        ou << Xmax << endl;
        ou << Ymin << endl;
        ou << Ymax << endl;
        ou << Zmin << endl;
        ou << Zmax << endl;
        ou << Bsiz << endl;
        ou << illum << endl;
        ou << "1"   << " " << "0"  << " " << col1R << " " << col1G << " " << col1B << endl;
        ou << m2    << " " << d2   << " " << col2R << " " << col2G << " " << col2B << endl;
        ou << m3    << " " << d3   << " " << col3R << " " << col3G << " " << col3B << endl;
        ou << "64"  << " " << d4   << " " << col4R << " " << col4G << " " << col4B << endl;
        ou.close();

        Parameters::readParameters(s2);
        m_canvas->getLowRenderer()->constructColorMap();
        m_canvas->getControler()->updateObjects3D_Map();
        m_canvas->getLowRenderer()->setNeedUpdateAll();
        delete [] namefileInit3d;
}

//void AppliFrame::OnNewWindow( wxCommandEvent& WXUNUSED(event) )
//{
//    (void) Create(this, true);
//}
//
//void AppliFrame::OnDefRotateLeftKey( wxCommandEvent& WXUNUSED(event) )
//{
//    ScanCodeDialog dial( this, wxID_ANY, m_canvas->m_rleft,
//        wxString(_T("Left")), _T("Define key") );
//
//    int result = dial.ShowModal();
//
//    if( result == wxID_OK )
//        m_canvas->m_rleft = dial.GetValue();
//}
//
//void AppliFrame::OnDefRotateRightKey( wxCommandEvent& WXUNUSED(event) )
//{
//    ScanCodeDialog dial( this, wxID_ANY, m_canvas->m_rright,
//        wxString(_T("Right")), _T("Define key") );
//
//    int result = dial.ShowModal();
//
//    if( result == wxID_OK )
//        m_canvas->m_rright = dial.GetValue();
//}

BEGIN_EVENT_TABLE(AppliFrame, wxFrame)
    EVT_MENU(wxID_EXIT, AppliFrame::OnExit)
    //    EVT_MENU(ID_OPEN_DIRECTORY, AppliFrame::OnOpenDirectory)
    EVT_MENU(ID_CREATE_PROJECT, AppliFrame::OnCreateProject)
    EVT_MENU(ID_OPEN_PROJECT, AppliFrame::OnOpenProject)
    //    EVT_MENU(ID_CLOSE_PROJECT, AppliFrame::OnCloseProject)
    //    EVT_MENU(ID_SAVE_PROJECT, AppliFrame::OnSaveProject)
    //    EVT_MENU(ID_EXECUTE_GTM, AppliFrame::OnExecuteGTM)
    //    EVT_MENU(ID_EXECUTE_PCA, AppliFrame::OnExecutePCA)
    //    EVT_MENU(ID_EXECUTE_VIZ, AppliFrame::OnExecuteVIZ)
    EVT_MENU(ID_APROPOS, AppliFrame::OnAPropos)
    //    EVT_MENU( ID_NEW_WINDOW, AppliFrame::OnNewWindow)
    //    EVT_MENU( ID_DEF_ROTATE_LEFT_KEY, AppliFrame::OnDefRotateLeftKey)
    //    EVT_MENU( ID_DEF_ROTATE_RIGHT_KEY, AppliFrame::OnDefRotateRightKey)
    EVT_UPDATE_UI(ID_CREATE_PROJECT, AppliFrame::OnUpdateThreadGTM)
    //EVT_UPDATE_UI(THREAD_START_WORKER, AppliFrame::OnUpdateThreadGTM)
    //EVT_MENU(THREAD_START_WORKER, AppliFrame::OnStartThreadGTM)
    EVT_MENU(WORKER_EVENT, AppliFrame::OnThreadGTMEvent)
END_EVENT_TABLE()
