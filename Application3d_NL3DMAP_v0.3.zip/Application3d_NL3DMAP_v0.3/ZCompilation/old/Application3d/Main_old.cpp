#include <windows.h>
#include <fstream.h>
#include "Interface/LOG.h"
#include "Interface/WINDOW.h"
#include "Interface/HighRenderer.h"
#include "Interface/Data.h"
#include "Interface/libs.h"
#include "Interface/INIT_PARAM.h"
#include "Main.h"

//link to libraries
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "winmm.lib")

class LIBS; //class INIT_PARAM;

int WINAPI WinMain(	HINSTANCE	hInstance,				//instance
					HINSTANCE	hPrevInstance,			//Previous Instance
					LPSTR		lpCmdLine,				//command line parameters
					int			nCmdShow)				//Window show state
{
    // work directory on command line
    char* workDirectory = (char *)new char(strlen(lpCmdLine)) ;
	strcpy(workDirectory,lpCmdLine);
	strtok(workDirectory," \t");

    // reading gtm.ini file    
    INIT_PARAM::readParameters(workDirectory);

    // readinf data    
    Data* data = new Data();
    data->readData(INIT_PARAM::get_namefiledata());
    data->readRowClass(INIT_PARAM::get_namefilelabel());
    data->readReducMap(INIT_PARAM::get_workDirectory(),
                        INIT_PARAM::get_xdim(),INIT_PARAM::get_ydim());
    
    // launch view 3d !
    HighRenderer* rd = new HighRenderer(data);
	rd->setConstants(-3.5f, 3.5f, -3.5f, 3.5f, -3.5f, 3.5f);
	
	if (!rd->allInit()) {return 0;} //init all Renderer .........          
	for(;;)   //Main Loop
	{
		if(!rd->handleMessagesWindow()) break;//check handle windows messages
		rd->paint();
	}
	rd->allEnd();// .................. end all Renderer .........
    // end of view 3d !
    	
	return (rd->messageWindow());								//Exit The Program
}
//MessageBox (NULL, "Title", "HelloMsg", 0) ;
    
