#include"GTM.h"
#include <time.h>

int GTM::INIT_PCA    = 0;
int GTM::INIT_RANDOM = 1;
int GTM::INIT_FILE   = 2;
int GTM::INIT_DONE   = 3;

GTM::GTM(char* _w)
{
    workDirectory = new char[strlen(_w)+1];
    strcpy(workDirectory,_w);
}

void GTM::updateSizeVariables(int _xdimK, int _ydimK, double _sM)
{
    xdim   = _xdimK;
    ydim   = _ydimK;
    K      = _xdimK*_ydimK;
    sM     = _sM;
}

void GTM::setVariables(int _I,
                       int _J,
                       double** tabdata,
                       int _xdimK,
                       int _ydimK,
                       int _xdimM,
                       int _ydimM,
                       double _sM)//,
//double _epsilon)
{
    I      = _I;
    J      = _J;
    xdim   = _xdimK;
    ydim   = _ydimK;
    xdimM  = _xdimM;
    ydimM  = _ydimM;
    sM     = _sM;
    //epsilon = _epsilon;

    K=xdim*ydim;
    M=xdimM*ydimM;

    data = Matrix(I,J);

    int i,j;
    for (i=0; i<I; i++)
    {
        for (j=0; j<J; j++)
        {
            data(i+1,j+1)=tabdata[i][j];
        }
    }

    //pDis     = Matrix(I,2);
    A_3d=Matrix(I,3);
    A_3d_U=Matrix(I,3);
    A_3d_D=Matrix(I,3);

    W        = Matrix(J,M);

    mean_js  = ColumnVector(J);
    sigma_js = ColumnVector(J);
    sigmas   = ColumnVector(100*T_MAX);
    logLs    = ColumnVector(100*T_MAX);
    erreurKs = ColumnVector(100*T_MAX);
    for (int t=0; t<100*T_MAX; t++)
    {
        sigmas(t+1)=0;
        logLs(t+1)=0;
        erreurKs(t+1)=0;
    }
    t_end=100*T_MAX; // last t in the learning loop

    //cerr << "FIN INIT !!" << endl;
}

int GTM::get_n()
{
    return I;
}

int GTM::get_p()
{
    return J;
}

int GTM::get_tend()
{
    return t_end;
}

double GTM::get_L()
{
    return logLs(t_end);
}

double GTM::get_sigma()
{
    return sigmas(t_end);
}

double GTM::get_sM()
{
    return sM;
}

//double GTM::get_epsilon() {
//    return epsilon;
//}

void GTM::apprentissage_init(int type_init, double** mk_init, bool save)
{
    // init size matrix
    Mk_init  = Matrix(K,J);
    Mk_init_2d  = Matrix(K,2);
    Mk       = Matrix(K,J);
    Pik      = Matrix(I,K);
    Sk       = Matrix(K,2);
    Phi      = Matrix(K,M);
    D_matrix = Matrix(K,3);
    U_matrix = Matrix(K,3);
    
    // init values matrix
    init_Sk();
    init_Phi_nonlineaire();
    if (type_init==INIT_RANDOM)
    {
        init_W_alea();
    }
    else if (type_init==INIT_PCA)
    {
        init_W_parACP();
    }
    else if (type_init==INIT_FILE)
    {
        int k,j;
        for (k=0; k<K; k++)
        {
            for (j=0; j<J; j++)
            {
                Mk_init(k+1,j+1)=mk_init[k][j];
            }
        }
        W = ((Phi.t()*Phi+IdentityMatrix(M)*EPSILON).i()*Phi.t()*Mk_init).t();
        evaluer_mk();
    }
    else if (type_init==INIT_DONE)
    {
        evaluer_mk(); // use current W (already calculated) !
    }
    else
    {
        return;
    }
    
    //evaluer_mk();
    cout << "begin pki_kmeans !" << endl;
    calculer_pki_kmeans();
    cout << "init pki_kmeans passed !" << endl;
    
    //evaluer_mk();
    cout << "begin sigma !" << endl;
    calculer_sigma();
    cout << "init sigma passed !" << endl;

    cout << "begin mapping all !" << endl;
    calculer_mapping3D_all();
    cout << "init mapping all passed !" << endl;
    if (save)
    {
        sauvegarde_init();    // save ACP map
    }
    cout << "init vars passed (end) !" << endl;
}

void GTM::apprentissage(int aff)
{
    calculer_logvraisemblance();
    static int t=0;
    int t0=t;
    
    bool end=false;
    for (;t-t0<T_MAX && !end ;t++)
    {
        calculer_pki();
        calculer_mk_et_sigma();
        sigmas(t+1) = sigma;
        logLs(t+1)  = calculer_logvraisemblance();
        if (aff==1||aff==2)
        {
            cout << t << " " << logLs(t+1) << " " << sigmas(t+1) <<  " " << sM << endl;
        }
        if (t>0)
        {
            if (fabs(logLs(t+1)-logLs(t))/fabs(logLs(t))<1E-9)
            {
                end=true;
                t_end=t+1;
            }
        }
    }
    if (aff==2||aff==3) {cout << "t_end=" << t_end << " L=" << logLs(t_end) << " sigma=" << sigmas(t_end) << " sM=" << sM << endl;}
}

void GTM::stocha_move_sM(int t)
{
    double L0=logLs(t+1);
    double sigma0=sigmas(t+1);
    double sM0=sM;

    int sens = 2*((float)rand()/(1.0+RAND_MAX)>0.5)-1;
    Matrix Phi0=Phi;
    Matrix Mk0=Mk;
    double L=0;

    sM = sM + sens * 0.01;
    if (sM<0.01) sM=0.01;

    init_Phi_nonlineaire();
    calculer_mk();
    calculer_sigma();
    L=calculer_logvraisemblance();
    if (L>L0)
    {
        logLs(t+1) = L;
        sigmas(t+1)=sigma;
    }
    else
    {
        sM=sM0;
        Phi=Phi0;
        Mk=Mk0;
        sigma=sigma0;
    }
}

void GTM::sauvegarde_init()
{
    char* w = workDirectory;
    char* n = new char[256];
    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_2d_ACP.txt"),A_3d,I,2);

    for (int k=0; k<K; k++)
    {
        for (int j=0; j<J; j++)
        {
            Mk(k+1,j+1) = Mk(k+1,j+1) * sigma_js(j+1) + mean_js(j+1);
        }
    }
    strcpy(n,w);
    sauvegarder_p(strcat(n,"Mk_ACP.txt"),Mk,K,J);
    for (int k=0; k<K; k++)
    {
        for (int j=0; j<J; j++)
        {
            Mk(k+1,j+1) = (Mk(k+1,j+1)-mean_js(j+1))/sigma_js(j+1);
        }
    }

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Dmat_ACP.txt"),D_matrix,K,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Umat_ACP.txt"),U_matrix,K,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_3dD_ACP.txt"),A_3d_D,I,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_3dU_ACP.txt"),A_3d_U,I,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Pik_ACP.txt"),Pik,I,K);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"W_ACP.txt"),W,J,M);
}

void GTM::sauvegarde()
{
    char* w = workDirectory;
    char* n = new char[256];
    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_2d.txt"),A_3d,I,2);

    for (int k=0; k<K; k++)
    {
        for (int j=0; j<J; j++)
        {
            Mk(k+1,j+1) = Mk(k+1,j+1) * sigma_js(j+1) + mean_js(j+1);
        }
    }
    strcpy(n,w);
    sauvegarder_p(strcat(n,"Mk.txt"),Mk,K,J);
    for (int k=0; k<K; k++)
    {
        for (int j=0; j<J; j++)
        {
            Mk(k+1,j+1) = (Mk(k+1,j+1)-mean_js(j+1))/sigma_js(j+1);
        }
    }

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Sk.txt"),Sk,K,2);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Dmat.txt"),D_matrix,K,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Umat.txt"),U_matrix,K,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_3dD.txt"),A_3d_D,I,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Si_3dU.txt"),A_3d_U,I,3);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Pik.txt"),Pik,I,K);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"W.txt"),W,J,M);

    strcpy(n,w);
    sauvegarder_p(strcat(n,"Phi.txt"),Phi,K,M);

    strcpy(n,w);
    sauvegarder_v(strcat(n,"Sigmas.txt"),sigmas,T_MAX);

    strcpy(n,w);
    sauvegarder_v(strcat(n,"LogLs.txt"),logLs,T_MAX);

    strcpy(n,w);
    sauvegarder_params(strcat(n,"Params.txt"));

    /*
    sauvegarder_p("../IO/out/Si_2d.txt",A_3d,I,2);
    sauvegarder_p("../IO/out/Mk.txt",Mk,K,J);
    sauvegarder_p("../IO/out/Sk.txt",Sk,K,2);

    sauvegarder_p("../IO/out/Dmat.txt",D_matrix,K,3);
    sauvegarder_p("../IO/out/Umat.txt",U_matrix,K,3);

    sauvegarder_p("../IO/out/Si_3dD.txt",A_3d_D,I,3);
    sauvegarder_p("../IO/out/Si_3dU.txt",A_3d_U,I,3);

    sauvegarder_p("../IO/out/Pik.txt",Pik,I,K);
    sauvegarder_p("../IO/out/W.txt",W,J,M);
    sauvegarder_p("../IO/out/Phi.txt",Phi,K,M);
    sauvegarder_v("../IO/out/Sigmas.txt",sigmas,T_MAX);
    sauvegarder_v("../IO/out/LogLs.txt",logLs,T_MAX);

    sauvegarder_params("../IO/out/Mapsize.txt","../IO/out/Params.txt");
    */

    // Debut : sauvegardes
    //sauvegarder_p("./out/Phi.txt",Phi,K,M);
    //sauvegarder_p("./out/W.txt",W,J,M);
    //sauvegarder_p("./out/Mk.txt",Mk,K,J);
    //sauvegarder_p("./out/Pik.txt",Pik,I,K);
    //sauvegarder_v("./out/Pk.txt",Pk,K);
    //sauvegarder_v("./out/LogLs.txt",logLs,T_MAX);
    //sauvegarder_v("./out/Sigmas.txt",sigmas,T_MAX);
    //sauvegarder_v("./out/EKintras.txt",erreurKs,T_MAX);

    //system("images2mpg -f VCD -d 1 -o ./out/em_3.mpg -i out/images/*.jpeg");
}

void GTM::calculer_mapping2D()
{
    for (int i=0; i<I; i++)
    {
        A_3d(i+1,0+1)=0;
        A_3d(i+1,1+1)=0;
        for (int k=0; k<K; k++)
        {
            A_3d(i+1,0+1)= A_3d(i+1,0+1) + Pik(i+1,k+1)*Sk(k+1,1);
            A_3d(i+1,1+1)= A_3d(i+1,1+1) + Pik(i+1,k+1)*Sk(k+1,2);

            A_3d_U(i+1,0+1)=A_3d(i+1,0+1);
            A_3d_U(i+1,0+2)=A_3d(i+1,0+2);
            A_3d_D(i+1,0+1)=A_3d(i+1,0+1);
            A_3d_D(i+1,0+2)=A_3d(i+1,0+2);
        }
    }
}

double** GTM::get_mapping2D()
{
    int i,k;
    double** pDi_hat = (double**)malloc(sizeof(double)*I);
    for (i=0; i<I; i++)
        pDi_hat[i]=(double*)malloc(sizeof(double)*2);
    for (i=0; i<I; i++)
    {
        pDi_hat[i][0]= A_3d(i+1,0+1);
        pDi_hat[i][1]= A_3d(i+1,1+1);
    }
    return pDi_hat;
}

void GTM::calculer_mapping3D_all()
{
    calculer_mapping2D();
    calculer_umap();
    calculer_density();

    calculer_mapping3D(U_matrix, A_3d_U);
    calculer_mapping3D(D_matrix, A_3d_D);

}

void GTM::calculer_mapping3D(const Matrix &_matrix, Matrix &A_3d)
{
    int kp, xp, yp;

    for (int i=0; i<I; i++)
    {
        kp=-1;
        for (int y=0; y<ydim-1 && kp<0; y++)
        {
            for (int x=0; x<xdim-1 && kp<0; x++)
            {
                int k=y*xdim+x+1;
                if (A_3d(i+1,1)>=Sk(k,1)&& A_3d(i+1,1)<=Sk(k+1,1) && A_3d(i+1,2)>=Sk(k,2)&& A_3d(i+1,2)<=Sk(k+xdim,2))
                {
                    kp=k;
                    xp=x;
                    yp=y;
//               cout << setw(5) << setprecision(4) << Sk(k,1) << "\t";
//               cout << "<" << setw(5) << setprecision(4) << A_3d(i+1,1) << "<" << "\t";
//               cout << setw(5) << setprecision(4) << Sk(k+1,1) << endl;
//               cout << setw(5) << setprecision(4) << Sk(k,2) << "\t";
//               cout << "<" << setw(5) << setprecision(4) << A_3d(i+1,2) << "<" << "\t";
//               cout << setw(5) << setprecision(4) << Sk(k+xdim,2) << endl;
//               //cout << setw(5) << setprecision(2) << umap[2*x][2*y];
//               cout << endl;
                }
            }
        }
        //cout << kp << " ";
        double x1, y1, z1, x2, y2, z2, x3, y3, z3, a , b, c;
        double val_test = (A_3d(i+1,1)-Sk(kp,1))*(A_3d(i+1,1)-Sk(kp,1))-(A_3d(i+1,1)-Sk(kp+xdim+1,1))*(A_3d(i+1,1)-Sk(kp+xdim+1,1));
//      if (fabs(val_test)>1e-5) {

        if ((A_3d(i+1,1)-Sk(kp,1))*(A_3d(i+1,1)-Sk(kp,1))<(A_3d(i+1,1)-Sk(kp+xdim+1,1))*(A_3d(i+1,1)-Sk(kp+xdim+1,1)))
        {
            x1=Sk(kp,1);
            y1=Sk(kp,2);
            z1=_matrix(kp,3);
            x2=Sk(kp+1,1);
            y2=Sk(kp+1,2);
            z2=_matrix(kp+1,3);
            x3=Sk(kp+xdim,1);
            y3=Sk(kp+xdim,2);
            z3=_matrix(kp+xdim,3);
            a= ((z3-z2)/(y3-y2)-(z3-z1)/(y3-y1));
            a = a /((x3-x2)/(y3-y2)-(x3-x1)/(y3-y1));

            b= (z3-z1)/(y3-y1) - a * (x3-x1)/(y3-y1);
            c= z1 - a * x1 - b * y1;
        }
        else
        {
            x1=Sk(kp+xdim+1,1);
            y1=Sk(kp+xdim+1,2);
            z1=_matrix(kp+xdim+1,3);
            x2=Sk(kp+1,1);
            y2=Sk(kp+1,2);
            z2=_matrix(kp+1,3);
            x3=Sk(kp+xdim,1);
            y3=Sk(kp+xdim,2);
            z3=_matrix(kp+xdim,3);
            a= ((z3-z2)/(y3-y2)-(z2-z1)/(y2-y1));
            a = a /((x3-x2)/(y3-y2)-(x2-x1)/(y2-y1));
            b= (z3-z2)/(y3-y2) - a * (x3-x2)/(y3-y2);
            c= z1 - a * x1 - b * y1;
        }

        //      cout << x1 << " " << y1 << " " << z1 << " ";
        //      cout << x2 << " " << y2 << " " << z2 << " ";
        //      cout << x3 << " " << y3 << " " << z3 << " ";
        //      cout << endl;
        //      cout << a << " " << b << " " << c << endl;


        A_3d(i+1,3) = a * A_3d(i+1,1) + b * A_3d(i+1,2)+c;
//          if (A_3d(i+1,3) > 1e5) {
//            cout << "BUG density matrix! " << i << "->[" << a << "|" << b << "|" << c << "]" << endl;
//          }
//      } else {
//          A_3d(i+1,3)=Sk(kp,3);
//      }
        //cout << A_3d(i+1,3) << " " << z1 << " " << z2 << " " << z3 << endl;
    }
}

double** GTM::get_mapping3D()
{
    int i,k;
    double** pDi_hat = (double**)malloc(sizeof(double)*I);
    for (i=0; i<I; i++)
        pDi_hat[i]=(double*)malloc(sizeof(double)*3);
    for (i=0; i<I; i++)
    {
        pDi_hat[i][0]= A_3d(i+1,0+1);
        pDi_hat[i][1]= A_3d(i+1,1+1);
        pDi_hat[i][2]= A_3d(i+1,2+1);
    }
    return pDi_hat;
}

void GTM::calculer_umap()
{
    int k,kv,j;
    for (int y=0; y<ydim; y++)
    {
        for (int x=0; x<xdim; x++)
        {
            //cerr << x << " " << y << endl;
            k=y*xdim+x;
            U_matrix(k+1,3)=1e-12;
        }
    }

    for (int y=0; y<ydim; y++)
    {
        for (int x=0; x<xdim; x++)
        {
            k=y*xdim+x;
            int nv=0;
            for (int dx=-1; dx<3; dx+=2)
            {
                for (int dy=-1; dy<3; dy+=2)
                {
                    if (x+dx>=0 && x+dx<xdim && y+dy>=0 && y+dy<ydim)
                    {
                        nv++;
                        kv=(y+dy)*xdim+x+dx;
                        //cerr << 2*x+dx << " " << 2*y+dy << endl;
                        Real d=0;
                        for (int j=0; j<J; j++)
                        {
                            d = d + (Mk(k+1,j+1)-Mk(kv+1,j+1))*(Mk(k+1,j+1)-Mk(kv+1,j+1));
                        }
                        U_matrix(k+1,3)= U_matrix(k+1,3) + d;
                    }
                }
            }
            if (nv>0)
            {
                U_matrix(k+1,3)=sqrt(U_matrix(k+1,3)/nv);
            }
        }
    }
}

// -----------------------------------------------------------------

void GTM::calculer_density()
{
    for (int y=0; y<ydim; y++)
    {
        for (int x=0; x<xdim; x++)
        {
            int k=y*xdim+x;
            D_matrix(k+1,3)=1e-12;
        }
    }
    
    //calculer_pki_kmeans();
    for (int y=0; y<ydim; y++)
    {
        for (int x=0; x<xdim; x++)
        {
            int k=y*xdim+x;
            for (int i=0; i<I; i++)
            {
                
                D_matrix(k+1,3) = D_matrix(k+1,3)+Pik(i+1,k+1);
                //if (Pik(i+1,k+1)>0.5)
                //{
                //    D_matrix(k+1,3)=D_matrix(k+1,3)+1;
                //}
            }
            //D_matrix(k+1,3) = D_matrix(k+1,3)/K;
        }
    }
//    calculer_pki();
}

// -----------------------------------------------------------------

double GTM::max(double a, double b)
{
    double m=a;
    if (a<b)
    {
        m=b;
    }
    return m;
}

void GTM::generer_data()
{
    int i,j;
    for (i=0; i<I; i++)
    {
        for (j=0; j<J; j++)
        {
            //data(i+1,j+1) = i%3+2 +rand()/(1.0+RAND_MAX)/100;
            data(i+1,j+1)=rand()/(1.0+RAND_MAX);
        }
    }
}

void GTM::lire_data(char *s)
{
    int i,j;
    ifstream in(s);
    for (i=0; i<I; i++)
    {
        for (j=0; j<J; j++)
        {
            in >> data(i+1,j+1);
        }
    }
}

void GTM::lire_labels(char *s)
{
    int i;
    ifstream in(s);
    for (i=0; i<I; i++)
    {
        in >> labels(i+1);
    }
}

// ----------------- ESTIMATE -----------------------------------------------

double GTM::distance_IndivCentr_2(int i, int k)
{
    double dist=0.0f;
    for (int j=0; j<J; j++)
    {
        dist = dist + (Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
    }
    return dist;
}

double GTM::distance_IndivIndiv_2(int i1, int i2)
{
    double dist=0.0f;
    for (int j=0; j<J; j++)
    {
        dist = dist + (data(i1+1,j+1)-data(i2+1,j+1))*(data(i1+1,j+1)-data(i2+1,j+1));
    }
    return dist;
}

double GTM::distance_IndivCentr(int i, int k)
{
    return sqrt(distance_IndivCentr(i,k));
}

double GTM::distance_IndivIndiv(int i1, int i2)
{
    return sqrt(distance_IndivIndiv_2(i1,i2));
}

double GTM::distanceEuclidian_IndivCentr_2(int i, int k)
{
    double dist=0.0f;
    for (int j=0; j<J; j++)
    {
        dist = dist + (Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
    }
    return dist;
}

double GTM::distanceEuclidian_IndivIndiv_2(int i1, int i2)
{
    double dist=0.0f;
    for (int j=0; j<J; j++)
    {
        dist = dist + (data(i1+1,j+1)-data(i2+1,j+1))*(data(i1+1,j+1)-data(i2+1,j+1));
    }
    return dist;
}

double GTM::distanceEuclidian_IndivCentr(int i, int k)
{
    return sqrt(distanceEuclidian_IndivCentr(i,k));
}

double GTM::distanceEuclidian_IndivIndiv(int i1, int i2)
{
    return sqrt(distanceEuclidian_IndivIndiv_2(i1,i2));
}

void GTM::calculer_pki()
{
    int i=-1, j=-1, k=-1;
    double dmin=0;
    double pnorm=0;

    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        pnorm=0;
        for (k=0; k<K; k++)
        {
            Pik(i+1,k+1)=1e-10+distance_IndivCentr_2(i,k);
            if (Pik(i+1,k+1)<dmin)
            {
                dmin=Pik(i+1,k+1);
            }
        }
        for (k=0; k<K; k++)
        {
            Pik(i+1,k+1)=exp((-Pik(i+1,k+1)+dmin)/2/sigma/sigma);
            pnorm=pnorm+Pik(i+1,k+1);
        }
        for (k=0; k<K; k++)
        {
            Pik(i+1,k+1) = Pik(i+1,k+1)/pnorm;
        }
    }

    for (i=0; i<I; i++)
    {
        for (k=0; k<K; k++)
        {
            if (Pik(i+1,k+1)<1E-8) Pik(i+1,k+1)=1E-8;
            if (Pik(i+1,k+1)>1-1E-8) Pik(i+1,k+1)=1-1E-8;
        }
    }
}

void GTM::calculer_pki_kmeans()
{
    int i=-1, j=-1, k=-1, kmin=-1;
    double d,dmin=0;

    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        kmin=-1;
        for (k=0; k<K; k++)
        {
            d=1e-10+distance_IndivCentr_2(i,k);
            if (d<dmin)
            {
                dmin=d;
                kmin=k;
            }
        }
        for (k=0; k<K; k++)
        {
            if (k==kmin)
            {
                Pik(i+1,k+1)=1;
            }
            else
            {
                Pik(i+1,k+1)=0;
            }
        }
    }
}

void GTM::evaluer_mk()
{
    Mk = Phi*W.t();
}

void GTM::calculer_mk()
{
    int i,k;
    DiagonalMatrix G(K);
    for (k=0; k<K; k++)
    {
        G(k+1)=0;
        for (i=0; i<I; i++)
        {
            G(k+1) = G(k+1) + Pik(i+1,k+1);
        }
    }
    //
    Matrix PGP = Phi.t()*G*Phi;
    DiagonalMatrix D, Dinv;
    Matrix U, V;
    SVD(PGP,D,U,V);

//    cout << PGP(1,1) << " " << PGP(K,K) << endl << endl;
//    Matrix PGP2 = U * D * V.t();
//    cout << PGP2(1,1) << " " << PGP2(K,K) << endl << endl;
    //cout << D << endl;

    Dinv = DiagonalMatrix(M);
    for (int m=0; m<M; m++)
    {
        if (D(m+1)>1E-5)
        {
            Dinv(m+1)=(double)1/D(m+1);
        }
        else
        {
            Dinv(m+1)=0;
        }
    }
    W = ((V*Dinv*U.t()) * (Phi.t()*Pik.t()*data)).t();

    /*
    double L0=logL;
    Matrix W0=W;
    double L=1;
    double rho=10;
    do {
      W = W0 - rho * (PGP*W0.t()- Phi.t()*Pik.t()*data).t();
      evaluer_mk();
      L=calculer_logvraisemblance();
      rho=rho/10;
    } while (L<L0 || L>0);
    */
    //cout << Dinv << endl;
    //W = ((Phi.t()*G*Phi).i() * (Phi.t()*Pik.t()*data)).t();
    evaluer_mk();
}

void GTM::calculer_mk_et_sigma()
{
    // calcul des mk

    int i,k;
    DiagonalMatrix G(K);
    for (k=0; k<K; k++)
    {
        G(k+1)=0;
        for (i=0; i<I; i++)
        {
            G(k+1) = G(k+1) + Pik(i+1,k+1);
        }
    }
    //
    Matrix PGP = Phi.t()*G*Phi;
    DiagonalMatrix D, Dinv, Regul;
    Matrix U, V;
    SVD(PGP,D,U,V);

    Dinv = DiagonalMatrix(M);
    Regul = DiagonalMatrix(M);
    for (int m=0; m<M; m++)
    {
        if (D(m+1)>1E-5)
        {
            Dinv(m+1)=(double)1/D(m+1);
        }
        else
        {
            Dinv(m+1)=0;
        }
        Regul(m+1)=1;
    }

    //for (int m=0; m<M; m++) {
//       Real alpha_m=0.0;
//       Real SSW_m=0.0;
//       Real trace_m_1=0.0;
//
//       for (int k=0; k<K; k++) {
//         trace_m_1 = trace_m_1 + G(k+1)*Phi(k+1,m+1)*Phi(k+1,m+1);
//       }
//       trace_m_1=-trace_m_1/sigma/sigma;
//       trace_m_1=(double)J/trace_m_1;
//
//       for (int j=0;j<J;j++)   SSW_m = SSW_m+W(j+1,m+1)*W(j+1,m+1);
//
//       alpha_m=(Real)M/(SSW_m+trace_m_1);
//       Regul(m+1)=alpha_m;
//    }
    //cout << Regul << endl;
    W = ((V*Dinv*U.t()) * (Phi.t()*Pik.t()*data)).t();
    //W = ((V*Dinv*U.t()+1E-3*Regul/sigma/sigma) * (Phi.t()*Pik.t()*data)).t();

    evaluer_mk();

    // calcul de sigma
    double s=0;
    for (int i=0; i<I; i++)
    {
        for (int k=0; k<K; k++)
        {
            s = s + Pik(i+1,k+1)*distance_IndivCentr_2(i,k);
        }
    }
    // fin
    sigma=sqrt(s/I/J);
}

void GTM::calculer_mk_sanscontrainte()
{
    int i,j,k;
    double norm_k;
    for (k=0; k<K; k++)
    {
        norm_k=0;
        for (i=0; i<I; i++)
        {
            norm_k=norm_k+Pik(i+1,k+1);
        }
        //if (norm_k>0) {
        for (j=0; j<J; j++)
        {
            Mk(k+1,j+1)=0;
        }
        for (i=0; i<I; i++)
        {
            for (j=0; j<J; j++)
            {
                Mk(k+1,j+1) = Mk(k+1,j+1) + Pik(i+1,k+1) * data(i+1,j+1);
            }
        }
        for (j=0; j<J; j++)
        {
            Mk(k+1,j+1)= Mk(k+1,j+1) / norm_k; // + rand()/(1.0+RAND_MAX)*1E-8; // + alea !!
        }
        //} else { printf("#"); }
    }
}

void GTM::calculer_sigma()
{
    int i,j,k;
    double s=0;
    for (i=0; i<I; i++)
    {
        for (j=0; j<J; j++)
        {
            for (k=0; k<K; k++)
            {
                s = s + Pik(i+1,k+1)*(Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
            }
        }
    }
    sigma=sqrt(s/I/J);
}

// ---------------- INIT ---------------------------------------------------

void GTM::recenterData() {
    for (int j=0; j<J; j++)
    {
        for (int i=0; i<I; i++)
        {
            data(i+1,j+1)=data(i+1,j+1)*sigma_js(j+1)+mean_js(j+1);
        }
    }     
}

void GTM::init_W_parACP()
{
    int i,j,k;
    double s;
    Matrix A=Matrix(I,J);
    Matrix U=Matrix(I,J);
    DiagonalMatrix D=DiagonalMatrix(J);
    Matrix V=Matrix(J,J);
    srand(time(NULL));
    A = data;
    for (j=0; j<J; j++)
    {
        mean_js(j+1)=0;
        for (i=0; i<I; i++)
        {
            mean_js(j+1)=mean_js(j+1)+data(i+1,j+1);
        }
        mean_js(j+1)=mean_js(j+1)/I;
    }
    for (j=0; j<J; j++)
    {
        sigma_js(j+1)=0;
        for (i=0; i<I; i++)
        {
            sigma_js(j+1) = sigma_js(j+1) + (A(i+1,j+1)-mean_js(j+1))*(A(i+1,j+1)-mean_js(j+1));
        }
        sigma_js(j+1) = sqrt(sigma_js(j+1)/(I-1));
        for (i=0; i<I; i++)
        {
            A(i+1,j+1)=(A(i+1,j+1)-mean_js(j+1))/sigma_js(j+1);
        }
    }
    data=A;
    SVD(A,D,U,V);
    Matrix A_2d = U.Columns(1,2)*D.SubMatrix(1,2,1,2);
    double xmin=A_2d.Column(1).Minimum();
    double xmax=A_2d.Column(1).Maximum();
    double ymin=A_2d.Column(2).Minimum();
    double ymax=A_2d.Column(2).Maximum();
    for (j=0; j<ydim; j++)
    {
        for (i=0; i<xdim; i++)
        {
            k=j*xdim+i+1;
            Mk_init_2d(k,1)=xmin+i*(xmax-xmin)/(xdim-1);
            Mk_init_2d(k,2)=ymin+j*(ymax-ymin)/(ydim-1);
        }
    }
    Mk_init = Mk_init_2d*((V.t()).SubMatrix(1,2,1,J));
    Mk=Mk_init;
    W = ((Phi.t()*Phi+IdentityMatrix(M)*EPSILON).i()*Phi.t()*Mk_init).t();
}

void GTM::init_Phi_nonlineaire()   // (i,j) : (ligne,colonne)
{
    int i,j,k,l,ik,jk,jl,il;
    Matrix Bl = Matrix(M,2);
    //double s=1;

    for (j=0; j<ydimM; j++)
    {
        for (i=0; i<xdimM; i++)
        {
            l=j*xdimM+i+1;
            Bl(l,1)=-1+i*(double)2/(xdimM-1);
            Bl(l,2)=-1+j*(double)2/(ydimM-1);
        }
    }
    //cerr << "BL ok ! " << endl;
    for (jk=0; jk<ydim; jk++)
    {
        for (ik=0; ik<xdim; ik++)
        {
            k=jk*xdim+ik+1;
            for (jl=0; jl<ydimM; jl++)
            {
                for (il=0; il<xdimM; il++)
                {
                    l=jl*xdimM+il+1;
                    //cerr << "k=" << k << " " << "l=" << l << endl;
                    Phi(k,l)=exp(-((Sk(k,1)-Bl(l,1))*(Sk(k,1)-Bl(l,1))+(Sk(k,2)-Bl(l,2))*(Sk(k,2)-Bl(l,2)))/sM);
                }
            }
        }
    }
    //cerr << "Phi ok ! " << endl;
}

void GTM::init_Sk()   // (i,j) : (ligne,colonne)
{
    int i,j,k;
    for (j=0; j<ydim; j++)
    {
        for (i=0; i<xdim; i++)
        {
            k=j*xdim+i+1;
            Sk(k,1)=-1+i*(double)2/(xdim-1);
            Sk(k,2)=-1+j*(double)2/(ydim-1);
            U_matrix(k,1)=Sk(k,1);
            U_matrix(k,2)=Sk(k,2);
            D_matrix(k,1)=Sk(k,1);
            D_matrix(k,2)=Sk(k,2);
        }
    }
}

void GTM::init_W_alea()   // Modifier pour faire r�gression avec Mk initiaux par Kohonen
{
    int j,m;
    for (j=0; j<J; j++)
    {
        for (m=0; m<M; m++)
        {
            W(j+1,m+1)=rand()/(1.0+RAND_MAX);
        }
    }
}

void GTM::init_parametres()
{
    init_Sk();
    init_Phi_nonlineaire();
    init_W_parACP();
    evaluer_mk();
    calculer_pki_kmeans();
    calculer_sigma();
    //calculer_mapping();
}

void GTM::init_parametres_sanscontrainte()
{
    //srand(time(NULL));
    int i,j,k;
    for (k=0; k<K; k++)
    {
        i=(int) (((double)I*rand())/(RAND_MAX+1.0));
        for (j=0; j<J; j++)
        {
            Mk(k+1,j+1)=data(i+1,j+1);
        }
    }

    calculer_pki_kmeans(); //*sigma = SIGMA_0;calculer_pki(data, Mk, Pik, Pk, *sigma);
    calculer_sigma();
    calculer_mapping2D();
}

// -------------- CRITERIA ---------------------------------------

double GTM::calculer_logvraisemblance()
{
    logL=0;
    int i,j,k;
    double d=0, dmin=MAX_DOUBLE;
    double dsomme=0;
    double L_i=0;
    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        for (k=0; k<K; k++)
        {
            d=0;
            for (j=0; j<J; j++)
            {
                d=d+(Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
            }
            if (dmin>d)
            {
                dmin=d;
            }
        }
        L_i=0;
        for (k=0; k<K; k++)
        {
            d=0;
            for (j=0; j<J; j++)
            {
                d=d+(Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
            }
            L_i=L_i+exp((-d+dmin)/2/sigma/sigma);
        }
        dsomme=dsomme+dmin;
        logL=logL+log(L_i);
    }
    logL=logL-J*I*log(sigma)-J*I*log(2*PI)/2 - dsomme/2/sigma/sigma - log((double)K)*I;
    logL=logL/I;
    return logL;
}

double GTM::calculer_erreurintra()
{
    double E=0;
    int i,j,k;
    double d=0, dmin=MAX_DOUBLE;
    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        for (k=0; k<K; k++)
        {
            d=0;
            for (j=0; j<J; j++)
            {
                d=d+(Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
            }
            if (dmin>d)
            {
                dmin=d;
            }
        }
        E = E + dmin/I;
    }
    return E;
}

// ----------------- SAVE --------------------------------------------------

void GTM::sauvegarder_p(char* nomfic, const Matrix &mat, int n1, int n2)
{
    //cout << "save " << nomfic;
    ofstream out;
    out.open(nomfic);
    out << n1 << " " << n2 << endl;
    for (int i=0; i<n1; i++)
    {
        for (int j=0; j<n2; j++)
        {
            out << mat(i+1,j+1) << " ";
        }
        out << "\n";
    }
    out.close();
    //cout << "\tok ! \n";
}

void GTM::sauvegarder_v(char* nomfic, const ColumnVector &vect, int n1)
{
    //cout << "save " << nomfic;
    ofstream out;
    out.open (nomfic);
    out << n1 << endl;
    for (int i=0; i<n1; i++)
    {
        out<< vect(i+1) << "\n";
    }
    out.close();
    //cout << "\tok ! \n";
}

void GTM::afficher_p(char* s, const Matrix &mat, int n1, int n2)
{
    int i,j;
    printf("%s = \n",s);
    for (i=0; i<n1; i++)
    {
        if (i==0)
        {
            printf("[ ");
        }
        else
        {
            printf("  ");
        }
        for (j=0; j<n2; j++)
        {
            printf("%e ", mat(i+1,j+1));
        }
        if (i==n1-1) printf("]");
        printf("\n");
    }
}

void GTM::afficher_v(char *s, const ColumnVector &vect, int n1)
{
    int i;
    printf("%s = \n",s);
    for (i=0; i<n1; i++)
    {
        if (i==0)
        {

            printf("[ ");
        }
        else
        {
            printf("  ");
        }
        printf("%e\n", vect(i+1));
        if (i==n1-1) printf("]");
    }
    printf("\n");
}

void GTM::sauvegarder_params(char* nomfic)
{
    ofstream out;
    out.open (nomfic);
    out << "I=" << I << endl;
    out << "J=" << J << endl;
    out << "Xdim=" << xdim << endl;
    out << "Ydim=" << ydim << endl;
    out << "XdimM" << xdimM << endl;
    out << "YdimM=" << ydimM << endl;
    out << "sM=" << sM << endl;
    out << "t_end=" << t_end << endl;
    out << "L=" << logLs(t_end) << endl;
    out << "sigma=" << sigmas(t_end) << endl;
    out.close();
}

// --------- GET ---------------------------------------------------------

double** GTM::get_Pik()
{
    int i,k;
    double** Pik_copy = (double**)malloc(sizeof(double)*I);
    for (i=0; i<I; i++)
    {
        Pik_copy[i]=(double*)malloc(sizeof(double)*K);
        for (k=0;k<K;k++)
        {
            Pik_copy[i][k]=Pik(i+1,k+1);
        }
    }
    return Pik_copy;
}

double** GTM::get_Pik_j(int j)
{
    int i=-1, k=-1, kmin=-1;
    double d,dmin=0;

    double** Pik_j = (double**)malloc(sizeof(double)*I);
    for (i=0; i<I; i++)
    {
        Pik_j[i]=(double*)malloc(sizeof(double)*K);
        for (k=0;k<K;k++)
        {
            Pik_j[i][k]=0;
        }
    }

    for (i=0; i<I; i++)
    {
        dmin=MAX_DOUBLE;
        kmin=-1;
        for (k=0; k<K; k++)
        {
            d=(Mk(k+1,j+1)-data(i+1,j+1))*(Mk(k+1,j+1)-data(i+1,j+1));
            if (d<dmin)
            {
                dmin=d;
                kmin=k;
            }
        }
        for (k=0; k<K; k++)
        {
            if (k==kmin)
            {
                Pik_j[i][k]=1;
            }
            else
            {
                Pik_j[i][k]=0;
            }
        }
    }

    return Pik_j;
}
