#ifndef DATA_H
#define DATA_H
//#include <vector.h>
//#include "ReducMap.h"
//#include "libs.h"

class Data {
public:
Data();
int n;
int p;

double** d_np;
double* min;
double* max;
int* c_n;
int* c_p;
char ** l_n;
char ** l_p;

void readData(char* filename);
void readRowClass(char* filename);
void readColumnClass(char* filename);

~Data();
              
//int n_maps;
//vector <ReducMap*> maps;
//void readReducMap(char* filename);

};

#endif
