//
#ifndef MAIN_H
#define MAIN_H

#include <windows.h>
#include <GL\gl.h>
#include <GL\glu.h>
#include <GL\glut.h>


int WINAPI WinMain(HINSTANCE	hInstance,
				   HINSTANCE	hPervInstance,
				   LPSTR		lpCmdLine,
				   int			nCmdShow);					//main entry point

#endif	//MAIN_H
