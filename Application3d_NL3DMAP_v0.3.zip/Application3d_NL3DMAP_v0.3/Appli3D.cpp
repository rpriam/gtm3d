#include "wx/msgdlg.h"

#include "Appli3D.h"
//#include "AppliFrame.h"

#include "Interface/sample.xpm"
#include "Interface/Parameters.h"
#include "Interface/ReducMap.h"
#include "Interface/LowRenderer.h"
#include "Interface/Controler.h"
#include "Interface/debugDIALOG.h"

//#include "PCA.h"
#include "Algorithms/Data.h"
#include "Algorithms/GTM.h"
//#include "Algorithms/NGGTM.h"
//#include "Algorithms/TNGTM.h"
//#include "Algorithms/Data.h"

#include "Interface/ThreadGTM.h"


IMPLEMENT_APP(Appli3D)

bool Appli3D::OnInit()
{
    // Create the main frame window
    (void) AppliFrame::Create(NULL);

    return true;
}
