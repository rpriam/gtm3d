#ifndef _WX_APPLIFRAME_H_
#define _WX_APPLIFRAME_H_

// ------------- WX_LIB -------------------------------------------------------
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#if !wxUSE_GLCANVAS
#error "OpenGL required: set wxUSE_GLCANVAS to 1 and rebuild the library"
#endif
// -----------------------------------------------------------------------------

#include "wx/progdlg.h"

//#include "Interface/ScanCodeCtrl.h"
//#include "Interface/ScanCodeDialog.h"
#include "Interface/Renderer3D.h"

//#include "Algorithms/Data.h"
#include "Algorithms/GTM.h"

//#include "Interface/ThreadGTM.h"

class ThreadGTM;

//class Data;

//#define ID_NEW_WINDOW 10000
//#define ID_DEF_ROTATE_LEFT_KEY 10001
//#define ID_DEF_ROTATE_RIGHT_KEY 10002


typedef enum
{
    ID_LEAVE            = 1,
    ID_OPEN_DIRECTORY   = 101,
    ID_OPEN_PROJECT     = 102,
    ID_CREATE_PROJECT   = 103,
    ID_CLOSE_PROJECT    = 104,
    ID_SAVE_PROJECT     = 105,
    ID_EXECUTE_VIZ      = 201,
    ID_EXECUTE_GTM      = 202,
    ID_EXECUTE_PCA      = 203,
    ID_APROPOS          = 300,
    THREAD_START_WORKER = 500,
    WORKER_EVENT        = 501
} ITEM_MENU_FRAME;

// Define a new frame type

class AppliFrame: public wxFrame
{
public:
    static AppliFrame *Create(AppliFrame *parentFrame, bool isCloneWindow = false);

    void OnExit(wxCommandEvent& event);
//    void MyFrame::OnOpenDirectory( wxCommandEvent& WXUNUSED(event) );
    void OnOpenProject( wxCommandEvent& WXUNUSED(event) );
    void OnCreateProject( wxCommandEvent& WXUNUSED(event) );
    void OnCloseProject( wxCommandEvent& WXUNUSED(event) );
    void OnSaveProject( wxCommandEvent& WXUNUSED(event) );
//    void MyFrame::OnExecuteVIZ( wxCommandEvent& WXUNUSED(event) );
//    void MyFrame::OnExecutePCA( wxCommandEvent& WXUNUSED(event) );
//    void MyFrame::OnExecuteGTM( wxCommandEvent& WXUNUSED(event) );
    void OnAPropos( wxCommandEvent& WXUNUSED(event) );

    //void OnStartThreadGTM(wxCommandEvent& event);
    void OnThreadGTMEvent(wxCommandEvent& event);
    void OnUpdateThreadGTM(wxUpdateUIEvent& event);

    //wxSemaphore* m_semAllDone;
    wxProgressDialog *m_dlgProgress;

    void updateParameters();

private:

    AppliFrame(wxWindow *parent, const wxString& title, const wxPoint& pos,
            const wxSize& size, long style = wxDEFAULT_FRAME_STYLE);

    void InitData();
//    void DoGTM(GTM* gtm, Data& d, int dim1_W_init, int dim2_W_init,
//                int dim1_W_end, int dim2_W_end, int dim1_W_last,
//                int dim2_W_last, int dim1_M, int dim2_M, double sM,
//                int type_gtm, double beta);

    Renderer3D *m_canvas;
    wxString workDirectory;
    wxString nameProject;

    ThreadGTM* tgtm;

    DECLARE_EVENT_TABLE()
};
#endif // #ifndef _APPLIFRAME_H_
