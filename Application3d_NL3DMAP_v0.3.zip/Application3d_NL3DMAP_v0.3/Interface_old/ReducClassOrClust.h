#ifndef REDUCMAP_H
#define REDUCMAP_H

class ReducMap {

public:
    ReducMap(char* filename);

    int dim1;
    int dim2;
    int k;
    int p;
    
//    int** coord_graph;
//    int** vicinity_matrix;
//    int* reverse_clusters;
    
    double** d_kp;
    double* min;
    double* max;
//    int* c_k;
//    int* c_p;
//    char ** l_k;
//    char ** l_p;

    void readMap(char* filename);
//    void readRowClass(char* filename);
//    void readColumnClass(char* filename);

};

#endif
