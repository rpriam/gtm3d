#include "TIMER.h"

bool Timer::hasBeenReset() {
     return (startTime>0);
}
    
void Timer::Reset()
{
	startTime=(double)timeGetTime();
}

double Timer::GetTime()
{
	if(isPaused)
		return pauseTime-startTime;
	else
		return ((double)timeGetTime())-startTime;
}

void Timer::Pause()
{
	if(isPaused)
		return;		//only pause if unpaused

	isPaused=true;
	pauseTime=(double)timeGetTime();
}

void Timer::Unpause()
{
	if(!isPaused)
		return;		//only unpause if paused

	isPaused=false;
	startTime+=((double)timeGetTime()-pauseTime);	//update start time to reflect pause
}
