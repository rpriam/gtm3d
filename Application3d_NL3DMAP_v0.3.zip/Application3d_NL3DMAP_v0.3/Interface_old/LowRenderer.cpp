#include "LowRenderer.h"
#include "Parameters.h"

LowRenderer::LowRenderer() {
    constructColorMap();
    paintAxisXYZ=false;
    paintInPlaneXYZ=false;
    paintOutBoxXYZ=false;
    paintNameObject3D=false;
    paintData=true;
    paintColorObject3D=CLASS;
    paintMap=false;
    paintGrid=false;
    paintTextGrid=false;
    allowHeighMap=true;
    allowColorMap=true;
    paintNodeGrid=false;
    paintColorMap=false;
    paintColorGrid=false;
    
    coords_map=NULL;    
    dim1_map=-1;
    dim2_map=-1;
    setConstants(Parameters::get_Xmin(), Parameters::get_Xmax(),
                 Parameters::get_Ymin(), Parameters::get_Ymax(),
                 Parameters::get_Zmin(), Parameters::get_Zmax());
    updateAngle=false;
}

void LowRenderer::updateObjects3D_Data(int n,
                                       float** data_proj,
                                       float* min, float* max,
                                       int* data_cl,
                                       MAP_TYPE _type,
                                       OBJECT_TYPE _type3D) {
    type = _type;
    objects3D.clear();
    objects3D.resize(n);
    for (int i=0;i<n;i++) {
      objects3D[i]= new SObject3D();
      char* name = new char[10];
      //char name[10];
      sprintf(name, "i%d", i);
      objects3D[i]->setName(name);
      objects3D[i]->setNum(i);
      objects3D[i]->setCenter(data_proj[i][0], data_proj[i][1], data_proj[i][2]);
      objects3D[i]->setMM(min[0], max[0], min[1], max[1], min[2], max[2]);
      objects3D[i]->setSize(Parameters::get_size());
      objects3D[i]->setType(_type3D);
      objects3D[i]->setColor(0.5f,0.5f,0.5f);
      objects3D[i]->setLowRenderer(this);
      objects3D[i]->setClass(data_cl[i]);
    }
    setNeedUpdateOs3D();
    /*MessageBox (NULL, "update data", "!!", 0);*/
}

void LowRenderer::updateObjects3D_Map(int n, int k,
                                      int dim1, int dim2,
                                      float** map,
                                      float* min,
                                      float* max,
                                      int* map_cl,
                                      MAP_TYPE _type,
                                      OBJECT_TYPE _type3D) {
    type = _type;
    objects3D_map.clear();
    objects3D_map.resize(k);
    for (int l=0;l<k;l++) {
      objects3D_map[l]= new SObject3D();
      char* name = new char[10];
      //char name[10];
      sprintf(name, "C%d", l);
      objects3D_map[l]->setName(name);
      objects3D_map[l]->setNum(n+l);
      objects3D_map[l]->setCenter(map[l][0], map[l][1], map[l][2]);
      objects3D_map[l]->setMM(min[0], max[0], min[1], max[1], min[2], max[2]);
      objects3D_map[l]->setSize(Parameters::get_size());
      objects3D_map[l]->setType(_type3D);
      objects3D_map[l]->setColor(1.0f,1.0f,1.0f);
      objects3D_map[l]->setLowRenderer(this);
    }
    destruct_coords_map();
    dim1_map=dim1;
    dim2_map=dim2;
    construct_coords_map();
    setNeedUpdateMs3D();
    /*MessageBox (NULL, "update map", "!!", 0);*/
}

double LowRenderer::normalizeX(float x, float min_x, float max_x) {
   float n = max(fabs(min_x), fabs(max_x));
   if (min_x>=0) {return (x-min_x)/max_x*Xmax;}
   if (min_x<0) {
       if (Xmin>=0) Xmin=-Xmax;
       if (n>0)  {return (x)/n*Xmax;}
   }
   return x;
}

double LowRenderer::normalizeY(float y, float min_y, float max_y) {
   float n = max(fabs(min_y), fabs(max_y)); 
   if (min_y>=0) {return (y-min_y)/max_y*Ymax;}
   if (min_y<0) {
       if (Ymin>=0) Ymin=-Ymax;
       if (n>0)  {return (y)/n*Ymax;}
   }
   return y;
}

double LowRenderer::normalizeZ(float z, float min_z, float max_z) {
   float n = max(fabs(min_z), fabs(max_z));
   if (min_z>=0) {return (z-min_z)/(max_z-min_z)*(Zmax-1e-3);}
   if (min_z<0) {
       if (Zmin>=0) Zmin=-Zmax;
       if (n>0)  {return (z)/n*(Zmax-1e-3);}
   }
   return z;
}

//double LowRenderer::normalizeX(float x, float min_x, float max_x) {
//   float n = max(fabs(min_x), fabs(max_x));
//   if (n>0) {return x/n*Xmax;}
//   return x;
//}
//
//double LowRenderer::normalizeY(float y, float min_y, float max_y) {
//   float n = max(fabs(min_y), fabs(max_y)); 
//   if (n>0) {return y/n*Ymax;}
//   return y;
//}
//
//double LowRenderer::normalizeZ(float z, float min_z, float max_z) {
//   float n = max(fabs(min_z), fabs(max_z));
//   if (n>0)  {return (z)/n*Zmax;}
//   return z;
//}

void LowRenderer::setConstants(float _Xmin, float _Xmax,
                                float _Ymin, float _Ymax,
                                float _Zmin, float _Zmax) {
   Xmin = _Xmin;
   Xmax = _Xmax;
   Ymin = _Ymin;
   Ymax = _Ymax;
   Zmin = _Zmin;
   Zmax = _Zmax;
}

//void LowRenderer::setModel(vector<SObject3D*>& _objects3D) {
//    objects3D=_objects3D;
//}
//
//void LowRenderer::setModel_map(vector<SObject3D*>& _objects3D_map) {
//    objects3D_map=_objects3D_map;
//}

void LowRenderer::DrawScene( bool selectMode)
{
	static GLuint inPlaneList=0, boxList=0,
    axisList=0, objects3DList=0, objects3DTextList=0,
    mapList=0, gridTextList=0, gridList=0, gridNodeList=0;

	static float angle;

	if(updateAngle) {angle=timer.GetTime()/120;}
	
    glPushMatrix();
    
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(-2.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(angle, 0.0f, 0.0f, 1.0f);

    if (!selectMode) {
        inPlaneList=generateInPlaneList();
    	if (paintInPlaneXYZ) {
           glCallList(inPlaneList);
        }
        
        axisList=generateAxisList();    
        if (paintAxisXYZ) {
            glCallList(axisList);
        }
    
        boxList = generateBoxList();	
        if (paintOutBoxXYZ) {
            glCallList(boxList);
        }
    
        mapList=generateMapList();
        if (paintMap) {
           glCallList(mapList);
        }
    
        gridList=generateGridList();
        if (paintGrid) {
           glCallList(gridList);
        }
    
        gridTextList=generateGridTextList();
        if (paintTextGrid) {
           glCallList(gridTextList);
        }
    
        objects3DList = generateobjects3DList();        
        if (paintData) {
    	  glCallList(objects3DList);
        }
            
        objects3DTextList = generateobjects3DTextList();        
        if (paintNameObject3D) {
        glCallList(objects3DTextList);
        }    
    }
    gridNodeList = generateGridNodeList(selectMode);
    if (paintNodeGrid & !selectMode) {
       glCallList(gridNodeList);
    }
    glPopMatrix();
}

GLuint LowRenderer::generateobjects3DList() {
       static GLuint _objects3DList=0;
       if(_objects3DList==0 || needUpdateO3D)
       {
        if (_objects3DList!=0) {glDeleteLists(_objects3DList,1);}
        if (_objects3DList==0) {_objects3DList=glGenLists(1);}
    		glNewList(_objects3DList, GL_COMPILE);
     		{
               for (int i=0; i<objects3D.size(); i++) {
                if (objects3D[i] !=NULL) {
                    objects3D[i]->paint(paintColorObject3D, false, allowHeighMap);
                }
               }
		    }
		    glEndList();
	   }
	   needUpdateO3D=false;
       return _objects3DList;
}

GLuint LowRenderer::generateobjects3DTextList() {
       static GLuint _objects3DTextList=0;
       if((_objects3DTextList==0 || needUpdateOT3D) & coords_map!=NULL)
       {  
        if (_objects3DTextList!=0) {glDeleteLists(_objects3DTextList,1);}
        if (_objects3DTextList==0) {_objects3DTextList=glGenLists(1);}
    		glNewList(_objects3DTextList, GL_COMPILE);
     		{
               for (int i=0; i<objects3D.size(); i++) {
                if (objects3D[i] !=NULL) {
                    objects3D[i]->paintText(paintColorObject3D, allowHeighMap);
                }
               }
		    }
		    glEndList();
	   }
	   needUpdateOT3D=false;
       return _objects3DTextList;
}

float LowRenderer::heighColotMap_R(float x, float y, float z) {
  return LIBS::test_booleanForFloat( getColR(63-(int)((z/Zmax)*63)),0.5f,allowColorMap);//0.1f
}

float LowRenderer::heighColotMap_G(float x, float y, float z) {
  return LIBS::test_booleanForFloat( getColG(63-(int)((z/Zmax)*63)),0.5f,allowColorMap);
}

float LowRenderer::heighColotMap_B(float x, float y, float z) {      
  return LIBS::test_booleanForFloat( getColB(63-(int)((z/Zmax)*63)),0.5f,allowColorMap);//1.0;
}


//float LowRenderer::heighColotMap_R(float x, float y, float z) {
//  return LIBS::test_booleanForFloat((1-z/Zmax)*0.2,0.5f,allowColorMap);//0.1f
//}
//
//float LowRenderer::heighColotMap_G(float x, float y, float z) {
//  return LIBS::test_booleanForFloat((1-z/Zmax)*0.7,0.5f,allowColorMap);
//}
//
//float LowRenderer::heighColotMap_B(float x, float y, float z) {      
//  return LIBS::test_booleanForFloat((1-z/Zmax)*1.0,0.5f,allowColorMap);//1.0;
//}

float LowRenderer::constructColorMap () {
  cols = (float**)new float[64];
  for (int m=0; m<64; m++) {
    cols[m] = new float[3];
  }
//  float col1[3] = {1.0, 0.0, 0.0};
//  float col2[3] = {0.2, 1.0, 0.0};
//  float col3[3] = {1.0, 1.0, 0.3};
//  float col4[3] = {0.0, 0.0, 0.5};
//  int m2=55;
//  int m3=57;

  float col1[3] = {Parameters::get_col1(0), Parameters::get_col1(1), Parameters::get_col1(2)};
  float col2[3] = {Parameters::get_col2(0), Parameters::get_col2(1), Parameters::get_col2(2)};
  float col3[3] = {Parameters::get_col3(0), Parameters::get_col3(1), Parameters::get_col3(2)};
  float col4[3] = {Parameters::get_col4(0), Parameters::get_col4(1), Parameters::get_col4(2)};
  int m2=Parameters::get_m2();
  int m3=Parameters::get_m3();

  cols[0][0]=col1[0];
  cols[0][1]=col1[1];
  cols[0][2]=col1[2];
  cols[m2][0]=col2[0];
  cols[m2][1]=col2[1];
  cols[m2][2]=col2[2];
  cols[m3][0]=col3[0];
  cols[m3][1]=col3[1];
  cols[m3][2]=col3[2];
  cols[63][0]=col4[0];
  cols[63][1]=col4[1];
  cols[63][2]=col4[2];
 
  for (int m=1; m<=m2; m++) {
      if (Parameters::get_d2()) {
        cols[m][0] = cols[0][0] + (cols[m2][0]-cols[0][0])/(m2-0)*(m-0);
        cols[m][1] = cols[0][1] + (cols[m2][1]-cols[0][1])/(m2-0)*(m-0);
        cols[m][2] = cols[0][2] + (cols[m2][2]-cols[0][2])/(m2-0)*(m-0);
      } else {
        cols[m][0] = cols[m2][0];// + (cols[m2][0]-cols[0][0])/(m2-0)*(m-0);
        cols[m][1] = cols[m2][1];// + (cols[m2][1]-cols[0][1])/(m2-0)*(m-0);
        cols[m][2] = cols[m2][2];// + (cols[m2][2]-cols[0][2])/(m2-0)*(m-0);
      }
  }
  
  for (int m=m2+1; m<=m3; m++) {
      if (Parameters::get_d3()) {
        cols[m][0] = cols[m2][0] + (cols[m3][0]-cols[m2][0])/(m3-m2)*(m-m2);
        cols[m][1] = cols[m2][1] + (cols[m3][1]-cols[m2][1])/(m3-m2)*(m-m2);
        cols[m][2] = cols[m2][2] + (cols[m3][2]-cols[m2][2])/(m3-m2)*(m-m2);
      } else {
        cols[m][0] = cols[m3][0];// + (cols[m3][0]-cols[m2][0])/(m3-m2)*(m-m2);
        cols[m][1] = cols[m3][1];// + (cols[m3][1]-cols[m2][1])/(m3-m2)*(m-m2);
        cols[m][2] = cols[m3][2];// + (cols[m3][2]-cols[m2][2])/(m3-m2)*(m-m2);           
      }
  }
  
  for (int m=m3+1; m<64; m++) {
      if (Parameters::get_d4()) {
        cols[m][0] = cols[m3][0] + (cols[63][0]-cols[m3][0])/(63-m3)*(m-m3);
        cols[m][1] = cols[m3][1] + (cols[63][1]-cols[m3][1])/(63-m3)*(m-m3);
        cols[m][2] = cols[m3][2] + (cols[63][2]-cols[m3][2])/(63-m3)*(m-m3);
      } else {
        cols[m][0] = cols[63][0];//cols[m3][0] + (cols[63][0]-cols[m3][0])/(63-m3)*(m-m3);
        cols[m][1] = cols[63][1];//cols[m3][1] + (cols[63][1]-cols[m3][1])/(63-m3)*(m-m3);
        cols[m][2] = cols[63][2];//cols[m3][2] + (cols[63][2]-cols[m3][2])/(63-m3)*(m-m3);             
      }
  }  
}

GLuint LowRenderer::generateMapList() {
    static GLuint _mapList=0;
    if((_mapList==0 || needUpdateM3D) & coords_map!=NULL)
   	{
        if (_mapList!=0) {glDeleteLists(_mapList,1);}
        if (_mapList==0) {_mapList=glGenLists(1);}
  		glNewList(_mapList,GL_COMPILE);
    	int x, y;
    	float float_x, float_y, float_xb, float_yb;
    
        glPushMatrix();
        glColor3f(1.0f,1.0f,1.0f);
       	glPolygonMode( GL_FRONT, GL_LINE );
        glPolygonMode( GL_BACK,  GL_FILL );
    	glBegin( GL_QUADS );
    	for( x = 0; x < dim1_map-1; x++ ) {
    		for( y = 0; y < dim2_map-1; y++ ) {
    			float_x = float(x);
    			float_y = float(y);
    			float_xb = float(x+1);
    			float_yb = float(y+1);
                
                glColor3f(heighColotMap_R(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]),
                          heighColotMap_G(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]),
                          heighColotMap_B(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]));
  			    glVertex3f( coords_map[x][y][0], coords_map[x][y][1],
                            LIBS::test_booleanForFloat(coords_map[x][y][2],0.0f,allowHeighMap));
                
                glColor3f(heighColotMap_R(coords_map[x][y+1][0],coords_map[x][y+1][1],coords_map[x][y+1][2]),
                          heighColotMap_G(coords_map[x][y+1][0],coords_map[x][y][1+1],coords_map[x][y+1][2]),
                          heighColotMap_B(coords_map[x][y+1][0],coords_map[x][y+1][1],coords_map[x][y+1][2]));
    			glVertex3f( coords_map[x][y+1][0], coords_map[x][y+1][1],
                            LIBS::test_booleanForFloat(coords_map[x][y+1][2],0.0f,allowHeighMap));

                glColor3f(heighColotMap_R(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]),
                          heighColotMap_G(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]),
                          heighColotMap_B(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]));
    			glVertex3f( coords_map[x+1][y+1][0], coords_map[x+1][y+1][1],
                            LIBS::test_booleanForFloat(coords_map[x+1][y+1][2],0.0f,allowHeighMap));

                glColor3f(heighColotMap_R(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]),
                          heighColotMap_G(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]),
                          heighColotMap_B(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]));
    			glVertex3f( coords_map[x+1][y][0], coords_map[x+1][y][1],
                            LIBS::test_booleanForFloat(coords_map[x+1][y][2],0.0f,allowHeighMap));
    		}
    	}
    	glEnd();
        glPopMatrix();
        glEndList();
    }
    needUpdateM3D=false;
    return _mapList;
}

GLuint LowRenderer::generateGridList() {
    static GLuint _gridList=0;
    if((_gridList==0 || needUpdateG3D) & coords_map!=NULL)
   	{
        if (_gridList!=0) {glDeleteLists(_gridList,1);}
        if (_gridList==0) {_gridList=glGenLists(1);}
    	int x, y;
    	float float_x, float_y, float_xb, float_yb;

  		glNewList(_gridList,GL_COMPILE);        
        {
            glPushMatrix();
            glColor3f(1.0f,1.0f,1.0f);
           	glPolygonMode( GL_FRONT, GL_LINE );
           	glPolygonMode( GL_BACK, GL_LINE );
           	glLineWidth(0.8f);
        	glBegin( GL_QUADS );
        	for( x = 0; x < dim1_map-1; x++ ) {
        		for( y = 0; y < dim2_map-1; y++ ) {
        			float_x = float(x);
        			float_y = float(y);
        			float_xb = float(x+1);
        			float_yb = float(y+1);


                if (paintColorGrid) {
                  glColor3f(heighColotMap_R(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]),
                            heighColotMap_G(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]),
                            heighColotMap_B(coords_map[x][y][0],coords_map[x][y][1],coords_map[x][y][2]));
                }
  			    glVertex3f( coords_map[x][y][0], coords_map[x][y][1],
                            0.01f+LIBS::test_booleanForFloat(coords_map[x][y][2],0.0f,allowHeighMap));
                
                if (paintColorGrid) {
                  glColor3f(heighColotMap_R(coords_map[x][y+1][0],coords_map[x][y+1][1],coords_map[x][y+1][2]),
                            heighColotMap_G(coords_map[x][y+1][0],coords_map[x][y][1+1],coords_map[x][y+1][2]),
                            heighColotMap_B(coords_map[x][y+1][0],coords_map[x][y+1][1],coords_map[x][y+1][2]));
                }
    			glVertex3f( coords_map[x][y+1][0], coords_map[x][y+1][1],
                            0.01f+LIBS::test_booleanForFloat(coords_map[x][y+1][2],0.0f,allowHeighMap));

                if (paintColorGrid) {
                  glColor3f(heighColotMap_R(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]),
                            heighColotMap_G(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]),
                            heighColotMap_B(coords_map[x+1][y+1][0],coords_map[x+1][y+1][1],coords_map[x+1][y+1][2]));
                }
    			glVertex3f( coords_map[x+1][y+1][0], coords_map[x+1][y+1][1],
                            0.01f+LIBS::test_booleanForFloat(coords_map[x+1][y+1][2],0.0f,allowHeighMap));

                if (paintColorGrid) {
                  glColor3f(heighColotMap_R(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]),
                            heighColotMap_G(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]),
                            heighColotMap_B(coords_map[x+1][y][0],coords_map[x+1][y][1],coords_map[x+1][y][2]));
                }                  
    			glVertex3f( coords_map[x+1][y][0], coords_map[x+1][y][1],
                            0.01f+LIBS::test_booleanForFloat(coords_map[x+1][y][2],0.0f,allowHeighMap));
        		}
        	}        
    	    glEnd();
            glPopMatrix();
        }
        glEndList();
    }
    needUpdateG3D=false;
    return _gridList;
}

GLuint LowRenderer::generateGridTextList() {
    static GLuint _gridList=0;
   	if((_gridList==0 || needUpdateGT3D) & coords_map!=NULL)
    {
        if (_gridList!=0) {glDeleteLists(_gridList,1);}
        if (_gridList==0) {_gridList=glGenLists(1);}
    	int x, y;
    	float float_x, float_y, float_xb, float_yb;

  		glNewList(_gridList,GL_COMPILE);
  		{
            glPushMatrix();
           	glLineWidth(1.0f);
        	for( x = 0; x < dim1_map; x++ ) {
        		for( y = 0; y < dim2_map; y++ ) {
                    int l=x+y*dim1_map;                     
                    char* text = new char[10];
                    sprintf(text, "%3.2f", objects3D_map[l]->get_z());//coords_map[x][y][2]);
                    float cx=coords_map[x][y][0];
                    float cy=coords_map[x][y][1];
                    float cz =LIBS::test_booleanForFloat(coords_map[x][y][2]+0.2f,0.0f,allowHeighMap);
                    float Rc=1.0f;
                    float Gc=1.0f;  
                    float Bc=1.0f;
                    LIB3D::drawStringText(text,cx,cy,cz,Rc,Gc,Bc);
                }
            }
            glPopMatrix();
        }
        glEndList();
    }
    needUpdateGT3D=false;
    return _gridList;
}

GLuint LowRenderer::generateGridNodeList(bool selectMode) {
    static GLuint _gridList=0;
   	if((_gridList==0 || needUpdateGN3D || selectMode) & coords_map!=NULL)
    {
        //MessageBox (NULL, "List Node Grid object3D", "List Node Grid object3D", 0);
        if (_gridList!=0 & needUpdateGN3D) {glDeleteLists(_gridList,1);}
        if (_gridList==0) {_gridList=glGenLists(1);}
        
    	int x, y;
    	float float_x, float_y, float_xb, float_yb;

        if (!selectMode) {
      		glNewList(_gridList,GL_COMPILE);
      		{                                            
                for (int i=0; i<objects3D_map.size(); i++) {
                    if (objects3D_map[i] !=NULL) {
                        objects3D_map[i]->paint(NONE, false, allowHeighMap);
                    }
                 }
            }
            glEndList();
        } else {
            for (int l=0; l<objects3D_map.size(); l++) {
                 if (objects3D_map[l] !=NULL) {
                      glPushMatrix();
                         glPushName(l+1);                      
                         objects3D_map[l]->paint(NONE, false, allowHeighMap);
                         glPopName();
                      glPopMatrix();
                 }
            }
            //glPopMatrix();
        }
    }
    needUpdateGN3D=false;
    return _gridList;
}

void LowRenderer::construct_coords_map() {
    //float coords[dim1_map][dim2_map][3];
    if (dim1_map>0 & dim2_map>0) {
        coords_map=(float***)new float[dim1_map];
        for (int x=0;x<dim1_map; x++)
          coords_map[x]=(float**)new float[dim2_map];
          
        for (int x=0;x<dim1_map; x++)
           for (int y=0;y<dim2_map; y++)
             coords_map[x][y]=(float*)new float[3];
        
        for(int y=0;y<dim2_map;y++)
        {
       	     for(int x=0;x<dim1_map;x++)
       	     {
                int l=x+y*dim1_map;
                coords_map[ x ][ y ][0] = normalizeX(objects3D_map[l]->get_x(),objects3D[0]->get_min_x(),objects3D[0]->get_max_x());
                coords_map[ x ][ y ][1] = normalizeY(objects3D_map[l]->get_y(),objects3D[0]->get_min_y(),objects3D[0]->get_max_y());
                coords_map[ x ][ y ][2] = normalizeZ(objects3D_map[l]->get_z(),objects3D[0]->get_min_z(),objects3D[0]->get_max_z());
      		}
       	}
    } else {coords_map=NULL;}
}

void LowRenderer::destruct_coords_map() {
    if (coords_map != NULL & dim1_map>0 & dim2_map>0) {
       for (int x=0;x<dim1_map; x++)
         for (int y=0;y<dim2_map; y++)
           delete [] coords_map[x][y];

      for (int x=0;x<dim1_map; x++)
       delete [] coords_map[x];

      delete[] coords_map;
    }
    coords_map=NULL;
}

// ------------------------------------------------------------------------------------------

GLuint LowRenderer::generateAxisList() {
        static GLuint _axisList=0;
    	if(_axisList==0)
    	{
    		_axisList=glGenLists(1);
    		glNewList(_axisList, GL_COMPILE);
    		{                
                glPushMatrix();
                LIB3D::drawCylinder(Xmin, 0.0f, 0.0f, Xmax, 0.0f, 0.0f, 0.04, 0.2f, 0.3f, 0.5f);
                LIB3D::drawCylinder(0.0f, Ymin, 0.0f, 0.0f, Ymax, 0.0f, 0.04, 0.2f, 0.3f, 0.5f);
                LIB3D::drawCylinder(0.0f, 0.0f, Zmin, 0.0f, 0.0f, Zmax, 0.04, 0.2f, 0.3f, 0.5f);
                glPopMatrix();
                LIB3D::drawCone(0.1f, 0.3f, 32, 32, 0.0f, 1.0f, 0.0f, 90.0f,
                                0.0f, 0.0f, Xmax, 0.2f, 0.3f, 0.5f);

                LIB3D::drawCone(0.1f, 0.3f, 32, 32, 1.0f, 0.0f, 0.0f, -90.0f,
                                0.0f, 0.0f, Ymax, 0.2f, 0.3f, 0.5f);

                LIB3D::drawCone(0.1f, 0.3f, 32, 32, 0.0f, 0.0f, 1.0f, 90.0f,
                                0.0f, 0.0f, Zmax, 0.2f, 0.3f, 0.5f);
                glPushMatrix();                
                LIB3D::drawStringText("X", Xmax+0.5f,0.0f,0.01f, 0.2f, 0.3f, 0.5f);
                LIB3D::drawStringText("Y", 0.0f,Ymax+0.5f,0.01f, 0.2f, 0.3f, 0.5f);
                LIB3D::drawStringText("Z", 0.0f,0.0f,Zmax+0.51f, 0.2f, 0.3f, 0.5f);
                glPopMatrix();
    		}
    		glEndList();		
    	}
        return _axisList;
}

GLuint LowRenderer::generateBoxList() {
       static GLuint _boxList=0;
        if(_boxList==0)
    	{
    		_boxList=glGenLists(1);
    		glNewList(_boxList, GL_COMPILE);
    		{                
                glPushMatrix();
                LIB3D::drawCylinder(Xmin, Ymin, 0.0f, Xmin, Ymax, 0.0f, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, Ymin, 0.0f, Xmax, Ymax, 0.0f, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymin, 0.0f, Xmax, Ymin, 0.0f, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymax, 0.0f, Xmax, Ymax, 0.0f, 0.025, 0.1f, 0.1f, 0.3f);
                
                LIB3D::drawCylinder(Xmin, Ymin, Zmin, Xmin, Ymax, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, Ymin, Zmin, Xmax, Ymax, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymin, Zmin, Xmax, Ymin, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymax, Zmin, Xmax, Ymax, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymin, Zmax, Xmin, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, Ymin, Zmax, Xmax, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymin, Zmax, Xmax, Ymin, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymax, Zmax, Xmax, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);                
                
                LIB3D::drawCylinder(Xmin, Ymin, Zmin, Xmin, Ymin, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, Ymax, Zmin, Xmax, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, Ymin, Zmin, Xmax, Ymin, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, Ymax, Zmin, Xmin, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                
                LIB3D::drawCylinder(Xmin, 0.0f, Zmin, Xmin, 0.0f, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmax, 0.0f, Zmin, Xmax, 0.0f, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(0.0f, Ymin, Zmin, 0.0f, Ymin, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(0.0f, Ymax, Zmin, 0.0f, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);

                LIB3D::drawCylinder(Xmin, 0.0f, Zmin, Xmax, 0.0f, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(0.0f, Ymin, Zmin, 0.0f, Ymax, Zmin, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(Xmin, 0.0f, Zmax, Xmax, 0.0f, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                LIB3D::drawCylinder(0.0f, Ymin, Zmax, 0.0f, Ymax, Zmax, 0.025, 0.1f, 0.1f, 0.3f);
                glPopMatrix();
    		}
    		glEndList();		
    	}
    	return _boxList;
}

GLuint LowRenderer::generateInPlaneList() {
        static GLuint _inPlaneList=0;
        if(_inPlaneList==0)
    	{
    		_inPlaneList=glGenLists(1);
    		glNewList(_inPlaneList, GL_COMPILE);
    		{
                glPushMatrix();
                //glBlendFunc(GL_SRC_ALPHA,GL_ONE);
                glEnable(GL_BLEND); // Turn Blending On
                glDisable(GL_DEPTH_TEST); // Turn Depth Testing Off
               	//glPolygonMode( GL_FRONT, GL_FILL );
             	//glPolygonMode( GL_BACK, GL_FILL );
                //drawTetrahed(Xmin, Xmax, Ymin, Ymax, -0.005f, 0.005f, 0.1f, 0.1f, 0.1f, 0.9f);
                //drawTetrahed(0.0f, 0.0f, Ymin, Ymax, Zmin, Zmax, 0.1f, 0.1f, 0.1f, 0.9f);              
                 LIB3D::drawTetrahed(Xmin-0.01, Xmin-0.01, Ymin, Ymax, Zmin, Zmax,       0.0f, 0.0f, 0.0f, 0.95f);
                 LIB3D::drawTetrahed(Xmin, Xmax, Ymin, Ymax, Zmin, Zmin-0.01f, 0.0f, 0.0f, 0.0f, 0.95f);
                //drawTetrahed(Xmin, Xmax, Ymin, Ymax, Zmax-0.01f, Zmax, 0.1f, 0.3f, 0.1f, 0.9f);
                
                //drawTetrahed(Xmin, Xmax, Ymax, Ymax+0.01f, Zmin, Zmax, 0.3f, 0.3f, 0.85f, 0.75f);
                //drawTetrahed(Xmin-0.01f, Xmin, Ymin, Ymax, Zmin, Zmax, 0.3f, 0.3f, 0.85f, 0.75f);
                //drawTetrahed(Xmin, Xmax, Ymin-0.01f, Ymin, Zmin, Zmax, 0.3f, 0.3f, 0.85f, 0.75f);
                //drawTetrahed(Xmax, Xmax+0.01f, Ymin, Ymax, Zmin, Zmax, 0.3f, 0.3f, 0.85f, 0.75f);
                
                //drawTetrahed(Xmin, Xmax, Ymin, Ymax, Zmin, Zmax, 1.0f, 0.2f, 0.0f);
                //drawSphere(Xmax, 0.0f, 0.0f, 0.1f, 1.0f, 0.0f, 0.0f);
                //drawSphere(0.0f, Ymax, 0.0f, 0.1f, 0.0f, 1.0f, 0.0f);
                //drawSphere(0.0f, 0.0f, Zmax, 0.1f, 0.0f, 0.0f, 1.0f);
                //glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                glDisable(GL_BLEND); // Turn Blending On
                glEnable(GL_DEPTH_TEST); // Turn Depth Testing Off
               	glPopMatrix();
    		}
    		glEndList();	
    	}
    	return _inPlaneList;
}
