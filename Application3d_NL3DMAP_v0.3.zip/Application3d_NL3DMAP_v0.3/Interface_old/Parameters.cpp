#include "Parameters.h"

char* Parameters::workDirectory = new char[256];    
char* Parameters::namefileinit = new char[256];
char* Parameters::namefileinit3d = new char[256];
char* Parameters::namefiledata = new char[256];
char* Parameters::namefilelabel = new char[256];
int Parameters::xdim=-1;
int Parameters::ydim=-1;
//int Parameters::I=-1;
//int Parameters::J=-1;
float Parameters::Xmin=-1;
float Parameters::Xmax=-1;
float Parameters::Ymin=-1;
float Parameters::Ymax=-1;
float Parameters::Zmin=-1;
float Parameters::Zmax=-1;
float Parameters::size=-1;
int Parameters::illum=-1;


float* Parameters::col1 = new float[3];
float* Parameters::col2 = new float[3];
float* Parameters::col3 = new float[3];
float* Parameters::col4 = new float[3];
int Parameters::m1=-1;
int Parameters::m2=-1;
int Parameters::m3=-1;
int Parameters::m4=-1;
int Parameters::d1=-1;
int Parameters::d2=-1;
int Parameters::d3=-1;
int Parameters::d4=-1;
        
void Parameters::readParameters(char* _workDirectory) {
    strcpy(workDirectory,_workDirectory);
    ifstream in;
    int aux;
    
	LIBS::add_workDirectory(namefileinit, workDirectory,"gtm.ini");                
    in.open(namefileinit);            
    in >> namefiledata;
	LIBS::add_workDirectory(namefiledata, workDirectory,namefiledata);
    in >> namefilelabel;
    LIBS::add_workDirectory(namefilelabel, workDirectory,namefilelabel);
    in >> aux;  // xdim init gtm
    in >> aux;  // ydim init gtm
    in >> aux;  // xdim end gtm
    in >> aux;  // ydim end gtm
    in >> xdim; // xdim end_wider without gtm step
    in >> ydim; // ydim end_wider without gtm step
    in.close();
    
	LIBS::add_workDirectory(namefileinit3d, workDirectory,"gtm3d.ini");
    in.open(namefileinit3d);            
    in >> Xmin;
    in >> Xmax;
    in >> Ymin;
    in >> Ymax;
    in >> Zmin;
    in >> Zmax;
    in >> size;
    in >> illum;
    
    in >> m1;
    in >> d1;
    in >> col1[0];
    in >> col1[1];
    in >> col1[2];
    in >> m2;
    in >> d2;
    in >> col2[0];
    in >> col2[1];
    in >> col2[2];
    in >> m3;
    in >> d3;
    in >> col3[0];
    in >> col3[1];
    in >> col3[2];
    in >> m4;
    in >> d4;
    in >> col4[0];
    in >> col4[1];
    in >> col4[2];

    in.close();        
}
