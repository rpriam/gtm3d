#include <windows.h>
#include "ReducMap.h"
#include <fstream.h>

ReducMap::ReducMap(char* filename, int _xdim, int _ydim, MAP_TYPE _type) {
  type = _type;
   dim1=_xdim;
   dim2=_ydim;
   readMap(filename);
}

MAP_TYPE ReducMap::get_type() {
  return type;     
}

void ReducMap::readMap(char* workDirectory) {
  char* nameFileCoordmap = MAPS::get_nameFileCoordmap(type);
  char* nameFileCoordproj = MAPS::get_nameFileCoordproj(type);

  ifstream fic;
  char* filename = new char[256];
  int aux;
  
  LIBS::add_workDirectory(filename, workDirectory, nameFileCoordmap);
  d_kp = readMatrix(filename, &k, &p);
  
  LIBS::add_workDirectory(filename, workDirectory, nameFileCoordproj);
  d_ip = readMatrix(filename, &n, &aux);  
  
  min = new float[p];
  max = new float[p];
  for (int j=0; j<p; j++) {
      for (int i=0; i<n; i++) {
          if (i==0) {
             min[j]=d_ip[i][j];
             max[j]=d_ip[i][j];
          } else {
             if (max[j]<d_ip[i][j]) {max[j]=d_ip[i][j];}
             if (min[j]>d_ip[i][j]) {min[j]=d_ip[i][j];}
          }
      }
  }
}

float** ReducMap::readMatrix(char* filename, int* n, int* p) {
  ifstream fic(filename);
  fic >> *n;
  fic >> *p;
  float** A = (float**)new float[*n];
  for (int i=0; i<*n; i++) {
     A[i] = new float[*p];
  }
  for (int i=0; i<*n; i++) {
      for (int j=0; j<*p; j++) {
          fic >> A[i][j];
      }
  }
  fic.close();
  return A;
}

float**& ReducMap::get_dataproj(int j1, int j2, int j3) {
  return d_ip;
}

float**& ReducMap::get_map(int j1, int j2, int j3) {
  return d_kp;
}

float*& ReducMap::get_min() {
  return min;
}

float*& ReducMap::get_max() {
  return max;
}

