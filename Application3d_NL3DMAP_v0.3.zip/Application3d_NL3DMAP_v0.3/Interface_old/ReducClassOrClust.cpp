//
#include "ReducMap.h"
#include <fstream.h>


ReducMap::ReducMap(char* filename) {
   readMap(filename);
}

void ReducMap::readMap(char* filename) {
  ifstream fic(filename);
  fic >> k;
  fic >> p;
  fic >> dim1;
  fic >> dim2;
  d_kp = (double**)new double[k];
  for (int l=0; l<k; l++) 
     {d_kp[l] = new double[p];}
  for (int l=0; l<k; l++) {
      for (int j=0; j<p; j++) {
          fic >> d_kp[l][j];
      }
  }
  fic.close();
  min = new double[p];
  max = new double[p];
  for (int j=0; j<p; j++) {
      for (int l=0; l<k; l++) {
          if (l==0) {
             min[j]=d_kp[l][j];
             max[j]=d_kp[l][j];
          } else {
             if (max[j]<d_kp[l][j]) {max[j]=d_kp[l][j];}
             if (min[j]>d_kp[l][j]) {min[j]=d_kp[l][j];}
          }
      }
  }
}
