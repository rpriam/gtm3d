#ifndef PARAMETERS_H
#define PARAMETERS_H

#include <string.h>
#include <fstream.h>
#include "LIBS.h"

class LIBS;

class Parameters {

public:
    static char* workDirectory;   
    static char* namefileinit;
    static char* namefileinit3d;
    
    static char* namefiledata;
    static char* namefilelabel;
    //static int I;
    //static int J;
    static int xdim;
    static int ydim;

    static float Xmin;
    static float Xmax;
    static float Ymin;
    static float Ymax;
    static float Zmin;
    static float Zmax;
    
    static float size;
    
    static int illum;
    
    static char* get_workDirectory() {return workDirectory;}
    static char* get_namefileinit() {return namefileinit;}
    static char* get_namefiledata() {return namefiledata;}
    static char* get_namefilelabel() {return namefilelabel;}
    //static int get_I() {return I;}
    //static int get_J() {return J;}
    
    static int get_xdim() {return xdim;}
    static int get_ydim() {return ydim;}
    
    static float get_Xmin() {return Xmin;}
    static float get_Xmax() {return Xmax;}
    static float get_Ymin() {return Ymin;}
    static float get_Ymax() {return Ymax;}
    static float get_Zmin() {return Zmin;}
    static float get_Zmax() {return Zmax;}
    
    static float get_size() {return size;}
            
    static int get_illumination() {return illum;}
    
    static void readParameters(char* _workDirectory);
    
    // color map 4 colors
    static float* col1;
    static float* col2;
    static float* col3;
    static float* col4;
    static int m1;
    static int m2;
    static int m3;
    static int m4;
    static int d1;
    static int d2;
    static int d3;
    static int d4;
    
    static float get_col1(int c){ return col1[c]; }
    static float get_col2(int c){ return col2[c]; }
    static float get_col3(int c){ return col3[c]; }
    static float get_col4(int c){ return col4[c]; }
    static int get_m1() {return m1;}
    static int get_m2() {return m2;}
    static int get_m3() {return m3;}
    static int get_m4() {return m4;}
    static int get_d1() {return d1;}
    static int get_d2() {return d2;}
    static int get_d3() {return d3;}
    static int get_d4() {return d4;}
};

#endif
