#ifndef DATA_H
#define DATA_H
#include <vector.h>
#include "ReducMap.h"
//#include "ReducClassOrClust.h"
#include "LIBS.h"

class Data {

  public:
    Data();
    
    int get_n() {return n;}
    int get_p() {return p;}
    int get_k() {return k;}
    
    float** d_np;
    float* min;
    float* max;
    int* c_n;
    int* c_p;
    char ** l_n;
    char ** l_p;
    
    void readData(char* filename);
    void readRowClass(char* filename);
    void readColumnClass(char* filename);
    
    int n_maps;
    vector <ReducMap*> maps;
    void readReducMap(char* workDirectory, int _xdim, int _ydim);
    
    ReducMap* get_reducmap(int num_map);
    
  protected:
    int n;
    int p;
    int k;
    int dim1;
    int dim2;
};

#endif
