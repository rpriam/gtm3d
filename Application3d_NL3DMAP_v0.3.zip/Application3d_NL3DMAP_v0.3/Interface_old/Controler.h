#ifndef CONTROLER_H
#define CONTROLER_H

#include "Renderer3D.h"
#include "Data.h"

class Renderer3D;

class Controler {

  public:
    Controler(Data* _data);      
    void updateObjects3D_Data();
    void updateObjects3D_Map();    
    void keyboard(unsigned char key);
    void special(int key);
    void motion(int x, int y);
    void mouse(int button, int state, int x, int y);
    void save_snapshot();
     
    void setRenderer3D(Renderer3D* _r3d);
  
    MAP_TYPE getType() {return type;}
    
    int get_data_n()   {return data->get_n();}
    int get_data_p()   {return data->get_p();}
    int get_map_k()    {return data->get_reducmap(type)->get_k();}
    int get_map_p()    {return data->get_reducmap(type)->get_p();}
    int get_map_dim1() {return data->get_reducmap(type)->get_dim1();}
    int get_map_dim2() {return data->get_reducmap(type)->get_dim1();}
    
  protected:
    Renderer3D* renderer3D;
    Data* data;
    MAP_TYPE type;
    
    int j_1;
    int j_2;
    int j_3;
    
    void clamp(float *v);  
};

#endif	//CONTROLER_H
