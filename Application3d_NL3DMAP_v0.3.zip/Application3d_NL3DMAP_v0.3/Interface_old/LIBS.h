#ifndef LIBS_H
#define LIBS_H

#include <string.h>
#include <fstream.h>

typedef enum {SPHERE=1,CUBE=2} OBJECT_TYPE;
typedef enum {NONE=0,CLASS=1,CLUSTER=2} OBJECT_COLOR;
typedef enum {MAP_CENTER=0, MAP_UMAT=1, MAP_DENS=2, MAP_ACP=3} MAP_TYPE;
typedef enum {RENDER=0, SELECT=1} PICK_MODE;

class MAPS {
  public:
  static char* get_nameFileCoordmap(MAP_TYPE _type) {
    switch (_type) {
      case MAP_CENTER : return "Mk.txt"; break;
      case MAP_UMAT   : return "Umat.txt"; break;
      case MAP_DENS   : return "Dmat.txt";break;
      case MAP_ACP    : return "Mk_ACP.txt";break;
      otherwise       : return NULL;
    }
  }
  
  static char* get_nameFileCoordproj(MAP_TYPE _type) {
    switch (_type) {
      case MAP_CENTER : return "data.txt"; break;
      case MAP_UMAT   : return "Si_3dU.txt"; break;
      case MAP_DENS   : return "Si_3dD.txt";break;
      case MAP_ACP    : return "data.txt"; break;
      otherwise       : return NULL;
    }
  }
};

class LIBS {
  public:
  static char* add_workDirectory(char* s, char* dw, char* n) {
    char* a=new char[strlen(n)+1];
    strcpy(a,n);
    strcpy(s,dw);
    strcat(s,a);
    delete [] a;
   return s;
  }
  
  static float test_booleanForFloat(float _v_true, float _v_false, bool _b) {
    if (_b) return _v_true;
    return _v_false;
  }
};


#endif
