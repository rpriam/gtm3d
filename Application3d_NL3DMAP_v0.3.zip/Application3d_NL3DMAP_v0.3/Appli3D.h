#ifndef _WX_APPLI3D_H_
#define _WX_APPLI3D_H_

// ------------- WX_LIB -------------------------------------------------------
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#if !wxUSE_GLCANVAS
#error "OpenGL required: set wxUSE_GLCANVAS to 1 and rebuild the library"
#endif
// -----------------------------------------------------------------------------

#include "AppliFrame.h"
//#include "Interface/ScanCodeCtrl.h"
//#include "Interface/ScanCodeDialog.h"
#include "Interface/Renderer3D.h"

//#include "Algorithms/Data.h"
#include "Algorithms/GTM.h"

//class Data;

// Define a new application type
class Appli3D: public wxApp
{
public:
    bool OnInit();
};

#endif
